from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import HttpResponse,JsonResponse
from django.views.decorators.http import require_POST
from bayan.constants import WKHTML_TO_IMAGE_PATH,WKHTML_TO_PDF_PATH,AUTHORISATION_KEY,KEY_MISMATCH_STRING
import imgkit,json,os,pdfkit

@csrf_exempt
@require_POST
def renderChart(request):
    if request.GET.get('key')==AUTHORISATION_KEY:
        width=request.GET.get('width',1000)
        height=request.GET.get('height',520)
        path_wkthmltoimage = WKHTML_TO_IMAGE_PATH
        config = imgkit.config(wkhtmltoimage=path_wkthmltoimage)
        img=imgkit.from_string(request.body.decode("utf-8"),False,{'width': width, 'height':height},config=config)
        return HttpResponse(img, content_type='image/jpg')
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)

@csrf_exempt
@require_POST
def renderPdf(request):
    if request.GET.get('key')==AUTHORISATION_KEY:
        path_wkthmltopdf = WKHTML_TO_PDF_PATH
        config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)
        options = {
        'page-size': 'A4',
        'margin-top': '0',
        'margin-right': '0',
        'margin-bottom': '0',
        'margin-left': '0',
        'encoding': "UTF-8"
        }
        pdf=pdfkit.from_string(request.body.decode("utf-8"),False,configuration=config,options=options)
        return HttpResponse(pdf, content_type='application/*')
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)

@csrf_exempt
@require_POST
def renderPdf1(request):
    if request.GET.get('key')==AUTHORISATION_KEY:
        path_wkthmltopdf = WKHTML_TO_PDF_PATH
        config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)
        options = {
        'page-size': 'A4',
        'margin-top': '0',
        'margin-right': '0',
        'margin-bottom': '0',
        'margin-left': '0',
        'encoding': "UTF-8"
        }
        pdf=pdfkit.from_string(request.body.decode("utf-8"),False,configuration=config,options=options)
        return HttpResponse(pdf, content_type='application/*')
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)