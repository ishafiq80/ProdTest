function loadDashBoardDetails(dashboardDetails, profileDetails) {


    let dashBoardCardDetail = dashboardDetails.formInfo
    let dashBoardLookUpInfo = dashboardDetails.lookupInfo[lang]

    document.getElementById("profileName").innerHTML = !isEmpty(profileDetails.fullName) ? profileDetails.fullName : "" //string
    document.getElementById("profileId").innerHTML = dashBoardLookUpInfo.nationalID + " " + (!isEmpty(profileDetails.nationalId) ? profileDetails.nationalId : "")//string
    document.getElementById("totalCRCount").innerHTML = !isEmpty(profileDetails.total_commercial_records) ? profileDetails.total_commercial_records : 0 //string
    document.getElementById("totalCRLabel").innerHTML = dashBoardLookUpInfo.totalCRs
    document.getElementById("crAppliedCount").innerHTML = dashBoardCardDetail.noOfReportApplied
    document.getElementById("crAppliedLabel").innerHTML = dashBoardLookUpInfo.reportApplied
    document.getElementById("reportIssuedCount").innerHTML = dashBoardCardDetail.noOfReportIssued
    document.getElementById("reportIssuedLabel").innerHTML = dashBoardLookUpInfo.reportIssues
    document.getElementById("certificatePendingCount").innerHTML = dashBoardCardDetail.certificatePending
    document.getElementById("certificatePendingLabel").innerHTML = dashBoardLookUpInfo.certPending
    document.getElementById("certificateIssueCount").innerHTML = dashBoardCardDetail.certificateIssued
    document.getElementById("certificateIssueLabel").innerHTML = dashBoardLookUpInfo.certIssued
    document.getElementById("dahboardProfilePic").src = !isEmpty(profileDetails.userProfile) ? profileDetails.userProfile : defaultProfilePic
}

function onDashboardKPICardClicked(self){
    switch(self.id){
        case "totalCRCard":
        case "crAppliedCard":
            window.location=CR_RECORDS_URL
            break;
        case "reportIssuedCard":
        case "certificatePendingCard":
        case "certificateIssueCard":
            window.location=REPORT_URL
            break;
        default:
            window.location=DASHBOARD_URL
            break;
    }
}
