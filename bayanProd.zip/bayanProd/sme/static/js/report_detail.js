let startPageNumberList = [];
function loadCorporateDetails(data, lookupData, elementId) {


    let corporateDetailsContainer = document.createDocumentFragment()
    let sections = data
    let rowContainer = document.createElement("div")
    $.each(sections, function (key, value) {

        let sectionContainer = document.createElement("div");
        sectionContainer.classList.add("pb-4");

        let sectionTitle = document.createElement("h5");
        sectionTitle.classList.add("section-title")
        sectionTitle.classList.add("primary-color")

        sectionTitle.innerHTML = lookupData[key];

        let sectionInstructions = document.createElement("p");
        sectionInstructions.classList.add("mb-3")

        sectionContainer.append(sectionTitle);
        rowContainer = document.createElement("div")
        rowContainer.classList.add("row")
        sectionContainer.append(rowContainer)
        $.each(value, function (key1, value1) {
        if(key1!="legalFormAr" &&
            key1!="registrationStatusAr")
        {
                if (key1 % 2 == 0) {
                rowContainer = document.createElement("div")
                rowContainer.classList.add("row")
                rowContainer.classList.add("row-container")

                sectionContainer.append(rowContainer)
            }

            let divContainer = document.createElement("div")
            divContainer.classList.add("col-12")
            divContainer.classList.add("col-md-6")
            divContainer.classList.add("pt-4")
            divContainer.classList.add("pt-md-0")


            let inputDiv = document.createElement("div")
            inputDiv.classList.add("form-group")
            inputDiv.classList.add("margin-bottom-input")

            let inputLabel = document.createElement("label")
            inputLabel.setAttribute("for", "text")
            inputLabel.classList.add("label-bottom-padding")
            inputLabel.innerHTML = lookupData[key1]

            let input = document.createElement("input")
            input.classList.add("form-control")
            input.classList.add("input-read-only")
            input.setAttribute("disabled", "true")
            var arabic = /[\u0600-\u06FF]/;

            if (arabic.test(value1)) {
                input.setAttribute("dir", "rtl")
            }
            if ((elementId == "m360Tab1Content" || elementId == "reviewTab1") && (key1 == "registerationDate" || key1 == "registerationExpiryDate")) {
                value1 = (!isEmpty(value1)) ? getFormattedDate(value1) : ""
            }
            if ((elementId == "reportTab1") && lang=='arabic' && (key1 == "legalForm"|| key1 == "registrationStatus")) {
                input.value = value[key1+'Ar']  
            }
            else{
                input.value = value1;
            }
            if(key1=='paidUpCapital'){
                if(lang=='arabic')
                {
                    input.value=value1+" "+lookupData.currencySR;
                }
                else{
                    input.value=lookupData.currencySR+" "+value1;
                }
            }
            inputDiv.append(inputLabel)
            inputDiv.append(input)

            divContainer.append(inputDiv)
            rowContainer.append(divContainer)
        }
        })


        corporateDetailsContainer.append(sectionContainer)

    })
    document.getElementById(elementId).appendChild(corporateDetailsContainer)
}

function loadBusinessAnalysisDetails(data, lookupData,elementId) {


    let businessAnalysisContainer = document.createDocumentFragment()
    $.each(data, function (key, value) {


        let sectionContainer = document.createElement("div");
        sectionContainer.classList.add("pb-4");

        let sectionTitle = document.createElement("h5");
        sectionTitle.classList.add("section-title")
        sectionTitle.classList.add("primary-color")
        sectionTitle.innerHTML = value[lang].name;

        let sectionInstructions = document.createElement("p");
        sectionInstructions.classList.add("mb-3")

        sectionContainer.append(sectionTitle);
        let rowContainer;

        $.each(value.questions, function (key1, value1) {



            rowContainer = document.createElement("div")
            rowContainer.classList.add("row")
            rowContainer.classList.add("row-container")
            rowContainer.classList.add("mb-4")
            rowContainer.classList.add("mb-md-0")


            let divContainer = document.createElement("div")
            divContainer.classList.add("container")


            let questionTitle = document.createElement("h5")
            questionTitle.classList.add("ba-question-title");
            questionTitle.innerHTML = value1[lang]['question']

            let ansTitle = document.createElement("h4");
            ansTitle.classList.add("ba-ans-title")
            ansTitle.innerHTML = value1[lang]['answer']

            divContainer.append(questionTitle)
            divContainer.append(ansTitle)


            let justification = document.createElement("h4");
            justification.classList.add("ba-ans")


            if (!isEmpty(value1['justification'])) {
                justification.innerHTML = lookupData['justification'] + ": " + value1['justification']
                divContainer.append(justification)
            }

            if (value1.hasOwnProperty("documents")) {
                let docList = document.createElement("h4")
                docList.classList.add("ba-ans")
                docList.classList.add("mt-2")
                let docLinkLabel = document.createElement("span")
                docLinkLabel.innerHTML = ""
                docLinkLabel.classList.add("d-none")
                docList.append(docLinkLabel)
                $.each(value1["documents"], function (key2, value2) {
                    if (!isEmpty(value2)) {
                        let docLink = document.createElement("a")
                        docLink.classList.add("anchor-link")
                        docLink.addEventListener("click", function (event) {
                            // GET_UPLOADED_DOCUMENT_URL +
                            // folderName +
                            // "/" +
                            // existingFiles[i].frontEndName,
                            if(elementId=='reviewTab2'){
                                docLink.href =  GET_UPLOADED_DOCUMENT_URL +
                                value2.appianDocumentId+
                                "/"
                                docLink.download = value2.documentName
                            }else{
                                downloadFile(value2, "")
                            }
                            
                            return false;
                        })
                        let docLinkText = (elementId=='reviewTab2')?value2.documentName:value2.docName

                        if (key2 < value1["documents"].length - 1) {
                            docLinkText = docLinkText.concat(", ")
                        }

                        docLinkLabel.classList.remove("d-none")
                        docLink.innerHTML = docLinkText
                        docList.append(docLink)
                    }
                })
                divContainer.append(docList)

            }
            rowContainer.append(divContainer)
            sectionContainer.append(rowContainer)

        })

        businessAnalysisContainer.append(sectionContainer)
    })

    document.getElementById(elementId).appendChild(businessAnalysisContainer)

}

function downloadFile(value, btnId) {

    $.ajax({

        beforeSend: function () {
            if (!isEmpty(btnId)) {
                document.getElementById("img" + btnId).src = imgLoaderSrc
                document.getElementById("img" + btnId).style.height = "8px"
                document.getElementById("span" + btnId).classList.add("download-loader")
                document.getElementById(btnId).style.pointerEvents = "none"
            }
        },
        type: 'GET',
        url: DOWNLOAD_URL + value.docId, //url
        xhrFields: {
            responseType: 'blob'
        },

        success: function (blob) {
           try{
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = value.docName + "." + value.docExtension;
            link.click();
           }
           catch(err){
            
           }

        },
        complete: function () {
            if (!isEmpty(btnId)) {
                if(!isEmpty(document.getElementById("img" + btnId))){
                document.getElementById("img" + btnId).src = fileImgSrc
                document.getElementById("img" + btnId).style.height = "15px"
                document.getElementById(btnId).style.pointerEvents = "visible"
                document.getElementById("span" + btnId).classList.remove("download-loader")
                }
            }
        }
    });


}

function loadEmailMobileDetails(value) {
    let surveyTypeContainer = document.createElement("div");
    $.each(value, function (key1, value1) {
        let emailMobileDiv = document.createElement("div");
        emailMobileDiv.classList.add("row");
        emailMobileDiv.classList.add("mb-4");
        let emailDiv = document.createElement("div");
        emailDiv.classList.add("col-12");
        emailDiv.classList.add("col-md-6");
        emailDiv.classList.add("mt-2");
        emailDiv.classList.add("mt-md-0");
        let emailInput = document.createElement("input");   
        emailInput.classList.add("form-control");    
        emailInput.setAttribute("disabled", "true");
        emailInput.value = value1.email;
        emailDiv.append(emailInput);
        let mobileDiv = document.createElement("div");
        mobileDiv.classList.add("col-12");
        mobileDiv.classList.add("col-md-6");
        mobileDiv.classList.add("mt-2");
        mobileDiv.classList.add("mt-md-0");
        let mobileInput = document.createElement("input");  
        mobileInput.classList.add("form-control");
        mobileInput.classList.add("mobile-input");
        mobileInput.classList.add("input-read-only");
        mobileInput.setAttribute("disabled", true);
        mobileInput.value = value1.code + " " + value1.mobileNum;
        mobileDiv.append(mobileInput);
        emailMobileDiv.append(emailDiv);
        emailMobileDiv.append(mobileDiv);
        surveyTypeContainer.append(emailMobileDiv);
    });
    return surveyTypeContainer;
}

function createSurveyPageNumberSet(startPage, pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData) {
    let tempI=startPage;
    for (var i = startPage; (i < (startPage + pageNumberSetLimit)) && (i <= (totalPaginate)); i++) {

        var anchor = document.createElement("a");
        anchor.classList.add("pagination-anchor");
        anchor.addEventListener("click", function () {
            if(!$(this).hasClass("active"))
            {
            if( (($(this).text()==totalPaginate))){
                $("#paginationDiv" + key + " a").removeClass("active");
                    $(this).addClass("active");
                    end = pageSize * $(this).text();
                    startPageNumberList[key] = startPage-1;
                    $("#emailMobileListContainer" + key + " div").remove()
                    $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice(end - pageSize, end)))
            }
            else if (startPageNumberList[key] <= totalPaginate) {
                startPageNumberList[key]++;
                $('#pageNumberDiv' + key + ' a').remove();

                $("#leftArrow" + key).removeClass('disabled');
                $("#leftDoubleArrow" + key).removeClass('disabled');
                $('#leftDot'+key).show();
                let startPage = (startPageNumberList[key])
                createSurveyPageNumberSet(startPage, pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)
                $("#emailMobileListContainer" + key + " div").remove()
                $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice((startPage * pageSize) - pageSize, (startPage * pageSize))))
            }
        }
            // if (!$(this).hasClass("disabled")) {
            //     $("#paginationDiv" + key + " a").removeClass("active");
            //     $(this).addClass("active");
            //     end = pageSize * $(this).text();
            //     startPageNumberList[key] = $(this).text();
            //     $("#emailMobileListContainer" + key + " div").remove()
            //     $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice(end - pageSize, end)))

            // }
        })
        anchor.innerHTML = i;
        if (i == startPage) {
            anchor.classList.add("active");
        }

        if (i == 1) {
            $("#leftArrow" + key).addClass('disabled');
            $("#leftDoubleArrow" + key).addClass('disabled');
            $('#leftDot'+key).hide();
        }
        if (i == totalPaginate) {
            $("#rightArrow" + key).addClass('disabled');
            $("#rightDoubleArrow" + key).addClass('disabled');
            $('#rightDot'+key).hide();
        }

        if (lang == "arabic") {
            pageNumberDiv.prepend(anchor)
        } else {
            pageNumberDiv.append(anchor)
        }
        tempI=i
    }
    var paginationRightDot = document.createElement('a');
    paginationRightDot.setAttribute('id', 'rightDot');
    paginationRightDot.setAttribute('style', 'color: black !important;');
    paginationRightDot.classList.add('pagination-anchor');
    paginationRightDot.classList.add('disabled');
    paginationRightDot.innerHTML='..'
    

    if (lang == "arabic") {
        pageNumberDiv.prepend(paginationRightDot)
    } else {
        pageNumberDiv.append(paginationRightDot)
    }
    if (tempI == totalPaginate) {
        $(paginationRightDot).hide()
    }
    var totalCountDiv = document.createElement("a");
    totalCountDiv.classList.add("pagination-anchor");
    totalCountDiv.classList.add("disabled");

    let spanText = document.createElement("span")
    spanText.classList.add("page-span-number")
    spanText.innerHTML = totalPaginate

    let numberSpanText = document.createElement("span")
    numberSpanText.classList.add("page-span-number")
    numberSpanText.innerHTML = lookupData.of; //string
    
    if (lang == "arabic") {
        totalCountDiv.append(numberSpanText)
        totalCountDiv.append(spanText)
        pageNumberDiv.prepend(totalCountDiv);
    } else {
        totalCountDiv.append(numberSpanText)
        totalCountDiv.append(spanText);
        pageNumberDiv.append(totalCountDiv);
    }

}


function getSurveyPaginatedList(surveyTypeList, key, paginationDiv,lookupData) {

    if (surveyTypeList.length > pageSize) {
        var totalPaginate = Math.ceil(surveyTypeList.length / pageSize);
        var paginationDoubleLeftArrow = document.createElement('a');
        paginationDoubleLeftArrow.setAttribute('id', 'leftDoubleArrow' + key);
        paginationDoubleLeftArrow.classList.add('pagination-anchor')
        paginationDoubleLeftArrow.innerHTML = '&laquo';
        if (!(surveyTypeList.length <= pageNumberSetLimit * pageSize)) {
            if (lang == "arabic") {
                paginationDiv.prepend(paginationDoubleLeftArrow)
            } else {
                paginationDiv.append(paginationDoubleLeftArrow)
            }
        }

        var paginationLeftArrow = document.createElement('a');
        paginationLeftArrow.setAttribute('id', 'leftArrow' + key);
        paginationLeftArrow.classList.add('pagination-anchor')
        paginationLeftArrow.innerHTML = '&lsaquo;';
        if (!(surveyTypeList.length <= pageNumberSetLimit * pageSize)) {
            if (lang == "arabic") {
                paginationDiv.prepend(paginationLeftArrow)
            } else {
                paginationDiv.append(paginationLeftArrow)
            }
        }
        var paginationLeftDot = document.createElement('a');
        paginationLeftDot.setAttribute('id', 'leftDot'+key);
        paginationLeftDot.setAttribute('style', 'color: black !important;');
        paginationLeftDot.classList.add('pagination-anchor');
        paginationLeftDot.classList.add('disabled');
        paginationLeftDot.innerHTML='..'
        if (lang == "arabic") {
            paginationDiv.prepend(paginationLeftDot)
        } else {
            paginationDiv.append(paginationLeftDot)
        }
        var pageNumberDiv = document.createElement('span');
        pageNumberDiv.setAttribute('id', 'pageNumberDiv' + key);
        if (lang == "arabic") {
            paginationDiv.prepend(pageNumberDiv)
        } else {
            paginationDiv.append(pageNumberDiv)
        }

        var paginationRightArrow = document.createElement('a');
        paginationRightArrow.setAttribute('id', 'rightArrow' + key);
        paginationRightArrow.classList.add('pagination-anchor')
        paginationRightArrow.innerHTML = '&rsaquo;';
        paginationRightArrow.setAttribute('value', '&rsaquo;');
        if (!(surveyTypeList.length <= pageNumberSetLimit * pageSize)) {
            if (lang == "arabic") {
                paginationDiv.prepend(paginationRightArrow)
            } else {
                paginationDiv.append(paginationRightArrow)
            }
        }

        var paginationDoubleRightArrow = document.createElement('a');
        paginationDoubleRightArrow.setAttribute('id', 'rightDoubleArrow' + key);
        paginationDoubleRightArrow.classList.add('pagination-anchor')
        paginationDoubleRightArrow.innerHTML = '&raquo';
        if (!(surveyTypeList.length <= pageNumberSetLimit * pageSize)) {
            if (lang == "arabic") {
                paginationDiv.prepend(paginationDoubleRightArrow)
            } else {
                paginationDiv.append(paginationDoubleRightArrow)
            }
        }
        $(paginationLeftArrow).addClass('disabled');
        $(paginationDoubleLeftArrow).addClass('disabled');
        $(paginationLeftDot).hide();
        createSurveyPageNumberSet(startPageNumberList[key], pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)

        $(paginationRightArrow).click(function (event) {
            startPageNumberList[key]++;

            if (startPageNumberList[key] <= totalPaginate) {

                $('#pageNumberDiv' + key + ' a').remove();

                $(paginationLeftArrow).removeClass('disabled');
                $(paginationDoubleLeftArrow).removeClass('disabled');
                $(paginationLeftDot).show();
                let startPage = (startPageNumberList[key])
                createSurveyPageNumberSet(startPage, pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)
                $("#emailMobileListContainer" + key + " div").remove()
                $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice((startPage * pageSize) - pageSize, (startPage * pageSize))))
            }
        });
        $(paginationLeftArrow).click(function (event) {
            if (startPageNumberList[key] > 1) {
                startPageNumberList[key]--;
            }
                $('#pageNumberDiv' + key + ' a').remove();
                $(paginationRightArrow).removeClass('disabled');
                $(paginationDoubleRightArrow).removeClass('disabled');
                $('#rightDot'+key).show();
                let startPage = startPageNumberList[key]
                createSurveyPageNumberSet(startPage, pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)
                $("#emailMobileListContainer" + key + " div").remove()
                $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice((startPage * pageSize) - pageSize, (startPage * pageSize))));
        });
        $(paginationDoubleRightArrow).click(function (event) {

            $('#pageNumberDiv' + key + ' a').remove();
            $(paginationLeftArrow).removeClass('disabled');
            $(paginationDoubleLeftArrow).removeClass('disabled');
            $(paginationLeftDot).show();
            startPageNumberList[key] = totalPaginate - pageNumberSetLimit + 1
            let startPage = totalPaginate - pageNumberSetLimit + 1
            createSurveyPageNumberSet(startPage, pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)
            $("#emailMobileListContainer" + key + " div").remove()
            $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice((startPage * pageSize) - pageSize, startPage * pageSize)));

        });
        $(paginationDoubleLeftArrow).click(function (event) {

            $('#pageNumberDiv' + key + ' a').remove();
            $(paginationRightArrow).removeClass('disabled');
            $(paginationDoubleRightArrow).removeClass('disabled');
            $('#rightDot'+key).show();
            startPageNumberList[key] = 1
            createSurveyPageNumberSet(startPageNumberList[key], pageNumberDiv, key, totalPaginate, surveyTypeList,lookupData)
            $("#emailMobileListContainer" + key + " div").remove()
            $("#emailMobileListContainer" + key).append(loadEmailMobileDetails(surveyTypeList.slice(0, pageSize)));

        });

    }

    let contentContainer = loadEmailMobileDetails(surveyTypeList.slice(0, pageSize))
    return contentContainer;
}

function loadSurveyDetails(data, lookupData,elementId) {
   
    let surveyContainer = document.createDocumentFragment();
    let surveyDivContainer = document.createElement("div");
    surveyDivContainer.classList.add("row");
    let isValueExist = true

    $.each(data, function (key, value) {

        if (!isEmptyList(value.value)) {
            let surveyTypeContainer = document.createElement("div");
            surveyTypeContainer.classList.add("col-12");
            surveyTypeContainer.classList.add("col-md-6");
            surveyTypeContainer.classList.add("mt-2");
            surveyTypeContainer.classList.add("mt-md-0");

            let surveyCardContainer = document.createElement("div")
            surveyCardContainer.classList.add("card")
            surveyCardContainer.classList.add("DS")
            surveyCardContainer.classList.add("p-4")

            let surveyTypeTitle = document.createElement("h5");
            surveyTypeTitle.classList.add("section-title");
            surveyTypeTitle.classList.add("primary-color");
            surveyTypeTitle.innerHTML = value.type[lang].name;

            surveyCardContainer.append(surveyTypeTitle);

            let emailMobileListContainer = document.createElement("div");

            let detailsContainer = document.createElement("div");
            detailsContainer.setAttribute("id", "emailMobileListContainer" + key);
            let paginationContainerDiv = document.createElement("div");

            let paginationDiv = document.createElement("div");
            paginationDiv.classList.add("d-flex")
            paginationDiv.classList.add("justify-content-center")
            paginationDiv.classList.add("align-items-center")
            startPageNumberList[key] = 1

            let paginationInnerDiv=document.createElement("div");
            paginationInnerDiv.setAttribute("id", "paginationDiv" + key)

            let detailsContainerContent = getSurveyPaginatedList(value.value, key, paginationInnerDiv,lookupData)
            detailsContainer.append(detailsContainerContent)

            emailMobileListContainer.append(detailsContainer)
            paginationDiv.append(paginationInnerDiv)
            paginationContainerDiv.append(paginationDiv)
            emailMobileListContainer.append(paginationContainerDiv)

            surveyCardContainer.append(emailMobileListContainer);
            surveyTypeContainer.append(surveyCardContainer)
            surveyDivContainer.append(surveyTypeContainer);

        } else {
            isValueExist = false
        }
    });

    surveyContainer.append(surveyDivContainer);
    if (isValueExist) {
        document.getElementById(elementId).appendChild(surveyDivContainer);
    }
}