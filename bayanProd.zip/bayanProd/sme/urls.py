from django.urls import path
from . import views
from . import api_data
# from .api_data import savedocument


urlpatterns = [
    path('', views.index, name='index'),
    path('download/<id>/',api_data.downloadPdf,name='PDF'),
    path('smeFormDetails/',api_data.smeFormDetails,name='smeFormDetails'),
    path('postFormDetails/',api_data.postSurveyForm,name='postFormDetails'),
    path('postDraftFormDetails/',api_data.postDraftSurveyForm,name='postDraftFormDetails'),
    path('uploadDocument/',api_data.uploadDocument,name="uploadDocument"),
    path('logout/',views.logoutUser,name='logout'),
    path('postContactForm/',api_data.postContactForm, name="postContactForm"),
    path('userDetails/',views.sendUserDetails,name="userDetails"),
    path('removeInActiveUser/',api_data.removeLoggedoutUser,name="removeLoggedoutUser"),
    path('removeDocumentFolder/',api_data.removeDocumentFolder,name="removeDocumentFolder"),
    path('getProfileDetails/',api_data.getProfileDetails,name='profileDetails'),
    path('getUploadedDocument/<docId>/',api_data.getUploadedDocument,name="getUploadedDocument"),
    path('finalFolderList/',api_data.getFolderList,name='getFolderList'),
    path('<tabName>/', views.renderTab,{'crNum':''}),
    path('<tabName>/<crNum>/', views.renderTab, name='renderTab')
]
