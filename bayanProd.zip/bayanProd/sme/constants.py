from bayan.constants import BASE_URL,BAYAN_BASE_URL

GET_MTS_DETAILS_URL=BASE_URL+'getMTSDetails/'

DOWNLOAD_URL=BASE_URL+'download/'

CORPORATE_DETAILS_URL=BAYAN_BASE_URL+'reports/V1/'

SME_FORM_URL=GET_MTS_DETAILS_URL+'smeForm/'

FS_FALSE_LOOKUP_URL=GET_MTS_DETAILS_URL+'noFinancialStatements/'

SERVICE_UNAVAILABLE='Service Unavailable'

CLEANED_FOLDERS='Cleaned folders successfully'

REMOVED_USERS='Removed users successfully'

MESSAGE_INFO = {
            "english": {
                "messageTitle": "Service unavailable!",
                "messageDescription": "Sorry, we'are unable to reach the server right now. Please try again later.",
                "btnText":"Return to home"
            },
            "arabic": {
                "messageTitle": "الخدمة غير متوفرة!‎",
                "messageDescription": "عذرًا ، لم نتمكن من الوصول إلى الخادم في الوقت الحالي. الرجاء معاودة المحاولة في وقت لاحق.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }
        }

ACTION_BY_STATUS={
    "user":'user',
    "sys":'system'
}

POST_MTS_DETAILS_URL=BASE_URL+'postAssessmentResponse/'

POST_MTS_DRAFT_DETAILS=BASE_URL+'postSMESaveDraftDetails/'

CONTACT_US_URL = BASE_URL+'getContactDetails/'

CONTACT_US_POST_URL = BASE_URL+'postSupportTicketDetails/'

APPIAN_UPLOAD_DOCUMENT_URL = BASE_URL+'uploadDocument/'

APPIAN_REMOVE_DOCUMENT_URL =  BASE_URL+'deleteMultipleDocuments/'

FILE_UPLOAD_LOCATION='C:\\WINDOWS_SHARED_LOCATION\\FE_FILES\\'

FILE_SEPARATOR='\\'


