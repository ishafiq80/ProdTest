from django.shortcuts import render,redirect
from django.views.decorators.http import require_GET,require_POST
from django.http.response import JsonResponse,HttpResponse,FileResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import FileSystemStorage
from time import time as _time
import requests,json,time,asyncio,xmltodict,os,shutil
import logging
from bayan.constants import APPIAN_KEY_VALUE,AUTHORISATION_KEY,KEY_MISMATCH_STRING,LANDING_URL
from sme.constants import REMOVED_USERS,CLEANED_FOLDERS,SERVICE_UNAVAILABLE,FILE_SEPARATOR,POST_MTS_DRAFT_DETAILS,CONTACT_US_POST_URL,CONTACT_US_URL,FS_FALSE_LOOKUP_URL,FILE_UPLOAD_LOCATION,GET_MTS_DETAILS_URL,DOWNLOAD_URL,MESSAGE_INFO,POST_MTS_DETAILS_URL,SME_FORM_URL,APPIAN_UPLOAD_DOCUMENT_URL,APPIAN_REMOVE_DOCUMENT_URL
from sme.utils import getConcatString,getResponseList,getRandomNumber,editedResponse,getProfileDetails
from sme.models import SessionDetails,UserDetails,SmeCommonLookup,CRDetails

logger = logging.getLogger('sme')

def getDataForDashboard(tabName,param,request):
    headers={"Content-Type":"application/json",'Authorization':'Bearer {}'.format(request.user)}
    url = GET_MTS_DETAILS_URL+tabName
    user=SessionDetails.objects.get(username=request.user)
    try:
        userDetails=UserDetails.objects.get(uid=user.uid)
    except:
        return {"response_data":json.dumps({'messageInfo':MESSAGE_INFO})}
    paramData={}
    isTabNameError=False
    if tabName == 'dashboard':
        paramData={"nationalId":str(userDetails.national_id)}
    elif tabName == 'crRecords':
        crList=[]
        if userDetails.cr_list!='':
            crList=userDetails.cr_list.split(',')
        if userDetails.national_id=='1062637721':
            crList=["1010440768"]
        paramData={"crNumbers":crList,"nationalId":str(userDetails.national_id)}
    elif tabName == 'reports':
        paramData={"nationalId":str(userDetails.national_id)}
    elif tabName == 'reportDashboard':
        paramData={"requestId":param,"nationalId":str(userDetails.national_id)}
    elif tabName=='contact':
        url=GET_MTS_DETAILS_URL+'contactDetails'
    else:
        isTabNameError=True
        tabName ='dashboard'
        paramData={"nationalId":str(userDetails.national_id)}
    lookup=''
    try:
        lookupdata=SmeCommonLookup.objects.get(key_value=user.access_token)
        lookup=lookupdata.lookup_details
        footerDetails=lookupdata.footer_details
    except:
        url=url+'/common/'
    response = requests.post(url,data=json.dumps(paramData), headers={'Appian-API-Key': APPIAN_KEY_VALUE}, verify=False)
    if response.ok:
        response=response.json()
        if tabName=='crRecords':
            crListData=CRDetails.objects.filter(user_key=user.uid)
            for crObj in crListData:
                for value in response[0]['crRecordDetails']['formInfo']:
                    if crObj.cr_number == value['crNumber']:
                        value['companyName']=crObj.cr_company_name

        if '/common/' in url:
            footerDetails=requests.post(GET_MTS_DETAILS_URL+'contactDetails', headers={'Appian-API-Key': APPIAN_KEY_VALUE}, verify=False)
            if footerDetails.ok:
                footerDetails=footerDetails.json()[0]
                del footerDetails['contactDetails']['formInfo']['supportTypeNames']
                del footerDetails['contactDetails']['validations']
                footerDetails=footerDetails['contactDetails']
            else:
                footerDetails={'messageInfo':MESSAGE_INFO}
            SmeCommonLookup.objects.create(
                key_value=user.access_token,
                lookup_details=json.dumps(response[1]),
                footer_details=json.dumps(footerDetails)
            )
            lookup=json.dumps(response[1])
        resultData={"response_data":json.dumps(response[0]),
            "lookup":lookup,
            "footer_details":footerDetails,
            "profile_details":json.dumps(getProfileDetails(userDetails)) }
        if isTabNameError:
            resultData["response_data"]=json.dumps({'messageInfo':MESSAGE_INFO})
        elif tabName == "reportDashboard":
            resultData["reports"]="active"
        else:
            resultData[tabName]="active"
        if tabName=="reports":
            resultData['crNumber']=json.dumps(param)
        response=resultData
    else:
        response={"response_data":json.dumps({'messageInfo':MESSAGE_INFO})}
    return response

@require_GET
def downloadPdf(request,id):
    if request.user.is_authenticated:
        requestsResponse = requests.get(DOWNLOAD_URL+id+'/', headers={'Appian-API-Key': APPIAN_KEY_VALUE}, verify=False)
        if requestsResponse.ok:
            response=HttpResponse(requestsResponse.content,content_type=requestsResponse.headers['content-type'])
            response['Content-Disposition'] = requestsResponse.headers['content-disposition']
        else:
            response=requestsResponse.content
        return response
    else:
        # template='sme/landingPage.html'
        # return render(request, template, getFooterDetails())
        return redirect(LANDING_URL)

@csrf_exempt
@require_POST
def smeFormDetails(request):
    if request.user.is_authenticated:
        logger.info("request details ")
        logger.info(json.loads(request.body))
        crNumber=json.loads(request.body)['crNumber'] if 'crNumber' in json.loads(request.body) else ""
        lang=json.loads(request.body)['lang'] if 'lang' in json.loads(request.body) else ""
        isSaveDraft=json.loads(request.body)['isSaveDraft'] if 'isSaveDraft' in json.loads(request.body) else ""
        isCreateFromStart=json.loads(request.body)['isCreateFromStart'] if 'isCreateFromStart' in json.loads(request.body) else ""
        supportTicketDetails=json.loads(request.body)['supportTicketDetails'] if 'supportTicketDetails' in json.loads(request.body) else ""
        supportTicketDetails=json.loads(supportTicketDetails)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        responseList=loop.run_until_complete(getResponseList(crNumber,lang))
        loop.close()
        if responseList[0].ok and responseList[1].ok:
            report=''
            try:
                report=(json.loads(json.dumps(xmltodict.parse(responseList[0].content))))["s:Envelope"]["s:Body"]["BuyReportByCRNumberResponse"]["Report"]
            except:
                try:
                    queryMessage=(json.loads(json.dumps(xmltodict.parse(responseList[0].content))))["s:Envelope"]["s:Body"]["BuyReportByCRNumberResponse"]["TransactionResponse"]["Result"]
                    queryMessage=json.dumps(queryMessage).replace('{',"").replace('}',"").replace('"',"")
                    logger.info("b2b noData queryMessage ")
                    logger.info(queryMessage)
                    supportTicketDetails["supportTicketDetails"]["queries"]=queryMessage[:500]
                    logger.info("b2b noData supportTicketDetails ")
                    logger.info(supportTicketDetails)
                except:
                    supportTicketDetails["queries"]="TransactionResponse Result not found"
                    logger.info("b2b noData supportTicketDetails ")
                    logger.info(supportTicketDetails)
                r=requests.post(CONTACT_US_POST_URL,params={"hasIssueinB2B":"Y"}, data=json.dumps(supportTicketDetails),headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False) 
                return JsonResponse({'isB2BFailed':True})
            birDataObj=(json.loads(json.dumps(xmltodict.parse(report))))['Product']['BIRDATA']['BUS_HIGH']
            birDataIdObj=birDataObj['ID']
            birDataHLObj=birDataObj['HL']
            phone=[]
            if 'MOL_FTN_T' in birDataIdObj:
                phone.append(getConcatString('MOL_FTN_T','@VAL',birDataIdObj))
            if 'MCI_FTN_T' in birDataIdObj:
                phone.append(getConcatString('MCI_FTN_T','@VAL',birDataIdObj))
            if 'BAY_FTN_MT' in birDataIdObj:
                phone.append(getConcatString('BAY_FTN_MT','@VAL',birDataIdObj))
            paidUpCapital=""
            numberOfBranches=""
            if 'CA' in birDataHLObj:
                if '@PSCA' in birDataHLObj['CA']:
                    paidUpCapital=birDataHLObj['CA']['@PSCA']
            if '@TOT_BRA' in birDataHLObj:
                numberOfBranches=birDataHLObj['@TOT_BRA']

            resultObj={
                'mci':{
                    'companyName':birDataIdObj['@CN'] if '@CN' in birDataIdObj else "",
                    'companyAddress':",".join(birDataIdObj['CUHA'].values()),
                    'crNumber':birDataIdObj['@RC']  if '@RC' in birDataIdObj else "",
                    'legalForm':birDataIdObj['@LFC_DESC']  if '@LFC_DESC' in birDataIdObj else "",
                    'paidUpCapital':paidUpCapital,
                    'registerationDate':birDataIdObj['@RD'] if '@RD' in birDataIdObj else "",
                    'registerationExpiryDate':birDataIdObj['@RED']  if '@RED' in birDataIdObj else "",
                    'registrationStatus':birDataIdObj['@OSC_DESC'] if '@OSC_DESC' in birDataIdObj else "",
                    'numberOfBranches':numberOfBranches
                },
                'contactDetails':{
                    'faxNumber':birDataIdObj['MCI_FTN_F']['@VAL'] if 'MCI_FTN_F' in birDataIdObj else "",
                    'phone':",".join(phone),
                    'website':getConcatString('MCI_VL_W','@VAL',birDataIdObj) if 'MCI_VL_W' in birDataIdObj else "",
                    'email':getConcatString('MCI_VL_E','@VAL',birDataIdObj)  if 'MCI_VL_E' in birDataIdObj else ""
                }
            }
            financialStatementAvailable=False
            try:
                financialStatementAvailable=json.loads(json.dumps(xmltodict.parse(responseList[1].content)))["s:Envelope"]["s:Body"]["SearchByCRNumberResponse"]["CompanyList"]["CompanyItem"]["FinancialStatementAvailable"]
            except:
                financialStatementAvailable=json.loads(json.dumps(xmltodict.parse(responseList[1].content)))["s:Envelope"]["s:Body"]["SearchByCRNumberResponse"]["CompanyList"]["CompanyItem"][0]["FinancialStatementAvailable"]
            result=[None]*1
            result[0]={'smeFormDetails':{'formInfo':{},'lookupInfo':{}}}
            if financialStatementAvailable==True or financialStatementAvailable=='true':
                user=SessionDetails.objects.get(username=request.user)
                userDetails=UserDetails.objects.get(uid=user.uid)
                data=json.dumps({'crNumbers':crNumber,"isSaveDraft":isSaveDraft,"nationalId":str(userDetails.national_id)})
                smeFormResponse = requests.post(SME_FORM_URL,data=data,headers={'Appian-API-Key': APPIAN_KEY_VALUE},verify=False)
                if smeFormResponse.ok:
                    result=smeFormResponse.json()
                    result[0]['smeFormDetails']['formInfo']['feTempFolderName']=""
                    result[0]['smeFormDetails']['formInfo']['feFolderName']=""
                else:
                    logger.info("appian error ")
                    logger.info(smeFormResponse.content)

                if isCreateFromStart:
                    try:
                        filesData = json.dumps({'crNumber':crNumber,"isCreateFromStart":isCreateFromStart,"nationalId":str(userDetails.national_id)})
                        fileDeletionResponse = requests.post(APPIAN_REMOVE_DOCUMENT_URL,data=filesData,headers={'Appian-API-Key': APPIAN_KEY_VALUE},verify=False)
                        logger.info("files deletion response")
                        logger.info(fileDeletionResponse.content)
                    except:
                        pass
            else:
                lookUpResponse = requests.post(FS_FALSE_LOOKUP_URL,headers={'Appian-API-Key': APPIAN_KEY_VALUE},verify=False)
                if lookUpResponse.ok:
                    result[0]['smeFormDetails']['lookupInfo']=lookUpResponse.json()[0]
            result[0]['smeFormDetails']['formInfo']['financialStatement']=financialStatementAvailable
            result[0]['smeFormDetails']['formInfo']['corporateDetails']=resultObj
            return JsonResponse(result[0],safe=False)
            
        else:
            logger.info("b2b failed ")
            logger.info(responseList[0].content)
            logger.info(responseList[1].content)
            try:
                queryMessage=(json.loads(json.dumps(xmltodict.parse(responseList[0].content))))["s:Envelope"]["s:Body"]["BuyReportByCRNumberResponse"]["TransactionResponse"]["Result"]
                logger.info("b2b queryMessage ")
                logger.info(queryMessage)
                queryMessage=json.dumps(queryMessage).replace('{',"").replace('}',"").replace('"',"")
                supportTicketDetails["supportTicketDetails"]["queries"]=queryMessage[:500]
                logger.info("b2b supportTicketDetails ")
                logger.info(supportTicketDetails)
            except:
                supportTicketDetails["queries"]="TransactionResponse Result not found"
                logger.info("b2b supportTicketDetails ")
                logger.info(supportTicketDetails)
            r=requests.post(CONTACT_US_POST_URL,params={"hasIssueinB2B":"Y"}, data=json.dumps(supportTicketDetails),headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False) 
            return JsonResponse({'isB2BFailed':True})
    else:
        return JsonResponse({'isReload':True}, safe=False)

@csrf_exempt
@require_POST
def postSurveyForm(request):
    if request.user.is_authenticated:
        data=json.loads(request.body)
        logger.info('sme form post data ---')
        logger.info(data)
        feTempFolderName=''
        if 'requestorDetails' in data and data['requestorDetails']['hasFinancialStatements']:
            try:
                if data['deleteFileList']:
                    logger.info("file deletion call starts")
                    fileDeletionResponse=requests.post(APPIAN_REMOVE_DOCUMENT_URL,data=json.dumps({"documents":data['deleteFileList']}), headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)
                    logger.info("file deletion call ends")
                    logger.info(fileDeletionResponse.content)    
            except:
                logger.info("File deletion appian call error")
                
            del data['deleteFileList']
        logger.info('sme form posting to appian starts')
        response=requests.post(POST_MTS_DETAILS_URL,data=json.dumps(data), headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)
        finalResponse={}
        logger.info('sme form posting to appian ends')
        logger.info(response.content)
        try:
            finalResponse=response.json()
            finalResponse['messageInfo']['isError']=True
            if 'statusCode' in finalResponse:
                if finalResponse['statusCode'] == '000' or finalResponse['statusCode'] == '006':
                    finalResponse['messageInfo']['isError']=False
                    logger.info('sme post success ---')
                del finalResponse['statusCode']
            if 'description' in finalResponse:
                del finalResponse['description']
            logger.info('sme post response ---')
            logger.info(finalResponse)
            return JsonResponse(finalResponse,safe=False)
        except:
            finalResponse=response.content
            messageInfo=MESSAGE_INFO
            messageInfo['isError']=True
            logger.info('sme post error')
            logger.info(finalResponse)
            return JsonResponse({'messageInfo':MESSAGE_INFO})
    else:
        logger.info("unauthorised --")
        return JsonResponse({'isReload':True}, safe=False)

@csrf_exempt
@require_POST
def postDraftSurveyForm(request):
    if request.user.is_authenticated:
        data=json.loads(request.body)
        logger.info('sme form save draft data ---')
        logger.info(data)
        try:
            if data['deleteFileList']:
                logger.info("file deletion call starts")
                fileDeletionResponse=requests.post(APPIAN_REMOVE_DOCUMENT_URL,data=json.dumps({"documents":data['deleteFileList']}), headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)
                logger.info("file deletion call ends")
                logger.info(fileDeletionResponse.content)    
        except:
            logger.info("File deletion appian call error")
        del data['deleteFileList']
        logger.info('sme save draft posting to appian starts')
        response=requests.post(POST_MTS_DRAFT_DETAILS,data=json.dumps(data), headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)
        finalResponse={}
        logger.info('sme save draft posting to appian ends')
        logger.info(response.content)
        try:
            finalResponse=response.json()
            finalResponse['messageInfo']['isError']=True
            if 'statusCode' in finalResponse:
                if finalResponse['statusCode'] == '000':
                    finalResponse['messageInfo']['isError']=False
                    logger.info('sme save draft success ---')
                del finalResponse['statusCode']
            if 'description' in finalResponse:
                del finalResponse['description']
            logger.info('sme post response ---')
            logger.info(finalResponse)
            return JsonResponse(finalResponse,safe=False)
        except:
            finalResponse=response.content
            messageInfo=MESSAGE_INFO
            messageInfo['isError']=True
            logger.info('sme save draft error')
            logger.info(finalResponse)
            return JsonResponse({'messageInfo':MESSAGE_INFO})
    else:
        logger.info("unauthorised --")
        return JsonResponse({'isReload':True}, safe=False)

@require_GET
def getUploadedDocument(request,docId):
    if request.user.is_authenticated:
        requestsResponse = requests.get(DOWNLOAD_URL+docId+'/', headers={'Appian-API-Key': APPIAN_KEY_VALUE}, verify=False)
        if requestsResponse.ok:
            response=HttpResponse(requestsResponse.content,content_type=requestsResponse.headers['content-type'])
            response['Content-Disposition'] = requestsResponse.headers['content-disposition']
        else:
            response=requestsResponse.content
        return response
    else:
        # template='sme/landingPage.html'
        # return render(request, template, getFooterDetails())
        return redirect(LANDING_URL)

@csrf_exempt	
@require_POST	
def uploadDocument(request):	
    if request.user.is_authenticated:	
        uploadedFiles = request.FILES.getlist('file')	
        documentDetails=[None] * len(uploadedFiles)	
        for i,fileObj in enumerate(uploadedFiles):	
            url = APPIAN_UPLOAD_DOCUMENT_URL	
            responseDetail = requests.post(url, data=fileObj,headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json','Appian-Document-Name':fileObj.name}, verify=False) 	
            if responseDetail.ok:	
                documentDetails[i] = responseDetail.json()	
            else:	
                logger.info("appian document upload error")	
        return JsonResponse(documentDetails,safe=False)
    else:
        # template='sme/landingPage.html'
        # return render(request, template, getFooterDetails())
        return redirect(LANDING_URL)

@csrf_exempt	
@require_POST	
def removeDocumentFolder(request):	
    if request.user.is_authenticated:	
        try:	
            logger.info("on cancel click - file deletion call starts")	
            fileDeletionResponse=requests.post(APPIAN_REMOVE_DOCUMENT_URL,data=json.dumps(json.loads(request.body)), headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)	
            logger.info("on cancel click - file deletion call ends")	
            logger.info(fileDeletionResponse.content)   	
            return HttpResponse('Success') 	
        except:	
            logger.info("on cancel click - File deletion appian call error")	
            return JsonResponse('Invalid request',safe=False)	
    else:	
        # template='sme/landingPage.html'
        # return render(request, template, getFooterDetails())
        return redirect(LANDING_URL)
    

@csrf_exempt
@require_POST
def postContactForm(request):
    if request.user.is_authenticated:
        url = CONTACT_US_POST_URL
        result = json.loads(request.body)
        responseDetail = requests.post(url, data=json.dumps(result),headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False) 
        if responseDetail.ok:
            response = responseDetail.json()
            editedRes = editedResponse(response)
            editedRes["status_code"]= 200
            return JsonResponse(editedResponse(response), safe=False)
        res = {"messageInfo":MESSAGE_INFO}
        res["status_code"] = 500
        return JsonResponse(res, safe=False)
        
    else:
        return JsonResponse({'isReload':True}, safe=False)

@require_GET
def removeLoggedoutUser(request):
    if request.GET.get('key')==AUTHORISATION_KEY:
        SessionDetails.objects.exclude(action_by=None).delete()
        return HttpResponse(REMOVED_USERS)
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)

def getFooterDetails():
    footerDetails=requests.post(GET_MTS_DETAILS_URL+'contactDetails', headers={'Appian-API-Key': APPIAN_KEY_VALUE}, verify=False)
    if footerDetails.ok:
        footerDetails=footerDetails.json()[0]
        contactDetails=footerDetails['contactDetails']
        del contactDetails['validations']
        formInfo=contactDetails['formInfo']
        del formInfo['supportTypeNames']
        return {"footer_details":json.dumps(footerDetails['contactDetails'])}
    else:
        footerDetails={'messageInfo':MESSAGE_INFO}

@csrf_exempt
@require_POST
def getFolderList(request):
    data=json.loads(request.body)
    dir_path=FILE_UPLOAD_LOCATION
    folder_list=data['folderList']
    older_than=60*60*24*data['days']
    if request.GET.get('key')==AUTHORISATION_KEY:
        try:
            time_now = _time()
            for folder in os.listdir(dir_path):
                if (time_now - os.path.getctime(dir_path+folder)) > older_than:
                    if folder not in folder_list:
                        shutil.rmtree(str(dir_path+folder))
            return HttpResponse(CLEANED_FOLDERS)
        except:
            return HttpResponse(SERVICE_UNAVAILABLE)
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)
