#charts Lib loc
WKHTML_TO_PDF_PATH='C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe'
WKHTML_TO_IMAGE_PATH='C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltoimage.exe'

KEY_MISMATCH_STRING='Key Mismatch'

# b2b credentials
B2B_USERNAME = 'Momuser2'
B2B_PASSWORD = 'Password@062'

#user details and delete logout user key and chart
AUTHORISATION_KEY="dbh1i21m127gua52ac1g47h5t"

#bayan url

BAYAN_BASE_URL = 'https://a2a-itrade.bayancb.com/'


#sso url

SSO_TOKEN_URL='https://profile.monshaat.gov.sa/oauth2/token'

SSO_PROFILE_URL="https://profile.monshaat.gov.sa/api/user/profile"

SSO_CR_LIST_URL="https://profile.monshaat.gov.sa/api/v1.0/crList/sme"


#sso credentials

CLIENT_ID="monshati360_production"
CLIENT_SECRET="ByMonshaatToMonshati360Prod"


APPIAN_KEY_VALUE='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJiZTQ1ZDk1YS1jNWJjLTQ3ZDctOGJlMi1lODFjNjY1NmFiZmQifQ.OTWMxXQH7yRHwGzjuwDEe3WIh2zs4CS1TJa0swcW2ds'
BASE_URL= 'https://admin.monshati360.sa/suite/webapi/'

REDIRECT_URL="https://online.monshati360.sa/service/"

LANDING_URL="https://monshati360.sa/"
