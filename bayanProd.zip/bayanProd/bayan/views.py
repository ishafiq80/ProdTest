from django.http.response import JsonResponse
from django.shortcuts import render

MESSAGE_INFO_500 = {
            "messageInfo":{
            "code":"500",
            "english": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle": "Internal Server Error",
                "messageDescription": "The request was not completed. The server meet an unexpected condition.",
                "btnText":"Return to home"
            },
            "arabic": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle":"خطأ داخلي في النظام",
                "messageDescription":"لم يتم إكمال الطلب. يواجه النظام حالة غير متوقعة.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }}
        }

MESSAGE_INFO_404 = {
            "messageInfo":{
            "code":"404",
            "english": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle": "Page Not Found",
                "messageDescription": "The server cannot find the requested page.",
                "btnText":"Return to home"
            },
            "arabic": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle":"لم يتم العثور على الصفحة",
                "messageDescription":"يتعذر على النظام العثور على الصفحة المطلوبة.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }}
        }

MESSAGE_INFO_403 = {
            "messageInfo":{
            "code":"403",
            "english": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle": "Permission Denied",
                "messageDescription": "Access is forbidden to the requested page.",
                "btnText":"Return to home"
            },
            "arabic": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle":"تم رفض الطلب",
                "messageDescription":"تم حظر الوصول إلى الصفحة المطلوبة.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }}
        }

MESSAGE_INFO_400 = {
            "messageInfo":{
            "code":"400",
            "english": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle": "Bad Request",
                "messageDescription": "Sorry, it appears that an invalid request is being sent.",
                "btnText":"Return to home"
            },
            "arabic": {
                "languageArabic": "باللغة العربية",
                "languageEnglish": "English",
                "messageTitle":"الطلب غير ملائم!",
                "messageDescription":"عذرًا، يبدو أنه يتم إرسال طلب غير صالح.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }}
        }


def handler500(request):
    return render(request,'m360/error.html',{"data":MESSAGE_INFO_500},status=500)


def handler404(request, exception):
    return render(request,'m360/error.html',{"data":MESSAGE_INFO_404},status=404)

def handler403(request, exception):
    return render(request,'m360/error.html',{"data":MESSAGE_INFO_403},status=403)

def handler400(request, exception):
    return render(request,'m360/error.html',{"data":MESSAGE_INFO_400},status=400)