from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from django.views.decorators.http import require_POST
import requests,json
from bayan.constants import APPIAN_KEY_VALUE
from m360.constants import MESSAGE_INFO,SURVEY_GET,SURVEY_POST
from m360.utils import editedResponse

def getFormSchema(hash):

    url = SURVEY_GET
    responseDetail = requests.get(url, params={'hash': hash}, headers={'Appian-API-Key':APPIAN_KEY_VALUE}, verify=False)
    if responseDetail.ok:
        return editedResponse(responseDetail.json())
    else:
        return MESSAGE_INFO


@csrf_exempt
@require_POST
def postFormSchema(request):

    url = SURVEY_POST
    result = json.loads(request.body)
    responseDetail = requests.post(url, data=json.dumps(result),headers={'Appian-API-Key': APPIAN_KEY_VALUE, 'Content-Type': 'application/json'}, verify=False)
    response = responseDetail.json()
    if responseDetail.ok:
        return JsonResponse(editedResponse(response), safe=False)
    else:
        return JsonResponse(MESSAGE_INFO, safe=False)
    