let resultDataList = []
let isFormValid = true;
let elementsCount;
let isErrorExist = false

let resultData = {

   "surveyQuestionMasterId": null,
   "surveyAnsLookupId": null,
   "comments": null
}

function createm360ResponseCard() {
   let messageContainer = document.createDocumentFragment();

   let divContainer = document.createElement("div");
   divContainer.classList.add("row")

   let messageDivContainer = document.createElement("div");
   messageDivContainer.classList.add('error-info')
   messageDivContainer.classList.add('col-12')

   let titleContainer = document.createElement("h3");
   titleContainer.classList.add('mb-1')
   titleContainer.setAttribute("id", "title")

   let messageTextContainer = document.createElement("p");
   messageTextContainer.classList.add("mb-5")
   messageTextContainer.setAttribute("id", "subText")

   messageDivContainer.append(titleContainer)
   messageDivContainer.append(messageTextContainer)

   divContainer.append(messageDivContainer)
   messageContainer.append(divContainer)

   document.getElementById("responseCard").appendChild(messageContainer);
}
function createm360SuccessResponseCard(data) {
   let responseContainer = document.createDocumentFragment();

   let divContainer = document.createElement("div");
   divContainer.classList.add("card-body")
   divContainer.classList.add("mb-5");
   divContainer.classList.add("mt-5");

   let title = document.createElement("h4");
   title.classList.add('warning-text-color')
   title.classList.add('title')
   title.setAttribute("id", "successTitle")
   title.innerHTML = data.messageInfo[lang].messageTitle

   let subText = document.createElement("p");
   subText.classList.add("card-text")
   subText.setAttribute("id", "successSubText")
   subText.innerHTML = data.messageInfo[lang].messageDescription

   divContainer.append(title);
   divContainer.append(subText);


   responseContainer.append(divContainer);

   document.getElementById("responseSuccessCard").appendChild(responseContainer);
}

function resetAllInputs(obj) {

   let parentId = obj.prop("id")
   let inputType = obj.prop("tagName").toLowerCase()

   if (inputType == 'div') {
      let element = document.getElementById(parentId)
      let elementClass = document.getElementById(parentId).classList;

      if (elementClass.contains('radio-group')) {
         $('.radio-group input[type="radio"]').each(function () {
            $(this).prop('checked', false);
         })


      } else if (elementClass.contains('custom-radio')) {
         $('.custom-radio input[type="radio"]').each(function () {
            $(this).prop('checked', false);
            document.getElementById(this.id).classList.remove("is-invalid")
         })

      }

      else if (elementClass.contains("text-area")) {

         let child;
         for (let i = 0; i < element.children.length; i++) {
            if (element.children[i].tagName.toLowerCase() == "textarea") {
               child = element.children[i]
               child.value = ""
               child.classList.remove('is-invalid')
               child.classList.remove('is-valid')
               break;
            }
         }
      }
   }

   else if (inputType == "select") {

      $('select').prop('selectedIndex', 0)
      $(obj).val(null).trigger('change');
      document.getElementById(parentId).nextElementSibling.classList.remove("is-invalid")
   }

   $('#form .error-color').each(function (key, value) {
      $(this).addClass("d-none")
   })


}

function onClickEventListener(e, resultObj) {
   let element = e.target
   let inputType = element.tagName.toLowerCase()
   let elementId = element.id
   let elementClass = element.classList;
   let errorElement;

   switch (inputType) {
      case "input":
         elementClass = e.currentTarget.classList

         if (elementClass.contains("radio-group")) {
            let currentTargetId = e.currentTarget.id
            let currentTarget = e.currentTarget
            if (currentTarget.nextElementSibling.id == "ratingErrorText") {
               errorElement = currentTarget.nextElementSibling
            }

            let isRatingBarValid = validateRatingBar(currentTargetId, currentTarget, errorElement)

            isFormValid = isRatingBarValid

            if (isRatingBarValid) {
               let ansId = $('.' + currentTargetId + ' input[type=radio]:checked').prop('id').replace(/[^0-9]/g, '')
               resultObj["surveyQuestionMasterId"] = parseInt(currentTargetId)
               resultObj["surveyAnsLookupId"] = parseInt(ansId)
            }
         }
         else if (elementClass.contains("custom-radio")) {

            let currentTargetId = e.currentTarget.id
            let currentTarget = e.currentTarget

            if (currentTarget.lastChild.id == "radioErrorText") {
               errorElement = currentTarget.lastChild
            }

            let isRadioGroupValid = validateRadioButtonGroup(currentTargetId, currentTarget, errorElement)
            isFormValid = isRadioGroupValid

            if (isRadioGroupValid) {
               let ansId = $('.' + currentTargetId + ' input[type=radio]:checked').prop('id').replace(/[^0-9]/g, '')
               resultObj["surveyQuestionMasterId"] = parseInt(currentTargetId)
               resultObj["surveyAnsLookupId"] = parseInt(ansId)
            }
         }
         break;

      case "select":
         let selectErrorElementId = $("#" + element.id).nextAll("#selectErrorText")[0].id;

         if (selectErrorElementId == "selectErrorText") {
            errorElement = $("#" + element.id).nextAll("#selectErrorText")[0]
         }

         let isSelectFieldValid = validateSelect(elementId, element, errorElement)
         isFormValid = isSelectFieldValid

         if (isSelectFieldValid) {
            let ansId = $("." + elementId + " select option:selected").prop("id").replace(/[^0-9]/g, '')
            resultObj["surveyQuestionMasterId"] = parseInt(elementId)
            resultObj["surveyAnsLookupId"] = parseInt(ansId)
         }
         break;

      case "textarea":

         let currentTargetId = e.currentTarget.id
         let errorElementId = element.nextElementSibling.id;
         if (errorElementId == "textAreaErrorText") {
            errorElement = element.nextElementSibling;
         }
         let isTextAreaValid = validateTextArea(currentTargetId, element, errorElement)
         isFormValid = isTextAreaValid

         if (isTextAreaValid) {
            resultObj["surveyQuestionMasterId"] = parseInt(currentTargetId)
            resultObj["comments"] = element.value
         }
         break;
      default:
         break;
   }

}

function getFormSchema(data) {

   let sections = data.questionDetails
   let formBody = document.createDocumentFragment();
   let counter = -1
   let rowContainer;


   $.each(sections, function (key, value) {

      let sectionInfo = value.sectionInfo[lang]

      let sectionContainer = document.createElement("div");
      sectionContainer.classList.add("mt-3");
      sectionContainer.classList.add("pb-4");

      let sectionTitle = document.createElement("h5");
      sectionTitle.classList.add("section-title")
      sectionTitle.classList.add("primary-color")
      sectionTitle.innerHTML = sectionInfo.sectionName;

      let sectionInstructions = document.createElement("p");
      sectionInstructions.classList.add("mb-4")
      sectionInstructions.classList.add("mt-2")
      sectionInstructions.setAttribute("style","font-size:16px")
      sectionInstructions.innerHTML = sectionInfo.sectionInstructions

      sectionContainer.append(sectionTitle);
      sectionContainer.append(sectionInstructions);



      $.each(value.questions, function (key1, value1) {

         let questionInfo = value1.questionInfo[lang]

         let questionType = value1.questionType;
         let questionTitle = questionInfo.questionName;
         let questionId = value1.questionId;
         let isFieldMandatory = value1.isMandatory
         let questionInstructions = value1.questionInstructions

         resultDataList.push(JSON.parse(JSON.stringify(resultData)))

         if ((key1) % 2 == 0) {
            rowContainer = document.createElement("div");
            rowContainer.classList.add("row");
            rowContainer.classList.add("mt-4");
            sectionContainer.append(rowContainer)
         }

         if (questionType == "drop-down") {

            let selectContainer = document.createElement("div");
            selectContainer.classList.add("col-sm-12")
            selectContainer.classList.add("col-md-6")
            selectContainer.classList.add("col-lg-6")
            selectContainer.classList.add("col-12")
            selectContainer.classList.add("mt-sm-4")
            selectContainer.classList.add("mt-md-0")
            selectContainer.classList.add("mt-lg-0")
            selectContainer.classList.add("mt-4")
            selectContainer.classList.add(questionId)

            let titleDiv = document.createElement("div");
            titleDiv.classList.add("d-inline-flex")
            titleDiv.classList.add("align-items-center")
            titleDiv.classList.add("w-100")

            let label = document.createElement('h5');
            label.classList.add("card-title")
            label.innerHTML = questionTitle

            let imgTooltip = document.createElement("img")
            imgTooltip.src = imgTooltipSrc
            imgTooltip.classList.add("img-tooltip")

            let tooltip = document.createElement("a")
            tooltip.setAttribute("href", "#")
            tooltip.setAttribute("data-toggle", "tooltip")
            tooltip.setAttribute("data-placement", "top")
            tooltip.setAttribute("title", questionInfo.questionInstructions)

            tooltip.append(imgTooltip)

            titleDiv.append(label)

            if (!isEmpty(questionInstructions)) {
               titleDiv.append(tooltip)
            }

            let errorText = document.createElement("p")
            errorText.setAttribute("id", "selectErrorText")
            errorText.classList.add("pt-3")
            errorText.classList.add('error-color')
            errorText.classList.add('d-none')
            errorText.innerHTML = lookUpData.validationDrop

            let select = document.createElement('select');
            select.classList.add('DS');
            select.classList.add('select2');
            select.classList.add('dropdown');
            select.classList.add('form-control');
            select.classList.add(questionId)
            select.classList.add('field-reset')
            if (isFieldMandatory) {
               select.classList.add('field-validate')
               label.classList.add('required')

            }
            select.setAttribute("id", questionId)
            select.setAttribute("style", "width:inherit")

            let resObj = resultDataList[++counter]

            $(select).on("change", function (event) {

               onClickEventListener(event, resObj)
            });
            let options = questionInfo.questionOptions;
            let optionIds = value1.questionOptionsIds;

            var optionElement = new Option(lookUpData.dropdownPlaceholder, "", false, false)
            optionElement.setAttribute("style", "width:inherit")
            select.append(optionElement)

            $.each(options, function (key2, value2) {


               var newOption = new Option(value2, "", false, false);
               newOption.title = value2
               newOption.setAttribute("style", "width:inherit")
               $(select).append(newOption);

            })

            $.each(optionIds, function (key, optionValue) {
               select.options[key + 1].setAttribute("id", "option" + optionIds[key])
            })
            selectContainer.append(titleDiv)

            selectContainer.append(select)

            $(select).select2({
               minimumResultsForSearch: -1,
               dropdownParent: $(selectContainer),
               dropdownPosition: 'below'
            })
            
            selectContainer.append(errorText)

            rowContainer.append(selectContainer)


         }

         else if (questionType == "rating") {

            let ratingContainer = document.createElement("div");
            ratingContainer.classList.add("col-sm-12")
            ratingContainer.classList.add("col-md-6")
            ratingContainer.classList.add("col-lg-6")
            ratingContainer.classList.add("col-12")
            ratingContainer.classList.add("mt-sm-4")
            ratingContainer.classList.add("mt-md-0")
            ratingContainer.classList.add("mt-lg-0")
            ratingContainer.classList.add("mt-4")
            ratingContainer.classList.add(questionId)


            let titleDiv = document.createElement("div");
            titleDiv.classList.add("d-inline-flex")
            titleDiv.classList.add("align-items-center")
            titleDiv.classList.add("w-100")

            let label = document.createElement('h5');
            label.classList.add("card-title")
            label.innerHTML = questionTitle

            let imgTooltip = document.createElement("img")
            imgTooltip.src = imgTooltipSrc
            imgTooltip.classList.add("img-tooltip")

            let tooltip = document.createElement("a")
            tooltip.setAttribute("href", "#")
            tooltip.setAttribute("data-toggle", "tooltip")
            tooltip.setAttribute("data-placement", "top")
            tooltip.setAttribute("title", questionInfo.questionInstructions)

            tooltip.append(imgTooltip)

            titleDiv.append(label)
            if (!isEmpty(questionInstructions)) {
               titleDiv.append(tooltip)
            }

            let sliderContainer = document.createElement("div");
            sliderContainer.classList.add("rating")
            sliderContainer.classList.add("radio-group")
            sliderContainer.classList.add("field-reset")
            if (isFieldMandatory) {
               sliderContainer.classList.add("field-validate")
               label.classList.add('required')
            }
            sliderContainer.setAttribute("id", questionId)

            let resObj = resultDataList[++counter]
            sliderContainer.addEventListener("change", function (event) {
               onClickEventListener(event, resObj)
            })

            let optionIds = value1.questionOptionsIds;

            for (i = optionIds.length; i > 0; i--) {

               let sliderInput = document.createElement("input");
               sliderInput.setAttribute("type", "radio");
               sliderInput.setAttribute("name", "ratingPill" + questionId);
               sliderInput.setAttribute("id", "rate" + optionIds[i - 1])

               let sliderLabel = document.createElement("label");
               sliderLabel.setAttribute("for", "rate" + optionIds[i - 1]);
               sliderLabel.classList.add("pill")

               let sliderLabelValue = document.createElement("div")
               sliderLabelValue.innerHTML = i

               sliderLabel.append(sliderLabelValue);
               sliderContainer.append(sliderInput);
               sliderContainer.append(sliderLabel);
            }

            let errorText = document.createElement("p")
            errorText.setAttribute("id", "ratingErrorText")
            errorText.classList.add("pt-3")
            errorText.classList.add('error-color')
            errorText.classList.add('d-none')
            errorText.innerHTML = lookUpData.validationRating

            ratingContainer.append(titleDiv)
            ratingContainer.append(sliderContainer)
            ratingContainer.append(errorText)

            rowContainer.append(ratingContainer)

         }

         else if (questionType == "radio") {

            let radioContainer = document.createElement("div");
            radioContainer.classList.add("col-sm-12")
            radioContainer.classList.add("col-md-6")
            radioContainer.classList.add("col-lg-6")
            radioContainer.classList.add("col-12")
            radioContainer.classList.add("mt-sm-4")
            radioContainer.classList.add("mt-md-0")
            radioContainer.classList.add("mt-lg-0")
            radioContainer.classList.add("mt-4")
            radioContainer.classList.add(questionId)

            radioContainer.classList.add("field-reset")
           
            radioContainer.setAttribute("id", questionId)

            let resObj = resultDataList[++counter]

            let titleDiv = document.createElement("div");
            titleDiv.classList.add("d-inline-flex")
            titleDiv.classList.add("align-items-center")
            titleDiv.classList.add("w-100")

            let label = document.createElement('h5');
            label.classList.add("card-title")
            label.innerHTML = questionTitle

            if (isFieldMandatory) {
               radioContainer.classList.add("field-validate")
               label.classList.add('required')
            }

            let imgTooltip = document.createElement("img")
            imgTooltip.src = imgTooltipSrc
            imgTooltip.classList.add("img-tooltip")

            let tooltip = document.createElement("a")
            tooltip.setAttribute("href", "#")
            tooltip.setAttribute("data-toggle", "tooltip")
            tooltip.setAttribute("data-placement", "top")
            tooltip.setAttribute("title", questionInfo.questionInstructions)

            tooltip.append(imgTooltip)

            titleDiv.append(label)
            if (!isEmpty(questionInstructions)) {
               titleDiv.append(tooltip)
            }

            radioContainer.addEventListener("change", function (event) {
               onClickEventListener(event, resObj)
            })

            radioContainer.append(titleDiv);
            let options = questionInfo.questionOptions;
            let optionsId = value1.questionOptionsIds;

            let errorText = document.createElement("p")
            errorText.setAttribute("id", "radioErrorText")
            errorText.classList.add("pt-3")
            errorText.classList.add('error-color')
            errorText.classList.add('d-none')
            errorText.innerHTML = lookUpData.validationRadio


            for (i = 0; i < options.length; i++) {
               let radioBtnContainer = document.createElement("div");
               radioBtnContainer.classList.add("custom-control");
               radioContainer.classList.add("custom-radio");
               radioBtnContainer.classList.add("custom-control-inline");

               let radioButton = document.createElement("input");
               radioButton.classList.add("custom-control-input");
               radioButton.setAttribute("type", "radio");
               radioButton.setAttribute("id", "radio" + optionsId[i]);
               radioButton.setAttribute("name", "radioBtn" + questionId);

               let radioBtnLabel = document.createElement("label");
               radioBtnLabel.setAttribute("for", "radio" + optionsId[i]);
               radioBtnLabel.innerHTML = options[i];
               radioBtnLabel.classList.add("custom-control-label");


               radioBtnContainer.append(radioButton);
               radioBtnContainer.append(radioBtnLabel);
               radioContainer.append(radioBtnContainer);

            }

            radioContainer.append(errorText);
            rowContainer.append(radioContainer);

         }

         else if (questionType == "free-text") {

            let divContainer = document.createElement('div');
            divContainer.classList.add("col-sm-12")
            divContainer.classList.add("col-md-6")
            divContainer.classList.add("col-lg-6")
            divContainer.classList.add("col-12")
            divContainer.classList.add("mt-sm-4")
            divContainer.classList.add("mt-md-0")
            divContainer.classList.add("mt-lg-0")
            divContainer.classList.add("mt-4")



            divContainer.classList.add("field-reset")
            if (isFieldMandatory) {
               divContainer.classList.add("field-validate")
            }
            divContainer.classList.add("text-area")
            divContainer.classList.add(questionId)
            divContainer.setAttribute("id", questionId)

            let resObj = resultDataList[++counter]
            divContainer.addEventListener("change", function (event) {
               onClickEventListener(event, resObj)
            })


            let titleDiv = document.createElement("div");
            titleDiv.classList.add("d-inline-flex")
            titleDiv.classList.add("align-items-center")
            titleDiv.classList.add("w-100")

            let label = document.createElement('div');
            label.classList.add("card-title")
            label.innerHTML = questionTitle

            if (isFieldMandatory) {

               label.classList.add('required')
            }

            let imgTooltip = document.createElement("img")
            imgTooltip.src = imgTooltipSrc
            imgTooltip.classList.add("img-tooltip")

            let tooltip = document.createElement("a")
            tooltip.setAttribute("href", "#")
            tooltip.setAttribute("data-toggle", "tooltip")
            tooltip.setAttribute("data-placement", "top")
            tooltip.setAttribute("title", questionInfo.questionInstructions)

            tooltip.append(imgTooltip)


            titleDiv.append(label)
            if (!isEmpty(questionInstructions)) {
               titleDiv.append(tooltip)
            }

            let textArea = document.createElement('textarea')
            textArea.classList.add("form-control")
            textArea.setAttribute("type", "text");
            textArea.setAttribute("data-gramm_editor", "false");
            textArea.setAttribute("id", questionId);

            let errorText = document.createElement("p")
            errorText.setAttribute("id", "textAreaErrorText")
            errorText.classList.add("pt-3")
            errorText.classList.add('error-color')
            errorText.classList.add('d-none')
            errorText.innerHTML = lookUpData.commentFieldValidation


            divContainer.append(titleDiv)
            divContainer.append(textArea)
            divContainer.append(errorText)

            rowContainer.append(divContainer)
         }

         sectionContainer.append(rowContainer);


      })

      formBody.append(sectionContainer);


   })
   document.getElementById('form').appendChild(formBody);

}

function validateTextArea(parentId, currentObj, error) {
   let isFieldValid;
   let textValue = currentObj.value.trim();
   if (textValue.length == 0 && document.getElementById(parentId).classList.contains("field-validate")) {
      isFieldValid = false
      currentObj.classList.add("is-invalid")
      currentObj.classList.remove("is-valid")
      error.innerHTML = lookUpData.commentFieldRequiredMsg
      error.classList.remove('d-none')
   } else if (textValue.length > COMMENTS_MAX_LENGTH) {
      isFieldValid = false
      currentObj.classList.add("is-invalid")
      currentObj.classList.remove("is-valid")
      error.innerHTML = lookUpData.commentFieldValidation
      error.classList.remove('d-none')
   } else {
      isFieldValid = true
      currentObj.classList.remove("is-invalid")
      currentObj.classList.remove("is-valid")
      if(textValue.length>0){
      currentObj.classList.add("is-valid")
      }
      error.classList.add('d-none')
   }
   return isFieldValid
}

function validateSelect(parentId, currentObj, error) {

   let isFieldValid;
   if ($("." + parentId + " select option:selected").index() == 0) {
      isFormValid = false
      isFieldValid = false
      currentObj.nextElementSibling.classList.add("is-invalid")
      error.classList.remove('d-none')
   } else {
      isFormValid = true
      isFieldValid = true
      currentObj.nextElementSibling.classList.remove("is-invalid")
      error.classList.add('d-none')
   }

   return isFieldValid
}

function validateRatingBar(parentId, currentObj, error) {
   let isFieldValid;

   if ($("." + parentId + " input[type=radio]:checked").length == 0) {
      error.classList.remove('d-none')
      isFormValid = false
      isFieldValid = false
   } else {
      error.classList.add('d-none')
      isFormValid = true
      isFieldValid = true
   }
   return isFieldValid
}

function validateRadioButtonGroup(parentId, currentObj, error) {
   let isFieldValid;
   if ($('.' + parentId + ' input[type=radio]:checked').length == 0) {
      $('.' + parentId + ' .custom-control-input').each(function () {
         this.classList.add("is-invalid")
         error.classList.remove('d-none')
         isFormValid = false
         isFieldValid = false
      })
   }
   else {
      $('.' + parentId + ' .custom-control-input').each(function () {

         isFormValid = true
         isFieldValid = true
         error.classList.add('d-none')
         this.classList.remove("is-invalid")
      })
   }


   return isFieldValid
}

function validateInputs(obj) {

   let parentId = obj.prop("id")
   let inputType = obj.prop("tagName").toLowerCase()
   let currentElementObj = obj[0]
   let errorElement;

   if (inputType == 'div') {
      if (obj.hasClass("radio-group")) {
         if (currentElementObj.nextElementSibling.id == "ratingErrorText") {
            errorElement = currentElementObj.nextElementSibling
            isFormValid = validateRatingBar(parentId, currentElementObj, errorElement)
         }
      }
      else if (obj.hasClass('custom-radio')) {
         if (currentElementObj.lastChild.id == "radioErrorText") {
            errorElement = currentElementObj.lastChild
            isFormValid = validateRadioButtonGroup(parentId, currentElementObj, errorElement)
         }
      }
      else if (obj.hasClass("text-area")) {
         let child;
         let children = obj[0].childNodes;
         for (let i = 0; i < children.length; i++) {
            if (children[i].tagName.toLowerCase() == "textarea") {
               child = children[i]
            }
            if (children[i].id == "textAreaErrorText") {
               errorElement = children[i]
            }
         }
         isFormValid = validateTextArea(parentId, child, errorElement)
      }
   }

   else if (inputType == 'select') {


      let errorElementId = $("#" + currentElementObj.id).nextAll("#selectErrorText")[0].id;

      if (errorElementId == "selectErrorText") {
         errorElement = $("#" + currentElementObj.id).nextAll("#selectErrorText")[0]
      }

      isFormValid = validateSelect(parentId, currentElementObj, errorElement)

   }
   return isFormValid
}

function loadString(lookUpData) {

   document.getElementById("surveyTitleWelcome").innerHTML = lookUpData.welcomeMessage
   document.getElementById("feedbackLabel").innerHTML = lookUpData.fromInstruction
   document.getElementById("startSurveyBtn").innerHTML = lookUpData.startSurvey
   document.getElementById("submitBtn").innerHTML = lookUpData.submit
   document.getElementById("cancelBtn").innerHTML = lookUpData.cancel
   document.getElementById("resetBtn").innerHTML = lookUpData.reset
}

function postSurveyDetails(resultDataList) {

   let timeStamp = new Date();

   let dataToPost = {
      "surveyUserMasterId": data.surveyUserMasterId,
      "responderIdentity": "",
      "surveyResponse": resultDataList
   }

   $("#loaderSection").removeClass("d-none")
   $('#m360MandatoryInstr').addClass("d-none");
   $('#m360requiredInstr').addClass("d-none");
   $("#startSurveyContainer").addClass("d-none");
   $("#formContainer").removeClass("d-none");
   $("#formSection").addClass("d-none")

   $.ajax({
      type: 'POST',
      url: SURVEY_POST_URL,
      data: JSON.stringify(dataToPost),
      success: function (data) {
         $("#responseContainer").addClass("d-none");
         $('#loaderSection').addClass("d-none");
         $("#formContainer").addClass("d-none");
         createm360SuccessResponseCard(data)
         $("#responseSuccessContainer").removeClass('d-none');


      },
      error: function (error) {

         let errorData = COMMON_ERROR_MESSAGE

         $("#responseContainer").removeClass("d-none");
         $('#loaderSection').addClass("d-none");
         $("#formContainer").addClass("d-none");

         document.getElementById("title").innerHTML = errorData.messageInfo[lang].messageTitle
         document.getElementById("subText").innerHTML = errorData.messageInfo[lang].messageDescription
      }
   });
}

$("#surveyContainer").on('click', 'button', function (event) {
   let btnId = this.id;
   switch (btnId) {
      case "startSurveyBtn":
         $("#startSurveyContainer").addClass("d-none");
         $("#responseContainer").addClass("d-none");
         $("#formContainer").removeClass("d-none");

         if ($('#form').children().length == 0) {
            $('#loaderSection').removeClass("d-none");
         }
         break;

      case "arBtn":

         if (localStorage.getItem("lang") != JSON.stringify("arabic")) {
            localStorage.setItem("lang", JSON.stringify("arabic"))
            $("#startSurveyContainer").addClass("d-none")
            $("#formContainer").removeClass("d-none")
            $("#formSection").addClass("d-none")
            $("#loaderSection").removeClass("d-none")
            $("#responseContainer").addClass("d-none")
            $('#m360MandatoryInstr').addClass('d-none')
            window.location.reload()
         }
         break;

      case "engBtn":

         if (localStorage.getItem("lang") != JSON.stringify("english")) {
            localStorage.setItem("lang", JSON.stringify("english"))
            $("#startSurveyContainer").addClass("d-none")
            $("#formContainer").removeClass("d-none")
            $("#formSection").addClass("d-none")
            $("#loaderSection").removeClass("d-none")
            $("#responseContainer").addClass("d-none")
            $('#m360MandatoryInstr').addClass('d-none')
            window.location.reload()
         }
         break;

      case "submitBtn":
         errorCount = 0;
         if (!isErrorExist) {
            $('#form .field-validate').each(function (key, value) {
               isFormValid = validateInputs($(this));
            })
         }

         $('#form .error-color').each(function (key, value) {
            let errorClass = $(this).is(":visible")
            if (errorClass) {
               isErrorExist = true
               errorCount++;
               return;
            }
         })

         if (isFormValid && errorCount == 0) {

            postSurveyDetails(resultDataList)
         }
         break;

      case "cancelBtn":
         errorCount = 0
         isErrorExist = false
         isFormValid = true

         $('#form .field-reset').each(function (key, value) {
            resetAllInputs($(this));
            resultDataList[key]['comments'] = null
            resultDataList[key]['surveyAnsLookupId'] = null
            resultDataList[key]['surveyQuestionMasterId'] = null

         })

         $("#startSurveyContainer").removeClass("d-none");
         $("#formContainer").addClass("d-none");
         $("#responseContainer").addClass("d-none");
         $('#loaderSection').addClass("d-none");
         break;

      case "resetBtn":
         errorCount = 0
         isErrorExist = false
         isFormValid = true

         $('#form .field-reset').each(function (key, value) {
            resetAllInputs($(this));
            resultDataList[key]['comments'] = null
            resultDataList[key]['surveyAnsLookupId'] = null
            resultDataList[key]['surveyQuestionMasterId'] = null

         })
         break;

      default:
         break;

   }
})