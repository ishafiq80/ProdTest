#charts Lib loc
WKHTML_TO_PDF_PATH='C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe'
WKHTML_TO_IMAGE_PATH='C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltoimage.exe'

KEY_MISMATCH_STRING='Key Mismatch'

# b2b credentials
B2B_USERNAME = 'AppianA2AB2B'
B2B_PASSWORD = 'Bayan@2019'

# prod
# B2B_USERNAME = 'Momuser2'
# B2B_PASSWORD = 'Password@062'

#user details and delete logout user key and chart
#dev
# AUTHORISATION_KEY="fed5d99b703baa42ed5e92d0d"

#uat
AUTHORISATION_KEY="asd5d99b703naa42bd5f92o0z"

# pre prod
# AUTHORISATION_KEY="ksj1j90m973lak32bd1f45o6y"

# prod
# AUTHORISATION_KEY="dbh1i21m127gua52ac1g47h5t"

#bayan url
BAYAN_BASE_URL = 'https://test-a2a-itrade.bayancb.com/'
#prod
# BAYAN_BASE_URL = 'https://a2a-itrade.bayancb.com/'


#sso url
SSO_TOKEN_URL='https://sso-test.monshaat.sa/oauth2/token'

SSO_PROFILE_URL="https://sso-test.monshaat.sa/api/user/profile"

SSO_CR_LIST_URL="https://sso-test.monshaat.sa/api/v1.0/crList/sme"

#prod
# SSO_TOKEN_URL='https://profile.monshaat.gov.sa/oauth2/token'

# SSO_PROFILE_URL="https://profile.monshaat.gov.sa/api/user/profile"

# SSO_CR_LIST_URL="https://profile.monshaat.gov.sa/api/v1.0/crList/sme"


#sso credentials
CLIENT_ID="m360_test"
CLIENT_SECRET="SSO_FM360_Bay"

#prod
# CLIENT_ID="monshati360_production"
# CLIENT_SECRET="ByMonshaatToMonshati360Prod"

# dev

# APPIAN_KEY_VALUE = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9''.eyJzdWIiOiJlZWRiYWFiZi1mZjhlLTRiNGMtYmU2My03Nzc3MTFkZjY0ZmQifQ''.kUn8hqJ8TaEf6eUluuKiOKbFxfZf4uR-6SOLwTLJR84'
# BASE_URL = 'https://appiandev.bayan.local/suite/webapi/'

# REDIRECT_URL="https://smeaext-d.bayancb.com/service/"

#uat

APPIAN_KEY_VALUE = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9''.eyJzdWIiOiIxYzkwNzdhYS02MzNiLTQwY2ItOTVlOC05YjMzNWRlYjQ5MTYifQ''.SesTZkEJybKsVXyVgeShmq25xqNMjWVQlbeixJ_fVEg'
BASE_URL= 'https://appianuat.bayancb.com/suite/webapi/'

REDIRECT_URL="https://sme-m360uat.bayancb.com/service/"

# pre prod

# APPIAN_KEY_VALUE='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9''.eyJzdWIiOiJmZmExMzlkZS01MTY2LTQ1NjUtYTZkYi1kM2YwY2FiZWJmYzIifQ''.Ek9UABF6nKV4-lpmsb6KMp5k4d3IsX-_a9T8WvYQ550'
# BASE_URL= 'https://pre-appian.bayancb.com/suite/webapi/'

# REDIRECT_URL="https://sme-m360pre.bayancb.com/service/"

#prod
# APPIAN_KEY_VALUE='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJiZTQ1ZDk1YS1jNWJjLTQ3ZDctOGJlMi1lODFjNjY1NmFiZmQifQ.OTWMxXQH7yRHwGzjuwDEe3WIh2zs4CS1TJa0swcW2ds'
# BASE_URL= 'https://admin.monshati360.sa/suite/webapi/'

# REDIRECT_URL="https://online.monshati360.sa/service/"

LANDING_URL="https://monshati360.sa/"