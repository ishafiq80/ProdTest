function isEmpty(val) {
  switch (val) {
    case "":
    case 0:
    case "0":
    case null:
    case "null":
    case false:
    case "false":
    case undefined:
    case "undefined":
    case typeof (val) === "undefined":
      return true;
    default:
      return false;
  }
};

function isEmptyList(list) {
  if (list.length === 0) return true;
  else return false;
};

function isEmptyObject(obj) {
  if (!isEmpty(obj)) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) return false;
    }
    return true;
  } else {
    return true;
  }
};

function appendLeadingZeroes(n) {
  if (n <= 9) {
    return "0" + n;
  }
  return n
}

function getFormattedDate(dateObj) {
  let dateList=[]
  let day=null;
  let month=null;
  let year=null;
  if(!isEmpty(dateObj)){
    if(dateObj.indexOf('-')>-1){
      dateList=dateObj.split('-')
    }else{
      dateList=dateObj.split('/')
    }
  if(dateList[0].length==4){
    day=dateList[2]
    month=dateList[1]
    year=dateList[0]
  }else{
    day=dateList[0]
    month=dateList[1]
    year=dateList[2]
  }
  day=appendLeadingZeroes(Number(day))
  month=appendLeadingZeroes(Number(month))
  }
  return day + "/" + month + "/" + year
}

function initialiseStorageListener(){
  window.addEventListener('storage', function (e) {
    if(e.key=='pathname'){
        window.clearInterval(idleTimer);
    }
    else if(e.key!='lastActivity'){
        window.location.reload()
    }
});
}

function initialiseIdleListener() {
  
  document.onclick = function () {
    if(!document.getElementById("idleModal").classList.contains('show'))
    idleTimeCounter = 0;
  };
  document.onmousemove = function () {
    if(!document.getElementById("idleModal").classList.contains('show'))
    idleTimeCounter = 0;
  };
  document.onkeypress = function () {
    if(!document.getElementById("idleModal").classList.contains('show'))
    idleTimeCounter = 0;
  };
  if (document.hasFocus()) {
    $("#idleModal").modal("hide")
    idleTimeCounter = 0;
    window.clearInterval(idleTimer);
    idleTimer = window.setInterval(idleTimeLogout, 1000);
    if (localStorage.getItem("pathname") == window.location.pathname)
      localStorage.setItem("pathname", window.location.pathname + '/')
    else
      localStorage.setItem("pathname", window.location.pathname)
    }

    window.addEventListener("focus", function(event) { 
    $("#idleModal").modal("hide")
    idleTimeCounter = 0;
    window.clearInterval(idleTimer);
    idleTimer = window.setInterval(idleTimeLogout, 1000);
    if (localStorage.getItem("pathname") == window.location.pathname)
      localStorage.setItem("pathname", window.location.pathname + '/')
    else
      localStorage.setItem("pathname", window.location.pathname)
  });

  window.addEventListener("beforeunload", function(event) { 
    localStorage.setItem("lastActivity",new Date().getTime())
  });
}
function logout(){
  $.ajax({
    beforeSend: function () {
      $('#dashboardContainerSection').addClass('d-none')
      $("#reportSection").addClass("d-none");
      $("#crRecordsSection").addClass("d-none");

      $("#readyloaderContainer").removeClass("d-none");

    },
    type: 'POST',
    url: LOGOUT_URL,
    success: function (data) {
      window.location = SSO_LOGOUT_URL
    },
    complete: function () {
      $("#loaderContainer").addClass("d-none");
    }
  });
}
function idleTimeLogout() {
  idleTimeCounter++;
  localStorage.removeItem('lastActivity')
  if(idleTimeCounter == IDLE_WARNING_TIME){
    $("#idleModal").modal("show")
  }
  if (idleTimeCounter == IDLE_TIMEOUT) {
    idleTimeCounter = 0;
    window.clearInterval(idleTimer);
    logout()
  }
}

function checkIdleLogout(){
  if(!isEmpty(localStorage.getItem('lastActivity'))){
    var diff =(new Date().getTime() - new Date(Number(localStorage.getItem('lastActivity'))).getTime()) / 1000;
    let timeDiff = Math.abs(Math.round(diff));
    if((timeDiff-IDLE_TIMEOUT)>0){
      logout();
    }
  }
}

function createResponseCard(data, elementId) {
  let responseContainer = document.createDocumentFragment();
  let parentContainer = document.createElement("div");
  parentContainer.classList.add("card")
  parentContainer.classList.add("pb-5");
  parentContainer.classList.add("pt-5");

  let divContainer = document.createElement("div");
  divContainer.classList.add("card-body")
  divContainer.classList.add("pb-5");
  divContainer.classList.add("pt-5");

  let title = document.createElement("h4");
  title.classList.add('warning-text-color')
  title.classList.add('warning-title')
  title.setAttribute("id", "title")
  title.innerHTML = data.messageInfo[lang].messageTitle

  let subText = document.createElement("p");
  subText.classList.add("card-text")
  subText.setAttribute("id", "subText")
  subText.innerHTML = data.messageInfo[lang].messageDescription
  divContainer.append(title);
  divContainer.append(subText);

  parentContainer.append(divContainer)
  responseContainer.append(parentContainer);

  document.getElementById(elementId).appendChild(responseContainer);
}

function getQueryString(url) {
  let localUrl = !isEmpty(url) ? url : location.href
  var vars = {};
  var parts = localUrl.replace(/[?&]+([^=&]+)=([^&]*)/gi,
    function (m, key, value) {
      vars[key] = value;
    });
  return vars;
}

function setSearchParams() {

  let params = getQueryString("")
  let prevParams = ''

  if (!isEmptyObject(params)) {
    delete params.code
    delete params.state
     if (!isEmpty(localStorage.getItem('queryParams'))) {
      prevParams = getQueryString(localStorage.getItem('queryParams'))
    
    }
    let queryString = ''
    if (!isEmpty(params[languageQueryString])) {
      delete params[languageQueryString]
      localStorage.setItem("lang", getLanguage())
    }
    else if (!isEmpty(prevParams[languageQueryString])) {
      let langParam = prevParams[languageQueryString].replace(/['"]+/g, '').toLowerCase();
      if (langParam == arLanguageString)
        localStorage.setItem("lang", JSON.stringify("arabic"))
      else
        localStorage.setItem("lang", JSON.stringify("english"))
    }

    if (!isEmptyObject(params)) {
      queryString = "?"
      var keyArray = Object.keys(params);
      for (var i = 0; i < keyArray.length; i++) {
        if (i != 0) {
          queryString += "&"
        }
        queryString = queryString + keyArray[i] + "=" + params[keyArray[i]]
      }
    }

    let newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + queryString;
    window.history.replaceState({}, document.title, newurl);
    localStorage.removeItem('pathname')
    localStorage.removeItem('queryParams')
  }
}

function getLanguage() {
  let params = getQueryString("")
  let langParam = params[languageQueryString]
  if (!isEmpty(langParam))
    langParam = langParam.replace(/['"]+/g, '').toLowerCase();
  if (langParam == arLanguageString)
    return JSON.stringify("arabic")
  return JSON.stringify("english")
}

// prepend polyfill

(function (arr) {

  arr.forEach(function (item) {
    if (item.hasOwnProperty('prepend')) {
      return;
    }
    Object.defineProperty(item, 'prepend', {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function prepend() {
        var argArr = Array.prototype.slice.call(arguments),
          docFrag = document.createDocumentFragment();

        argArr.forEach(function (argItem) {
          var isNode = argItem instanceof Node;
          docFrag.appendChild(isNode ? argItem : document.createTextNode(String(argItem)));
        });

        this.insertBefore(docFrag, this.firstChild);
      }
    });
  });
})([Element.prototype, Document.prototype, DocumentFragment.prototype]);


// append polyfill

(function (arr) {

  arr.forEach(function (item) {
    if (item.hasOwnProperty('append')) {
      return;
    }
    Object.defineProperty(item, 'append', {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function append() {
        var argArr = Array.prototype.slice.call(arguments),
          docFrag = document.createDocumentFragment();

        argArr.forEach(function (argItem) {
          var isNode = argItem instanceof Node;
          docFrag.appendChild(isNode ? argItem : document.createTextNode(String(argItem)));
        });

        this.appendChild(docFrag);
      }
    });
  });
})([Element.prototype, Document.prototype, DocumentFragment.prototype]);

//closest

if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.msMatchesSelector ||
    Element.prototype.webkitMatchesSelector;
}

if (!Element.prototype.closest) {
  Element.prototype.closest = function (s) {
    var el = this;

    do {
      if (el.matches(s)) return el;
      el = el.parentElement || el.parentNode;
    } while (el !== null && el.nodeType === 1);
    return null;
  };
}

// remove 
(function (arr) {

  arr.forEach(function (item) {
    if (item.hasOwnProperty('remove')) {
      return;
    }
    Object.defineProperty(item, 'remove', {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function remove() {
        if (this.parentNode === null) {
          return;
        }
        this.parentNode.removeChild(this);
      }
    });
  });
})([Element.prototype, CharacterData.prototype, DocumentType.prototype]);

//starts With
if (!String.prototype.startsWith) {
  Object.defineProperty(String.prototype, 'startsWith', {
      value: function(search, rawPos) {
          var pos = rawPos > 0 ? rawPos|0 : 0;
          return this.substring(pos, pos + search.length) === search;
      }
  });
}

const IDLE_TIMEOUT = 900; //seconds - 5 minutes

let idleTimeCounter = 0;

let idleTimer = ''

const IDLE_WARNING_TIME=IDLE_TIMEOUT-120; //seconds - (before 2 minutes)

const FILE_UPLOAD_TIMEOUT=120000//seconds - 2min 

const BYTE_CONVERTOR_VALUE=1000000//bytes - 1MB 

const languageQueryString = 'ln'

const engLanguageString = "eng"

const arLanguageString = "ar"

const LANDING_URL="https://monshati360.sa/"
//  #dev
// const REDIRECT_URL="https://smeaext-d.bayancb.com/service/"

//  #uat
const REDIRECT_URL="https://sme-m360uat.bayancb.com/service/"

//  #pre-prod
// const REDIRECT_URL="https://sme-m360pre.bayancb.com/service/"

const CLIENT_ID="m360_test"

const SSO_URL = "https://sso-test.monshaat.sa/oauth2/authorize?client_id="+CLIENT_ID+"&response_type=code&redirect_uri="+REDIRECT_URL+"&scope=openid email profile&state="

const SSO_LOGOUT_URL = 'https://sso-test.monshaat.sa//account/redirect/logout?logout_destination='+REDIRECT_URL

// const REDIRECT_URL="https://online.monshati360.sa/service/"

// const CLIENT_ID='monshati360_production'

// const SSO_URL = "https://profile.monshaat.gov.sa/oauth2/authorize?client_id="+CLIENT_ID+"&response_type=code&redirect_uri="+REDIRECT_URL+"&scope=openid email profile&state="

// const SSO_LOGOUT_URL = 'https://profile.monshaat.gov.sa//account/redirect/logout?logout_destination='+LANDING_URL

const SERVICE_URL = "/service/"
const REPORT_URL = "/service/reports/";
const DASHBOARD_URL = "/service/dashboard/";
const CR_RECORDS_URL = SERVICE_URL + "cr-records/"
const CONTACT_URL = SERVICE_URL + "contact/"
const REPORT_DASHBOARD_URL = "/service/reportDashboard/";

const SME_FORM_POST_URL = "/service/postFormDetails/";
const SME_FORM_DRAFT_POST_URL = "/service/postDraftFormDetails/"
const LOGOUT_URL = "/service/logout/"

const UPLOAD_DOCUMENT_URL = "/service/uploadDocument/"
const REMOVE_DOCUMENT_URL = "/service/removeDocument/"
const REMOVE_DOC_FOLDER_URL = "/service/removeDocumentFolder/"
const GET_UPLOADED_DOCUMENT_URL = "/service/getUploadedDocument/"
const DOWNLOAD_URL = "/service/download/"


const SURVEY_POST_URL = "/survey/postSurveyDetails/"
const CONTACT_POST_URL = "/service/postContactForm/"
const SME_FORM_GET_URL = "/service/smeFormDetails/"

let COMMON_ERROR_MESSAGE = {
  messageInfo: {
    english: {
      messageTitle: "Service unavailable!",
      messageDescription: "Sorry, we'are unable to reach the server right now. Please try again later.",
      btnText:"Return to home"
    },
    arabic: {
      messageTitle: "الخدمة غير متوفرة!‎",
      messageDescription: "عذرًا ، لم نتمكن من الوصول إلى الخادم في الوقت الحالي. الرجاء معاودة المحاولة في وقت لاحق.",
      btnText:"العودة إلى الصفحة الرئيسية"
    }
  }
}
