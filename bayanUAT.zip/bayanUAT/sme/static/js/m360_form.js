let questionAnsObj = {
  sectionId: null,
  questionId: null,
  isRequired: null,
  isManualWeightCalculation: null,
  answerId: null,
  justification: null
};

const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]{2,63}\.)+[a-zA-Z]{2,}))$/;
const PHONE_REGEX = /^[0-9]*$/;
let surveyRecipientObject = {};
let resSmeFormDetails;
let documentDetails = [];
let deleteFileList = []
let isFormValid = true;
let errorCount = 0;
let isErrorExist = false;
let resultDataList;
let docList;
let surveyRecipientDetails;
let m360LookupData,
  validationInfo,
  corporateDetails,
  businessAnalysisDetails,
  surveyDetails,
  isRequiredFieldValidate;

let editedBAList = [];
let editedSurveyList = [];
let editedDocList = [];
let fileUploadTempList = [];

let isAgreementChecked = false;

let fileObj = {
  documentName: null,
  frontEndName: null,
  questionId: null,
};

let finalResponseData = "",
  folderName = "",
  feTempFolderName = "",
  agreementText = "",
  agreementId = null,
  termsAndConditionsId=null;
let certificateScoreCardMappingDetails = "";
let isSaveDraftAvailable=""
function openTermsAndConditions(element){
  element.setAttribute("data-toggle", "modal")
  element.setAttribute("data-target", "#termsModal")
  $("#termsModal").modal("show")
}
function loadm360Form(
  financialStatement,
  m360FormDetails,
  isSaveDraft,
  userDetails
) {
  resSmeFormDetails = m360FormDetails.smeFormDetails.formInfo;
  corporateDetails = m360FormDetails.smeFormDetails.formInfo.corporateDetails;
  certificateScoreCardMappingDetails =
  m360FormDetails.smeFormDetails.formInfo.certificateScoreCardMappingDetails;
  m360LookupData = m360FormDetails.smeFormDetails.lookupInfo[lang];
  validationInfo = m360FormDetails.smeFormDetails.validations;
  userDetails = userDetails;

  if(lang == "english"){
    document.getElementById("leftArrowImgSrc").src=leftArrowImg;
    document.getElementById("rightArrowImgSrc").src= rightArrowImg 
  }else{
    document.getElementById("leftArrowImgSrc").src=rightArrowImg;
    document.getElementById("rightArrowImgSrc").src= leftArrowImg 
  }
  loadCorporateDetails(corporateDetails, m360LookupData, "m360Tab1Content");
  document.getElementById('instructionCorporateDetails').innerHTML=m360LookupData.instructionCorporateDetails;
  if (!isEmpty(financialStatement)) {
    isSaveDraft = isSaveDraft;
    isSaveDraftAvailable = isSaveDraft;
    folderName = m360FormDetails.smeFormDetails.formInfo.feFolderName;
    feTempFolderName = m360FormDetails.smeFormDetails.formInfo.feTempFolderName;
    agreementText = m360FormDetails.smeFormDetails.formInfo.agreementText[lang];
    agreementText=(agreementText.replace('###',"<a href='#' id='termsAnchor'>")).replace('###',"</a>")
    agreementId = m360FormDetails.smeFormDetails.formInfo.agreementText.agreementId;
    termsAndConditionsId = m360FormDetails.smeFormDetails.formInfo.termsAndConditionsText.termsAndConditionsId;
    document.getElementById('termsContent').innerHTML = m360FormDetails.smeFormDetails.formInfo.termsAndConditionsText[lang]
    document.getElementById("agreementLbl").innerHTML = agreementText;
    if(!isEmpty(document.getElementById("termsAnchor"))){
    document.getElementById("termsAnchor").addEventListener('click',function(){
      openTermsAndConditions(this);
    })
    }
    document.getElementById("requiredInstr").innerHTML =
      m360LookupData.mandatoryFieldValidation; //string
    document.getElementById("maxFilesInstr").innerHTML =
      m360LookupData.fileUploadFieldValidation;
    document.getElementById("maxFileSizeInstr").innerHTML =
      m360LookupData.fileSizeValidation; // string
    document.getElementById("supportedFileInstr").innerHTML =
      m360LookupData.fileExtensionValidation;
    document.getElementById("groupMailInstr").innerHTML =
      m360LookupData.groupEmailAddress; //string
    document.getElementById("surveyMandatoryInstr").innerHTML =
      m360LookupData.mandatoryFieldValidation;
    document.getElementById('instructionSurveyDetails').innerHTML=
      m360LookupData.instructionSurveyDetails;
    document.getElementById('termsOkButton').innerHTML= m360LookupData.okBtn

    if (!isEmpty(resSmeFormDetails.previousAssessmentNumber)) {
      document.getElementById("baReportDashboardLink").innerHTML =
        m360LookupData.previousAssessment;
      document.getElementById("baReportDashboardLink").href =
        REPORT_DASHBOARD_URL + resSmeFormDetails.previousAssessmentNumber;
      document.getElementById("surveyReportDashboardLink").innerHTML =
        m360LookupData.previousAssessment;
      document.getElementById("surveyReportDashboardLink").href =
        REPORT_DASHBOARD_URL + resSmeFormDetails.previousAssessmentNumber;
    }

    businessAnalysisDetails =
      m360FormDetails.smeFormDetails.formInfo.businessAnalysisDetails;
    surveyDetails = m360FormDetails.smeFormDetails.formInfo.surveyDetails;
    let dialCodeInfo = m360FormDetails.smeFormDetails.dialCodeInfo;
    isFormValid = true;
    errorCount = 0;
    isErrorExist = false;
    // isSaveErrorExist = false
    resultDataList = [];
    documentDetails = [];

    questionAnsObj = {
      sectionId: null,
      questionId: null,
      isRequired: null,
      isManualWeightCalculation: null,
      answerId: null,
      justification: null,
    };
    surveyRecipientObject = {};

    loadM360BusinessAnalysisDetails(
      businessAnalysisDetails,
      m360LookupData,
      validationInfo,
      isSaveDraft
    );

    loadm360SurveyDetails(
      surveyDetails,
      m360LookupData,
      dialCodeInfo,
      isSaveDraft
    );

    $("#item2").removeClass("d-none");
    $("#item3").removeClass("d-none");
    $("#item2").addClass("d-md-block");
    $("#item3").addClass("d-md-block");

    $("#m360Tab2").removeClass("d-none");
    $("#m360Tab3").removeClass("d-none");
  } else {
    $("#item2").addClass("d-none");
    $("#item3").addClass("d-none");
    $("#item2").removeClass("d-md-block");
    $("#item3").removeClass("d-md-block");

    $("#m360Tab2").addClass("d-none");
    $("#m360Tab3").addClass("d-none");
  }

  let companyName = corporateDetails.mci.companyName;
  let companyTitleElement = document.getElementById("m360CompanyName");
  var arabic = /[\u0600-\u06FF]/;

  if (arabic.test(companyName)) {
    companyTitleElement.setAttribute("dir", "rtl");
  }

  companyTitleElement.innerHTML = companyName;
  document.getElementById("m360CRNumber").innerHTML =
    " (" + m360LookupData.crNo + ": " + corporateDetails.mci.crNumber + ")";
  document.getElementById("applyM360Title").innerHTML =
    m360LookupData.formTitle;
    if (financialStatement) {
  document.getElementById("submissionTitle").innerHTML =
    m360LookupData.sectionReview;
    }else{
      document.getElementById("submissionTitle").innerHTML =
      m360LookupData.submission; 
    }
  document.getElementById("corporateTitle").innerHTML =
    m360LookupData.corporateDetails;
  document.getElementById("surveyTitle").innerHTML = m360LookupData.survey;
  document.getElementById("baTitle").innerHTML =
    m360LookupData.businessAnalysisQuestions;
  document.getElementById("cancelBtn").innerHTML = m360LookupData.cancel;
  document.getElementById("prevBtnLbl").innerHTML = m360LookupData.prev;
  document.getElementById("doneBtnLbl").innerHTML = m360LookupData.done;
  document.getElementById("saveAndCloseBtn").innerHTML = m360LookupData.saveAndCloseButton; //string

  $("#loaderContainer").addClass("d-none");
  $("#crRecordsSection").removeClass("d-none");

  $("#m360FormContainer").removeClass("d-none");
  $("#crRecordListContainer").addClass("d-none");

  $("#container1").removeClass("d-none");

  showTab(currentTab);
}

function loadM360BusinessAnalysisDetails(
  data,
  lookupInfo,
  validationInfo,
  isSaveDraft
) {
  let baContainer = document.createDocumentFragment();
  let counter = -1;
  $.each(data, function (key, value) {
    let itemContainer = document.createElement("div");
    itemContainer.classList.add("item");
    itemContainer.setAttribute("id", "item" + key);

    if (key == 0) {
      itemContainer.classList.add("active");
    }

    // adding toggle class active container should remove the active class from all other items

    let accordionHeader = document.createElement("div");
    accordionHeader.classList.add("accordion-header");
    accordionHeader.setAttribute("id", "section" + value.sectionId); //section Id
    accordionHeader.setAttribute("data-toggle", "collapse");
    accordionHeader.setAttribute(
      "data-target",
      "#" + "section" + value.sectionId + "Content"
    ); // section to refer

    if (key == 0) {
      accordionHeader.setAttribute("aria-expanded", "true");
    } else {
      accordionHeader.setAttribute("aria-expanded", "false");
    }

    accordionHeader.setAttribute(
      "aria-controls",
      "section" + value.sectionId + "Content"
    ); //section to refer id

    accordionHeader.addEventListener("click", function (event) {

    let itemElement = event.target.closest(".item")
    itemElement.classList.toggle("active")
    $("html,body").animate(
      {
        scrollTop: $(itemElement).offset().top,
      },
      300
    );
      // $(".item").each(function (key, value) {
      //   if (value.id == event.target.closest(".item").id) {
          // value.classList.toggle("active");
      //   } else {
      //     value.classList.remove("active");
      //   }
      // });
    });

    let accordionIconToggle = document.createElement("span");
    accordionIconToggle.classList.add("accordion-icon-toggle");
    accordionIconToggle.classList.add("mr-3");

    let accordionIcon = document.createElement("span");
    accordionIcon.classList.add("icon");

    accordionIconToggle.append(accordionIcon);

    let sectionDiv = document.createElement("div");
    sectionDiv.setAttribute("style","display:flex")

    let sectionTitle = document.createElement("h2");
    sectionTitle.classList.add("title");
    sectionTitle.innerHTML = value[lang].name;

    let tickMark =document.createElement("img");
    tickMark.setAttribute("id","tick"+value.sectionId)
    tickMark.classList.add("pl-2");
    tickMark.classList.add("d-none");
    tickMark.src = iconTick;
  

    let sectionInstructions = document.createElement("p");
    sectionInstructions.classList.add("ml-5");
    sectionInstructions.setAttribute("style","font-size:16px;font-style:italic;")
    sectionInstructions.innerHTML = value[lang].instruction

    accordionHeader.append(accordionIconToggle);

    sectionDiv.append(sectionTitle)
    sectionDiv.append(tickMark)
    // sectionDiv.append(sectionInstructions)

    accordionHeader.append(sectionDiv);

    itemContainer.append(accordionHeader);
    itemContainer.append(sectionInstructions);

    let sectionContainer = document.createElement("div");
    sectionContainer.classList.add("collapse");

    if (key == 0) {
      sectionContainer.classList.add("show");
    } else {
      sectionContainer.classList.remove("show");
    }
    sectionContainer.setAttribute(
      "aria-labelledby",
      "section" + value.sectionId
    ); // section Id
    // sectionContainer.setAttribute("data-parent", "#accordion");
    sectionContainer.setAttribute(
      "id",
      "section" + value.sectionId + "Content"
    );

    let accordionBody = document.createElement("div");
    accordionBody.classList.add("accordion-body");
    accordionBody.classList.add("px-0");
    accordionBody.classList.add("px-md-4");

    let formContainer = document.createElement("form");

    accordionBody.append(formContainer);

    sectionContainer.append(accordionBody);

    $.each(value.questions, function (key1, value1) {
      let divContainer = document.createElement("div");
      divContainer.classList.add("row");
      divContainer.classList.add("m-0");
      divContainer.classList.add("pb-3");
      
      resultDataList.push(JSON.parse(JSON.stringify(questionAnsObj)));

      let questionText = document.createElement("h4");
      questionText.classList.add("pl-3");
      questionText.classList.add("mb-4");
      questionText.classList.add("title");
      questionText.classList.add("col-12");
      questionText.setAttribute("style","font-size:1.45rem")
      if (value1.isRequired) {
        questionText.classList.add("required");
      }
      
      questionText.innerHTML = value1[lang].question.replace('(','&rlm;(');

      
      questionText.setAttribute("id", "baQuestion" + value1.questionId);

      let brTag = document.createElement("br");

      let textInputSectionContainer = document.createElement("div");
      textInputSectionContainer.classList.add("col-md-6");
      textInputSectionContainer.classList.add("col-12");

      let selectDiv = document.createElement("div");
      selectDiv.setAttribute("id", "divSelect" + value1.questionId);
      selectDiv.setAttribute("style", "width:inherit");

      let selectDropdown = document.createElement("select");
      selectDropdown.classList.add("DS");
      selectDropdown.classList.add("select2");
      selectDropdown.classList.add("dropdown");
      selectDropdown.classList.add("form-control");

      if (value1.isRequired) {
        selectDropdown.classList.add("field-validate");
      }

      selectDropdown.setAttribute("id", "select" + value1.questionId);
      let resObj = resultDataList[++counter];

      resObj["sectionId"] = value.sectionId;
      resObj["questionId"] = value1.questionId;
      resObj["isRequired"] = value1.isRequired;
      resObj["isManualWeightCalculation"] = value1.isManualWeightCalculation;

      let errorText = document.createElement("p");
      errorText.setAttribute("id", "m360SelectErrorText");
      errorText.classList.add("pt-3");
      errorText.classList.add("error-color");
      errorText.classList.add("d-none");
      errorText.innerHTML = lookupInfo.questionFieldRequiredMsg;
      selectDiv.append(selectDropdown);
      selectDiv.append(errorText);

      textInputSectionContainer.append(selectDiv);

      $(selectDropdown).select2({
        minimumResultsForSearch: -1,
        dropdownParent: $(selectDiv),
        dropdownPosition: 'below',
        positionDropdown:true
      });


      var optionElement = new Option(
        lookupInfo.dropdownPlaceholder,
        "",
        false,
        false
      );

      optionElement.setAttribute("style", "width:inherit");
      selectDropdown.append(optionElement);

      $.each(value1.answerNamesAndIds, function (key2, value2) {
        var newOption = new Option(value2[lang], value2.id, false, false);
        newOption.title = value2[lang];
        newOption.setAttribute("style", "width:inherit");
        newOption.setAttribute("isRequired", value2.isJustificationMandatory);

        $(selectDropdown).append(newOption);
        

        $(selectDropdown).on("change", function (event) {
          if(selectDropdown.selectedIndex){ 
            let selectedOptionElement = event.target.options[event.target.selectedIndex]
            resObj['justificationIsRequired']=(!isEmpty(selectedOptionElement.getAttribute("isRequired")))     
          }else{
            resObj['justificationIsRequired']=value1.justificationRequired
          }
          onClickEventListener(selectDropdown, resObj,value1.justificationRequired);
        });
      });
      if (isSaveDraft) {
        $.each(value1.answerNamesAndIds, function (key2, value2) {

          if (
            value2.isSelectedOption &&
            selectDropdown.options[key2 + 1].value == value2.id
          ) {
            selectDropdown.selectedIndex =
              selectDropdown.options[key2 + 1].index;
            resObj["answerId"] = value2.id;
            return;
          }
        });
      }

      if (
        value1.hasOwnProperty("showJustification") &&
        value1.showJustification
      ) {
        let justificationContainer = document.createElement("div");
        justificationContainer.classList.add("mb-3");
        justificationContainer.classList.add("mt-3");

        let justificationLabel = document.createElement("label");
        justificationLabel.setAttribute(
          "id",
          "validationTextareaLabel" + value1.questionId
        ); 
        justificationLabel.setAttribute(
          "for",
          "validationTextarea" + value1.questionId
        ); //text area id
        justificationLabel.innerHTML = lookupInfo.justification;
        let justificationTextArea = document.createElement("textarea");
        justificationTextArea.classList.add("form-control");
        justificationTextArea.setAttribute(
          "id",
          "validationTextarea" + value1.questionId
        );
        justificationTextArea.setAttribute(
          "placeholder",
          value1[lang].justificationPlaceHolder
        );
        justificationTextArea.setAttribute("style", "min-height:6rem");
        if (value1.justificationRequired && !isSaveDraft) {
        
          resObj["justificationIsRequired"] = value1.justificationRequired;
          justificationTextArea.classList.add("field-validate");
          justificationLabel.classList.add("required");
        }else if(isSaveDraft){
          $.each(value1.answerNamesAndIds, function (key2, value2) {
            if (value2.isSelectedOption){
              if(value2.isJustificationMandatory){
                resObj["justificationIsRequired"] = value2.isJustificationMandatory;
                justificationTextArea.classList.add("field-validate");
                justificationLabel.classList.add("required");
              }
              return;
            }
        })
      }

        let pErrorText = document.createElement("p");
        pErrorText.setAttribute("id", "m360JustificationErrorText"+ value1.questionId);
        pErrorText.classList.add("pt-3");
        pErrorText.classList.add("error-color");
        pErrorText.classList.add("d-none");

        justificationTextArea.addEventListener("change", function (event) {
          onClickEventListener(event.target, resObj);
        });

        justificationContainer.append(justificationLabel);
        justificationContainer.append(justificationTextArea);
        justificationContainer.append(pErrorText);

        if (isSaveDraft) {
          justificationTextArea.value = value1.justification;
          resObj["justification"] = value1.justification;

        }

        textInputSectionContainer.append(justificationContainer);
      }

      divContainer.append(questionText);
      divContainer.append(brTag);
      divContainer.append(textInputSectionContainer);

      formContainer.append(divContainer);

      if (
        value1.hasOwnProperty("showDocumentUpload") &&
        value1.showDocumentUpload
      ) {
        let fileContainer = document.createElement("div");
        fileContainer.classList.add("col-md-6");
        fileContainer.classList.add("col-12");

        let fileDivLabel = document.createElement("label");
        fileDivLabel.innerHTML = lookupInfo.addSupportingDocuments; // string

        let sectionTag = document.createElement("section");

        let placeholderSection = document.createElement("div");

        let fileSection = document.createElement("div");
        fileSection.classList.add("dropzone");
        fileSection.classList.add("needsclick");
        fileSection.classList.add("pt-0");
        fileSection.classList.add("pb-0");
        fileSection.classList.add("mt-0");
        fileSection.classList.add("is-invalid");
        fileSection.setAttribute("style", "min-height:100px;border-width:1px");
        fileSection.setAttribute("id", "fileDiv" + key1 + key);

        let placeHolderContent = document.createElement("div");
        placeHolderContent.classList.add("dz-message");
        placeHolderContent.classList.add("needsclick");
        placeHolderContent.classList.add("mt-3");
        placeHolderContent.classList.add("mb-3");
        placeHolderContent.innerHTML = lookupInfo.dropFiles;

        let brTag1 = document.createElement("br");

        let placeholderSpan = document.createElement("span");
        placeholderSpan.classList.add("note");
        placeholderSpan.classList.add("needsclick");

        placeHolderContent.append(brTag1);
        placeHolderContent.append(placeholderSpan);

        fileSection.append(placeHolderContent);


        if (value1.documentUploadRequired) {
          resObj["documentUploadRequired"] = value1.documentUploadRequired;
          fileDivLabel.classList.add("required");
          fileSection.classList.add("field-validate");
        }

        sectionTag.append(fileDivLabel);
        sectionTag.append(fileSection);

        let fileContent = document.createElement("div");
        fileContent.classList.add("input-group");
        fileContent.classList.add("mb-3");

        let fileDiv = document.createElement("div");
        fileDiv.classList.add("custom-file");

        let fileInput = document.createElement("input");
        fileInput.classList.add("custom-file-input");
        fileInput.classList.add("input-file-upload");
        fileInput.classList.add("form-control");
        fileInput.setAttribute("type", "file");
        fileInput.setAttribute("id", "file" + key);

        let fileLabel = document.createElement("label");
        fileLabel.classList.add("custom-file-label");
        fileLabel.classList.add("form-control");
        fileLabel.classList.add("custom-height-file-upload");
        fileLabel.setAttribute("for", "file" + key);
        fileLabel.innerHTML = lookupInfo.dropFiles;

        fileDiv.append(fileInput);
        fileDiv.append(fileLabel);

        fileContent.append(fileDiv);

        let fileInstr = document.createElement("h5");
        fileInstr.setAttribute("id", "m360FileInstrText");
        fileInstr.setAttribute("style", "font-style:italic;");
        fileInstr.classList.add("pt-2");
        fileInstr.innerHTML=lookupInfo.fileUploadInstruction;

        let fileErrorText = document.createElement("p");
        fileErrorText.setAttribute("id", "m360FileErrorText");
        fileErrorText.classList.add("pt-2");
        fileErrorText.classList.add("error-color");
        fileErrorText.classList.add("d-none");

        sectionTag.append(fileInstr);
        sectionTag.append(fileErrorText);

        fileContainer.append(sectionTag);
        divContainer.append(fileContainer);

        var dropzone = new Dropzone(fileSection, {
          acceptedFiles: validationInfo.fileExtensions,
          paramName: "file",
          thumbnailHeight: 120,
          thumbnailWidth: 120,
          maxFilesize: validationInfo.maxFilesAllowed * validationInfo.maxFileSize,
          // maxFiles: validationInfo.maxFilesAllowed,
          timeout: FILE_UPLOAD_TIMEOUT,
          url: UPLOAD_DOCUMENT_URL, //url
          autoProcessQueue: true,
          addRemoveLinks: true,
          parallelUploads: 5,
          // clickable: true,
          accept: function (file, done) {
            if ((file.size < (validationInfo.maxFileSize * BYTE_CONVERTOR_VALUE)) && (this.files.length <= validationInfo.maxFilesAllowed)){	
              done();	
              }
            else
              this.removeFile(file)
          },

          init: function () {
            this.on("addedfile", function (file) {
              if (this.files.length > validationInfo.maxFilesAllowed) {
                file.isError = true;
                this.removeFile(file);
              }
            });
            this.on("sending", function (file, xhr) {
              file.itemId = "item" + key;
              fileUploadTempList.push(file);
              if (isDataEdited(editedBAList, resultDataList, true)) {
                $("#saveAndCloseBtn").addClass("disabled");
              } else {
                $("#saveAndCloseBtn").removeClass("disabled");
              }
              let sendingFile = this

              xhr.ontimeout = function () {
                /*Execute on case of timeout only*/
                sendingFile.removeFile(file)
              };
            });
            this.on("canceled", function (file) {

              for (i = 0; i < fileUploadTempList.length; i++) {
                if (file.upload.uuid == fileUploadTempList[i].upload.uuid) {
                  fileUploadTempList.splice(i, 1);
                }
              }
              if (isDataEdited(editedBAList, resultDataList, true)) {
                $("#saveAndCloseBtn").addClass("disabled");
              } else {
                $("#saveAndCloseBtn").removeClass("disabled");
              }
            });
            this.on("success", function (file, response) {
              file.isError = false;

              // if (this.options.maxFiles > 0) {
              //   this.options.maxFiles = this.options.maxFiles - 1;
              // }
              fileSection.classList.remove("is-invalid");
              fileSection.removeAttribute("style", "border:1px solid red");
              fileErrorText.classList.add("d-none");
              for (i = 0; i < fileUploadTempList.length; i++) {
                if (file.upload.uuid == fileUploadTempList[i].upload.uuid) {
                  fileUploadTempList.splice(i, 1);
                }
              }
              onFileUploaded(response[0], value1.questionId, true,value); // isAdded

              if (isDataEdited(editedBAList, resultDataList, true)) {
                $("#saveAndCloseBtn").addClass("disabled");
              } else {
                $("#saveAndCloseBtn").removeClass("disabled");
              }

            });
            this.on("error", function (file, response) {
              file.isError = true;
              this.removeFile(file);
            });
            this.on("removedfile", function (file, isError) {

              // if (
              //   this.options.maxFiles < validationInfo.maxFilesAllowed &&
              //   this.files.length < validationInfo.maxFilesAllowed
              // ) {
              //   this.options.maxFiles = this.options.maxFiles + 1;
              // }
              if (!isEmptyObject(file.upload)) {
                for (i = 0; i < fileUploadTempList.length; i++) {
                  if (file.upload.uuid == fileUploadTempList[i].upload.uuid) {
                    fileUploadTempList.splice(i, 1);
                  }
                }
              }
              if (!file.isError) {
                let isDeleted = false;
                for (i = 0; i < documentDetails.length; i++) {

                  if (
                    documentDetails[i].documentName == file.name &&
                    documentDetails[i].questionId == value1.questionId
                  ) {
                    deleteFileList.push(documentDetails[i].appianDocumentId)
                    documentDetails.splice(i, 1);
                    break;
                  }
                }

                if (this.files.length == 0 && isRequiredFieldValidate) {
                  fileSection.classList.remove("d-none");
                  fileErrorText.classList.remove("d-none");
                  fileSection.classList.add("is-invalid");
                  fileSection.setAttribute("style", "border:1px solid red");
                  fileErrorText.innerHTML =
                    lookupInfo.fileUploadFieldRequiredMsg;
                } else if (
                  this.files.length <= validationInfo.maxFilesAllowed
                ) {
                  if (this.files.length == 0) {	
                    fileSection.classList.add("is-invalid");	
                    }
                  fileSection.removeAttribute("style", "border:1px solid red");
                  fileErrorText.classList.add("d-none");
                }
                showOrHideTickMark(value.sectionId)
                if (isDataEdited(editedBAList, resultDataList, true)) {
                  $("#saveAndCloseBtn").addClass("disabled");
                } else {
                  $("#saveAndCloseBtn").removeClass("disabled");
                }
              }
            });

            if (isSaveDraft) {
              if (!isEmptyList(value1.documents)) {
                let existingFiles = value1.documents;
                for (i = 0; i < existingFiles.length; i++) {
                  var ext = existingFiles[i].documentName.split(".").pop();	
                  let fileProperties = {	
                  name: existingFiles[i].documentName,	
                  size: "12345",	
                  dataURL:	
                  GET_UPLOADED_DOCUMENT_URL +	
                  existingFiles[i].appianDocumentId,	
                  };
                  existingFiles[i]["name"] = existingFiles[i].documentName;

                  this.emit("addedfile", existingFiles[i], fileProperties);
                  onFileUploaded(existingFiles[i], value1.questionId, true,value);
                  this.files.push(existingFiles[i]);
                  dropzone1 = this;

                  if (
                    ext == "doc" ||
                    ext == "docx" ||
                    ext == "pdf" ||
                    ext == "gif"
                  ) {
                    this.createThumbnailFromUrl(
                      fileProperties,
                      this.options.thumbnailWidth,
                      this.options.thumbnailHeight,
                      this.options.thumbnailMethod,
                      true,
                      function (thumbnail) {
                        dropzone1.emit("thumbnail",  existingFiles[i], thumbnail);
                      }
                    );
                  } else {
                    this.emit(
                      "thumbnail",
                      existingFiles[i],
                      GET_UPLOADED_DOCUMENT_URL +
                      existingFiles[i].appianDocumentId	
                    );
                  }

                  fileSection.classList.remove("is-invalid");

                  this.emit("complete", existingFiles[i]);
                }
                dropzone1.options.maxFiles =
                  validationInfo.maxFilesAllowed - existingFiles.length;
              }
            }
          },
        });
      }
    });

    itemContainer.append(sectionContainer);
    for (i = 0; i < fileUploadTempList.length; i++) {
      if (file.upload.uuid == fileUploadTempList[i].upload.uuid) {
        fileUploadTempList.splice(i, 1);
      }
    }
    baContainer.append(itemContainer);
    editedBAList = JSON.parse(JSON.stringify(resultDataList));
    editedDocList = JSON.parse(JSON.stringify(documentDetails));

  });

  document.getElementById("accordion").appendChild(baContainer);
  if(isSaveDraft)
 { $.each(data, function (key, value) {
    showOrHideTickMark(value.sectionId)
  })}
}

function onFileUploaded(response, questionId, isAdded,value1) {
  if (isAdded) {
    let fileObj = response;
    fileObj["questionId"] = questionId;
    // delete fileObj.feFolderName;
    documentDetails.push(fileObj);
  } else {
    for (var i = documentDetails.length; i--;) {
      if (	
        documentDetails[i].appianDocumentId == response.appianDocumentId &&	
        documentDetails[i].questionId == questionId	
        ) {	
        deleteFileList.push(response.appianDocumentId)	
        documentDetails.splice(i, 1);	
        break;	
        }
    }
  }
  showOrHideTickMark(value1.sectionId)

}

function isDataEdited(editedItems, resultList, isDocument) {

  let resDataStr = "";
  for (let i = 0; i < resultDataList.length; i++) {
    if (!isEmpty(resultDataList[i].answerId)) {
      resDataStr = resultDataList[i].answerId + resDataStr;
    }
    if (!isEmpty(resultDataList[i].justification)) {
      resDataStr = resultDataList[i].justification + resDataStr;
    }
  }
  let surveyResDataStr = "";
  for (let i = 0; i < Object.values(surveyRecipientObject).length; i++) {
    if (!isEmpty(Object.values(surveyRecipientObject)[i].emailId)) {
      surveyResDataStr =
        Object.values(surveyRecipientObject)[i].emailId + surveyResDataStr;
    }
    if (!isEmpty(Object.values(surveyRecipientObject)[i].phoneNumber)) {
      surveyResDataStr =
        Object.values(surveyRecipientObject)[i].phoneNumber + surveyResDataStr;
    }
  }
 if (
    isEmpty(resDataStr) &&
    isEmptyList(documentDetails) &&
    isEmptyList(fileUploadTempList) &&
    JSON.stringify(editedDocList) === JSON.stringify(documentDetails)
  ) {
    return true;
  } else if (!isEmptyList(fileUploadTempList)) {
    return true;
  } else if (
    JSON.stringify(editedDocList) === JSON.stringify(documentDetails) &&
    isEmpty(resDataStr)
  ) {
    return true;
  } else if (
    isEmpty(surveyResDataStr) &&
    JSON.stringify(editedBAList) === JSON.stringify(resultDataList) &&
    JSON.stringify(editedDocList) === JSON.stringify(documentDetails) 
  ) {
    return true;
  } else if (
    !isEmpty(surveyResDataStr) &&
    JSON.stringify(editedSurveyList) ===
    JSON.stringify(Object.values(surveyRecipientObject)) &&
    JSON.stringify(editedBAList) === JSON.stringify(resultDataList) &&
    JSON.stringify(editedDocList) === JSON.stringify(documentDetails) 
  ) {
    return true;
  } else if (
    isEmpty(surveyResDataStr) &&
    JSON.stringify(editedSurveyList) ===
    JSON.stringify(Object.values(surveyRecipientObject)) &&
    JSON.stringify(editedBAList) === JSON.stringify(resultDataList) &&
    JSON.stringify(editedDocList) === JSON.stringify(documentDetails) 
  ) {
    return true;
  } else {
    return false;
  }
}

function applyInValidInput(outerSpan, innerSpan) {
  outerSpan.classList.add('is-invalid-span')
  innerSpan.classList.add('icon-invalid')
  outerSpan.classList.remove('is-valid-span')
  outerSpan.classList.remove('icon-done')

}

function applyValidInput(outerSpan, innerSpan) {
  outerSpan.classList.remove('is-invalid-span')
  innerSpan.classList.remove('icon-invalid')
  outerSpan.classList.add('is-valid-span')
  innerSpan.classList.add('icon-done')

}
function removeDuplicateEmailError(keyId){
let removeTempObj = JSON.parse(JSON.stringify(surveyRecipientObject));
delete removeTempObj[keyId];
for (var keyi in removeTempObj) {
 
  // if(surveyRecipientObject[keyId].surveyTypeId==removeTempObj[keyi].surveyTypeId)
  // {
    let errorElem = $("#" + keyi + " p[id=emailErrorText]")[0];
  if(errorElem.innerHTML==m360LookupData.duplicatesNotAllowed){
    let removeTempObj1=JSON.parse(JSON.stringify(removeTempObj))
    let emailTempiValue=removeTempObj[keyi].emailId
    delete removeTempObj1[keyi]
    let isRemoveError=true 
    for (var keyj in removeTempObj1) {
      // if(surveyRecipientObject[keyId].surveyTypeId==removeTempObj1[keyj].surveyTypeId){
      if(emailTempiValue==removeTempObj1[keyj].emailId){
        isRemoveError=false
        break;
      }
    // }
    }
    if(isRemoveError){
      errorElem.classList.add("d-none");
      errorElem.innerHTML='';
      $("#" + keyi + " input[type=email]").removeClass("is-invalid");
      $("#" + keyi + " input[type=email]").addClass("is-valid");
      applyValidInput($("#" + keyi + " span[id=iconSpan]")[0], $("#" + keyi + " span[id=iconContainer]")[0])
    }
  }
// }
}
}
function removeDuplicatePhoneError(keyId){
  let removeTempObj = JSON.parse(JSON.stringify(surveyRecipientObject));
  delete removeTempObj[keyId];
  for (var keyi in removeTempObj) {
   
    if(surveyRecipientObject[keyId].surveyTypeId==removeTempObj[keyi].surveyTypeId)
    {
      let errorElem = $("#" + keyi + " p[id=mobileErrorText]")[0];
    if(errorElem.innerHTML==m360LookupData.duplicatesNotAllowed){
      let removeTempObj1=JSON.parse(JSON.stringify(removeTempObj))
      let mobileTempiValue=removeTempObj[keyi].dialCode+removeTempObj[keyi].phoneNumber
      delete removeTempObj1[keyi]
      let isRemoveError=true 
      for (var keyj in removeTempObj1) {
        if(surveyRecipientObject[keyId].surveyTypeId==removeTempObj1[keyj].surveyTypeId){
        if(mobileTempiValue==removeTempObj1[keyj].dialCode+removeTempObj1[keyj].phoneNumber){
          isRemoveError=false
          break;
        }
      }
      }
      if(isRemoveError){
        errorElem.classList.add("d-none");
        errorElem.innerHTML='';
        $("#" + keyi + " input[type=tel]").removeClass("is-invalid");
        $("#" + keyi + " input[type=tel]").addClass("is-valid");
        applyValidInput($("#" + keyi + " span[id=iconTelSpan]")[0], $("#" + keyi + " span[id=iconTelContainer]")[0])
      }
    }}
  }
  }
  

function onChangeEventListener(element, questionAnsObj, keyId) {
  let inputType = element.type;
  let value = element.value;
  switch (inputType) {
    case "email":
      errorElement = $("#" + keyId + " p[id=emailErrorText]")[0];
      questionAnsObj.emailId = value;
      if (value.trim().length == 0 && isRequiredFieldValidate) {
        element.classList.add("is-invalid");
        element.classList.remove("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconSpan]")[0], $("#" + keyId + " span[id=iconContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.emailIdRequired; //string
        removeDuplicateEmailError(keyId)
      } else if (!isEmpty(value.trim()) && !EMAIL_REGEX.test(value.trim())) {
        element.classList.add("is-invalid");
        element.classList.remove("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconSpan]")[0], $("#" + keyId + " span[id=iconContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.validEmailId; //string
        removeDuplicateEmailError(keyId)
      } 
      else {
        let isError = false;
        for (var key in surveyRecipientObject) {
          let value = surveyRecipientObject[key];
          if (
            // questionAnsObj.surveyTypeId == value.surveyTypeId &&
            element.value == value.emailId &&
            !(keyId == key)
          ) {
            if (!isEmpty(value.emailId)) {
              isError = true;
              let elem = document.getElementById(key);
              $("#" + elem.id + " input[type=email]").addClass("is-invalid");
              $("#" + elem.id + " input[type=email]").removeClass("is-valid");
              applyInValidInput($("#" + elem.id + " span[id=iconSpan]")[0], $("#" + elem.id + " span[id=iconContainer]")[0])
              errorElement = $("#" + elem.id + " p[id=emailErrorText]")[0];
              errorElement.classList.remove("d-none");
              errorElement.innerHTML = m360LookupData.duplicatesNotAllowed;
            }
          } else {
            if (
              // questionAnsObj.surveyTypeId == value.surveyTypeId &&
              element.value != value.emailId &&
              !(keyId == key)
            ) {
              let tempObj = JSON.parse(JSON.stringify(surveyRecipientObject));
              let isTempError = false;
              delete tempObj[key];
              // delete tempObj[keyId];
              for (var key1 in tempObj) {
                if (
                  // tempObj[key1].surveyTypeId == value.surveyTypeId &&
                  tempObj[key1].emailId == value.emailId
                ) {
                  if (
                    !isEmpty(value.emailId) &&
                    !isEmpty(tempObj[key1].emailId)
                  ) {
                    isTempError = true;
                  }
                }
                if (isTempError) {
                  let elementId = document.getElementById(key).id;
                  $("#" + elementId + " input[type=email]").addClass(
                    "is-invalid"
                  );
                  $("#" + elementId + " input[type=email]").removeClass("is-valid");
                  applyInValidInput($("#" + elementId + " span[id=iconSpan]")[0], $("#" + elementId + " span[id=iconContainer]")[0])
                  errorElement = $("#" + elementId + " p[id=emailErrorText]")[0];
                  errorElement.innerHTML = m360LookupData.duplicatesNotAllowed; //string
                  errorElement.classList.remove("d-none");
                } else {
                  let elem = document.getElementById(key);
                  let emailElem = $("#" + elem.id + " input[type=email]")[0];
                  if (
                    emailElem.classList.contains("is-invalid") &&
                    !isEmpty(emailElem.value) &&
                    EMAIL_REGEX.test(emailElem.value)
                  ) {
                    $("#" + elem.id + " input[type=email]").removeClass(
                      "is-invalid"
                    );
                    $("#" + elem.id + " input[type=email]").addClass("is-valid");
                    applyValidInput($("#" + elem.id + " span[id=iconSpan]")[0], $("#" + elem.id + " span[id=iconContainer]")[0])
                    errorElement = $(
                      "#" + elem.id + " p[id=emailErrorText]"
                    )[0];
                    errorElement.classList.add("d-none");
                  }
                }
              }
            }
          }
        }
        if (!isError) {
          element.classList.remove("is-invalid");
          if (value.length > 0) {
            element.classList.add("is-valid");
            applyValidInput($("#" + keyId + " span[id=iconSpan]")[0], $("#" + keyId + " span[id=iconContainer]")[0])
          }

          errorElement = $("#" + keyId + " p[id=emailErrorText]")[0];
          errorElement.classList.add("d-none");
        } else {
          element.classList.add("is-invalid");
          element.classList.remove("is-valid");
          applyInValidInput($("#" + keyId + " span[id=iconSpan]")[0], $("#" + keyId + " span[id=iconContainer]")[0])
          errorElement = $("#" + keyId + " p[id=emailErrorText]")[0];
          errorElement.innerHTML = m360LookupData.duplicatesNotAllowed; //string
          errorElement.classList.remove("d-none");
        }
        
      }
     


      if (
        isDataEdited(editedSurveyList, Object.values(surveyRecipientObject))
      ) {
        $("#saveAndCloseBtn").addClass("disabled");
      } else {
        $("#saveAndCloseBtn").removeClass("disabled");
      }
      break;
    case "tel":
      errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
      questionAnsObj.phoneNumber = value;
      if (value.length == 0 && isRequiredFieldValidate) {
        element.classList.add("is-invalid");
        element.classList.remove("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.mobileNumberRequired; //string
        removeDuplicatePhoneError(keyId)
      } else if (
        (!isEmpty(value.trim()) && !validatePhoneNumber(value.trim())) ||
        (value[0] == 0 &&
          questionAnsObj.dialCode == "+966" &&
          !validatePhoneNumber(value.substring(1).trim()))
        || (value.startsWith((questionAnsObj.dialCode).replace(/[^\d]/g, "")) && !validatePhoneNumber(value.replace((questionAnsObj.dialCode).replace(/[^\d]/g, ""), "").trim()))
      ) {
        element.classList.add("is-invalid");
        element.classList.remove("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.validMobileNumber; //string
        removeDuplicatePhoneError(keyId)
      }else if(!isEmpty(value) && questionAnsObj.dialCode == "+966" && (value.length!=9 || value[0]!=5) ){
        element.classList.add("is-invalid");
        element.classList.remove("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.validMobileNumber; //string
        removeDuplicatePhoneError(keyId)
      } else {
        let isError = false;
        if (value[0] == 0 && questionAnsObj.dialCode == "+966") {
          value = value.substring(1);
          $("#" + keyId + " input[type=tel]").val(value);
        } else if (value.startsWith((questionAnsObj.dialCode).replace(/[^\d]/g, ""))) {
          value = value.replace((questionAnsObj.dialCode).replace(/[^\d]/g, ""), "")
          $("#" + keyId + " input[type=tel]").val(value);
        }
        for (var key in surveyRecipientObject) {
          let value = surveyRecipientObject[key];

          if (
            // questionAnsObj.surveyTypeId == value.surveyTypeId &&
            element.value == value.phoneNumber &&
            questionAnsObj.dialCode == value.dialCode &&
            !(keyId == key)
          ) {
            if (!isEmpty(value.phoneNumber)) {
              isError = true;
              let elem = document.getElementById(key);
              $("#" + elem.id + " input[type=tel]").addClass("is-invalid");
              $("#" + elem.id + " input[type=tel]").removeClass("is-valid");
              applyInValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])
              errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
              errorElement.classList.remove("d-none");
              errorElement.innerHTML = m360LookupData.duplicatesNotAllowed;
            }
          } else {
            if (
              // questionAnsObj.surveyTypeId == value.surveyTypeId &&
              (element.value != value.phoneNumber ||
                questionAnsObj.dialCode != value.dialCode)
            ) {

              let tempObj = JSON.parse(JSON.stringify(surveyRecipientObject));

              let isTempError = false;
              delete tempObj[key];
              // delete tempObj[keyId];

              for (var key1 in tempObj) {
                if (
                  // tempObj[key1].surveyTypeId == value.surveyTypeId &&
                  tempObj[key1].phoneNumber == value.phoneNumber &&
                  tempObj[key1].dialCode == value.dialCode
                ) {
                  if (
                    !isEmpty(value.phoneNumber) &&
                    !isEmpty(tempObj[key1].phoneNumber)
                  ) {
                    isTempError = true;
                  }
                }
              }
              if (isTempError) {
                let elem = document.getElementById(key);
                $("#" + elem.id + " input[type=tel]").addClass("is-invalid");
                $("#" + elem.id + " input[type=tel]").removeClass("is-valid");
                applyInValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])

                errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
                errorElement.classList.remove("d-none");
                errorElement.innerHTML = m360LookupData.duplicatesNotAllowed; //string
              } else {
                let elem = document.getElementById(key);
                let telElem = $("#" + elem.id + " input[type=tel]")[0];
                let selectElem= $("#" + elem.id + " select")[0];
                if(telElem.classList.contains("is-invalid")&& !isEmpty(telElem.value) && selectElem.value == "+966" && telElem.value.length==9 && telElem.value[0]==5){
                  $("#" + elem.id + " input[type=tel]").removeClass(
                    "is-invalid"
                  );
                  $("#" + elem.id + " input[type=tel]").addClass("is-valid");
                  applyValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])

                  errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
                  errorElement.classList.add("d-none");
        
                }
               else if (
                  telElem.classList.contains("is-invalid") &&
                  !isEmpty(telElem.value) &&
                  validatePhoneNumber(telElem.value) &&
                  selectElem.value != "+966"
                ) {
                    $("#" + elem.id + " input[type=tel]").removeClass(
                    "is-invalid"
                  );
                  $("#" + elem.id + " input[type=tel]").addClass("is-valid");
                  applyValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])

                  errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
                  errorElement.classList.add("d-none");
        
                }
              }
            }
          }
        }

        if (!isError) {
          element.classList.remove("is-invalid");
          if (value.length > 0) {
            element.classList.add("is-valid");
            applyValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
          }
          errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
          errorElement.classList.add("d-none");
        } else {
          element.classList.add("is-invalid");
          element.classList.remove("is-valid");
          applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
          errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
          errorElement.classList.remove("d-none");
          errorElement.innerHTML = m360LookupData.duplicatesNotAllowed; //string
        }
      }
     
      if (
        isDataEdited(editedSurveyList, Object.values(surveyRecipientObject))
      ) {
        $("#saveAndCloseBtn").addClass("disabled");
      } else {
        $("#saveAndCloseBtn").removeClass("disabled");
      }

      break;

    case "select-one":
      errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
      surveyRecipientObject[keyId].dialCode = value; //dialCode
      if (
        questionAnsObj["phoneNumber"].length == 0 &&
        isRequiredFieldValidate
      ) {
        if ($("#" + keyId + " input[type=tel]").hasClass("is-invalid")) {
          $("#" + keyId + " input[type=tel]").addClass("is-invalid");
          $("#" + keyId + " input[type=tel]").removeClass("is-valid");
          applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
          errorElement.classList.remove("d-none");
          errorElement.innerHTML = m360LookupData.mobileNumberRequired; //string
          removeDuplicatePhoneError(keyId)
        }
      } else if (
        (!isEmpty(questionAnsObj["phoneNumber"].trim()) &&
          !validatePhoneNumber(questionAnsObj["phoneNumber"].trim())) ||
        (questionAnsObj["phoneNumber"][0] == 0 &&
          value == "+966" &&
          !validatePhoneNumber(
            questionAnsObj["phoneNumber"].substring(1).trim()
          )) || (questionAnsObj["phoneNumber"].startsWith((value).replace(/[^\d]/g, ""))) && (!validatePhoneNumber(questionAnsObj["phoneNumber"].replace((value).replace(/[^\d]/g, ""), "").trim()))
      ) {
        $("#" + keyId + " input[type=tel]").addClass("is-invalid");
        $("#" + keyId + " input[type=tel]").removeClass("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.validMobileNumber; //string
        removeDuplicatePhoneError(keyId)
      }else if(!isEmpty(questionAnsObj["phoneNumber"])&&value == "+966" && (questionAnsObj["phoneNumber"].length!=9 ||questionAnsObj["phoneNumber"][0]!=5) ){
        $("#" + keyId + " input[type=tel]").addClass("is-invalid");
        $("#" + keyId + " input[type=tel]").removeClass("is-valid");
        applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
        errorElement.classList.remove("d-none");
        errorElement.innerHTML = m360LookupData.validMobileNumber; //string
        removeDuplicatePhoneError(keyId)
      } 

      else {
        let isError = false;
        if (questionAnsObj.phoneNumber[0] == 0 && value == "+966") {
          questionAnsObj.phoneNumber = questionAnsObj.phoneNumber.substring(1);
          $("#" + keyId + " input[type=tel]").val(questionAnsObj.phoneNumber);
        } else if (questionAnsObj.phoneNumber.startsWith((value).replace(/[^\d]/g, ""))) {
          questionAnsObj.phoneNumber = questionAnsObj.phoneNumber.replace((value).replace(/[^\d]/g, ""), "")
          $("#" + keyId + " input[type=tel]").val(questionAnsObj.phoneNumber);
        }
        for (var key in surveyRecipientObject) {
          let value = surveyRecipientObject[key];

          if (
            // questionAnsObj.surveyTypeId == value.surveyTypeId &&
            questionAnsObj.phoneNumber == value.phoneNumber &&
            element.value == value.dialCode &&
            !(keyId == key)
          ) {
            if (
              !isEmpty(value.phoneNumber) &&
              !isEmpty(questionAnsObj.phoneNumber)
            ) {
              isError = true;
              let elem = document.getElementById(key);
              $("#" + elem.id + " input[type=tel]").addClass("is-invalid");
              $("#" + elem.id + " input[type=tel]").removeClass("is-valid");
              applyInValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])
              errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
              errorElement.classList.remove("d-none");
              errorElement.innerHTML = m360LookupData.duplicatesNotAllowed;
            }

          } else {
            if (
              // questionAnsObj.surveyTypeId == value.surveyTypeId &&
              (questionAnsObj.phoneNumber != value.phoneNumber ||
                element.value != value.dialCode)
            ) {

              let tempObj = JSON.parse(JSON.stringify(surveyRecipientObject));

              let isTempError = false;
              delete tempObj[key];
              // delete tempObj[keyId];

              for (var key1 in tempObj) {
                if (
                  // tempObj[key1].surveyTypeId == value.surveyTypeId &&
                  tempObj[key1].phoneNumber == value.phoneNumber &&
                  tempObj[key1].dialCode == value.dialCode
                ) {
                  if (
                    !isEmpty(value.phoneNumber) &&
                    !isEmpty(tempObj[key1].phoneNumber)
                  ) {
                    isTempError = true;
                  }
                }
              }
              if (isTempError) {
                let elementId = document.getElementById(key).id;
                $("#" + elementId + " input[type=tel]").addClass("is-invalid");
                $("#" + elementId + " input[type=tel]").removeClass("is-valid");
                applyInValidInput($("#" + elementId + " span[id=iconTelSpan]")[0], $("#" + elementId + " span[id=iconTelContainer]")[0])
                errorElement = $("#" + elementId + " p[id=mobileErrorText]")[0];
                errorElement.classList.remove("d-none");
                errorElement.innerHTML = m360LookupData.duplicatesNotAllowed;
              } else {
                let elem = document.getElementById(key);
                let telElem = $("#" + elem.id + " input[type=tel]")[0];
                let selectElem= $("#" + elem.id + " select")[0];
                if( telElem.classList.contains("is-invalid") &&
                !isEmpty(telElem.value) &&selectElem.value == "+966" && telElem.value.length==9 && telElem.value[0]==5){
                  $("#" + elem.id + " input[type=tel]").removeClass(
                    "is-invalid"
                  );
                  $("#" + elem.id + " input[type=tel]").addClass("is-valid");
                  applyValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])

                  errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
                  errorElement.classList.add("d-none");
        
                }
               else if (
                  telElem.classList.contains("is-invalid") &&
                  !isEmpty(telElem.value) &&
                  validatePhoneNumber(telElem.value) &&
                  selectElem.value != "+966" 
                ) {
                  $("#" + elem.id + " input[type=tel]").removeClass(
                    "is-invalid"
                  );
                  $("#" + elem.id + " input[type=tel]").addClass("is-valid");
                  applyValidInput($("#" + elem.id + " span[id=iconTelSpan]")[0], $("#" + elem.id + " span[id=iconTelContainer]")[0])
                  errorElement = $("#" + elem.id + " p[id=mobileErrorText]")[0];
                  errorElement.classList.add("d-none");
                }
              }
            }
          }
        }

        if (!isError) {
          $("#" + keyId + " input[type=tel]").removeClass("is-invalid");
          if (questionAnsObj.phoneNumber.length > 0) {
            $("#" + keyId + " input[type=tel]").addClass("is-valid");
            applyValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
          }
          errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
          errorElement.classList.add("d-none");
        } else {
          $("#" + keyId + " input[type=tel]").addClass("is-invalid");
          $("#" + keyId + " input[type=tel]").removeClass("is-valid");
          applyInValidInput($("#" + keyId + " span[id=iconTelSpan]")[0], $("#" + keyId + " span[id=iconTelContainer]")[0])
          errorElement = $("#" + keyId + " p[id=mobileErrorText]")[0];
          errorElement.classList.remove("d-none");
          errorElement.innerHTML = m360LookupData.duplicatesNotAllowed;
        }
      }

  

      if (
        isDataEdited(editedSurveyList, Object.values(surveyRecipientObject))
      ) {
        $("#saveAndCloseBtn").addClass("disabled");
      } else {
        $("#saveAndCloseBtn").removeClass("disabled");
      }

      break;
    default:
      break;
  }

}

function validatePhoneNumber(value) {
  if (value.length >= 6 && value.length <= 15) return PHONE_REGEX.test(value);
  else return false;
}

function getCount(parent, getChildrensChildren) {
  var relevantChildren = 0;
  var children = parent.childNodes.length;
  for (var i = 0; i < children; i++) {
    if (parent.childNodes[i].nodeType != 3) {
      if (getChildrensChildren)
        relevantChildren += getCount(parent.childNodes[i], true);
      relevantChildren++;
    }
  }
  return relevantChildren;
}

function deleteSelectedEmailMobileRow(key, initialRowCount) {
  let rowListDiv = document.getElementById("rowListDiv" + key.split("-")[0]);


  let lastRowCount = getCount(rowListDiv, false);

  if (lastRowCount > initialRowCount) {
    deletedsurveyTypeId=surveyRecipientObject[key].surveyTypeId;
    delete surveyRecipientObject[key];
    let isEmailChecked=false,isMobileChecked=false;
    for (var keyid in surveyRecipientObject) {
      if(deletedsurveyTypeId==surveyRecipientObject[keyid].surveyTypeId){
        if(!isEmpty(surveyRecipientObject[keyid].emailId) && !isEmailChecked){
          isEmailChecked=true
          onChangeEventListener($("#" + keyid + " input[type=email]")[0],surveyRecipientObject[keyid],keyid)
        }
        if(!isEmpty(surveyRecipientObject[keyid].phoneNumber) && !isMobileChecked){
          isMobileChecked=true
        onChangeEventListener($("#" + keyid + " input[type=tel]")[0],surveyRecipientObject[keyid],keyid)
        }
        if(isMobileChecked && isEmailChecked)
        break;
      }
    }
  
    document.getElementById(key).remove();
    if (lastRowCount - 1 == initialRowCount)
      $("#rowListDiv" + key.split("-")[0] + " img").addClass("d-none");
  }
  if (isDataEdited(editedSurveyList, surveyRecipientObject)) {
    $("#saveAndCloseBtn").addClass("disabled");
  } else {
    $("#saveAndCloseBtn").removeClass("disabled");
  }
}

function getEmailMobileSection(
  key,
  dialCodeInfo,
  value,
  isSaveDraft,
  editedInputValue
) {
  surveyRecipientObject[key] = {
    surveyTypeId: value.surveyTypeId,
    emailId: "",
    phoneNumber: "",
    dialCode: dialCodeInfo.defaultDialCode,
  };

  if (isSaveDraft) {
    surveyRecipientObject[key] = {
      surveyTypeId: value.surveyTypeId,
      emailId: !isEmpty(editedInputValue.emailId)
        ? editedInputValue.emailId
        : "",
      phoneNumber: !isEmpty(editedInputValue.phoneNumber)
        ? editedInputValue.phoneNumber
        : "",
      dialCode: !isEmpty(editedInputValue.dialCode)
        ? editedInputValue.dialCode
        : dialCodeInfo.defaultDialCode,
    };
  }


  let listDivContainer = document.createElement("div");
  listDivContainer.classList.add("row");
  listDivContainer.setAttribute("id", key);
  let listDivColContainer = document.createElement("div");
  listDivColContainer.classList.add("col-12");
  listDivColContainer.classList.add("col-md-12");
  listDivColContainer.classList.add("col-lg-6");
  listDivColContainer.classList.add("mt-md-0");
  listDivColContainer.classList.add("mt-md-2");
  let listDivformGroupContainer = document.createElement("div");
  listDivformGroupContainer.classList.add("form-group");

  let listDivInputValidationContainer = document.createElement("div");
  listDivInputValidationContainer.classList.add("input-validation");

  let listDivInputContainer = document.createElement("input");
  listDivInputContainer.setAttribute("type", "email");
  listDivInputContainer.setAttribute("placeholder", m360LookupData.placeholderemail); //string
  listDivInputContainer.classList.add("form-control");

  let listIconSpanContainer = document.createElement("span");
  listIconSpanContainer.setAttribute("id", "iconSpan");

  let listIconContainer = document.createElement("span");
  listIconContainer.setAttribute("id", "iconContainer");

  listIconSpanContainer.append(listIconContainer)

  listDivInputContainer.addEventListener("change", function (event) {
    onChangeEventListener(event.target, surveyRecipientObject[key], key);
  });

  if (isSaveDraft) {
    listDivInputContainer.value = !isEmpty(editedInputValue.emailId)
      ? editedInputValue.emailId
      : "";
  }

  let emailErrorText = document.createElement("p");
  emailErrorText.setAttribute("id", "emailErrorText");
  emailErrorText.classList.add("pt-3");
  emailErrorText.classList.add("error-color");
  emailErrorText.classList.add("d-none");

  listDivInputValidationContainer.append(listDivInputContainer);
  listDivInputValidationContainer.append(listIconSpanContainer);
  listDivInputValidationContainer.append(emailErrorText);

  listDivformGroupContainer.append(listDivInputValidationContainer);

  listDivColContainer.append(listDivformGroupContainer);
  listDivContainer.append(listDivColContainer);
  let listDivSelectContainer = document.createElement("div");
  listDivSelectContainer.classList.add("col-12");
  listDivSelectContainer.classList.add("col-md-12");
  listDivSelectContainer.classList.add("col-lg-6");
  listDivSelectContainer.classList.add("mt-md-0");
  listDivSelectContainer.classList.add("mt-md-2");
  listDivSelectContainer.setAttribute("style","direction:ltr")
  let listDivInputGroupContainer = document.createElement("div");
  listDivInputGroupContainer.classList.add("input-group");
  listDivInputGroupContainer.classList.add("mb-3");
  let listDivInputGroupPrependContainer = document.createElement("div");
  listDivInputGroupPrependContainer.classList.add("input-group-prepend");
  listDivInputGroupPrependContainer.classList.add("input-validation");
  listDivInputGroupPrependContainer.classList.add("select");
  listDivInputGroupPrependContainer.classList.add("DS");
  listDivInputGroupPrependContainer.addEventListener("change", function (
    event
  ) {
    onChangeEventListener(event.target, surveyRecipientObject[key], key);
  });
  let listDivInputGroupTextContainer = document.createElement("select");
  listDivInputGroupTextContainer.classList.add("input-group-text");
  listDivInputGroupTextContainer.classList.add("select-dial-code");
  listDivInputGroupTextContainer.classList.add("left");
  for (j = 0; j < dialCodeInfo.dialCodes.length; j++) {
    let listDivOptionContainer = document.createElement("option");
    listDivOptionContainer.setAttribute("value", dialCodeInfo.dialCodes[j]);
    listDivOptionContainer.innerHTML = dialCodeInfo.dialCodes[j];

    if (isSaveDraft) {
      if (!isEmpty(editedInputValue.dialCode)) {
        if (dialCodeInfo.dialCodes[j] == editedInputValue.dialCode) {
          listDivOptionContainer.setAttribute("selected", "selected");
        }
      } else if (dialCodeInfo.dialCodes[j] == dialCodeInfo.defaultDialCode) {
        listDivOptionContainer.setAttribute("selected", "selected");
      }
    } else if (dialCodeInfo.dialCodes[j] == dialCodeInfo.defaultDialCode) {
      listDivOptionContainer.setAttribute("selected", "selected");
    }
    listDivInputGroupTextContainer.append(listDivOptionContainer);
  }
  listDivInputGroupPrependContainer.append(listDivInputGroupTextContainer);
  let listDivSelectInputContainer = document.createElement("input");
  listDivSelectInputContainer.setAttribute("type", "tel");
  listDivSelectInputContainer.classList.add("input-tel");
  listDivSelectInputContainer.setAttribute("placeholder", m360LookupData.placeholderassessmentMobileNo) //string
  listDivSelectInputContainer.classList.add("form-control");

  if (isSaveDraft) {
    listDivSelectInputContainer.value = !isEmpty(editedInputValue.phoneNumber)
      ? editedInputValue.phoneNumber
      : "";
  }

  listDivSelectInputContainer.addEventListener("change", function (event) {
    onChangeEventListener(event.target, surveyRecipientObject[key], key);
    $("#" + key + " select").removeAttr("style", "border:1px solid #b23939");
  });
  let listTelIconSpanContainer = document.createElement("span");
  listTelIconSpanContainer.setAttribute("id", "iconTelSpan");
  listTelIconSpanContainer.classList.add("icon-span-ltr");


  let listTelIconContainer = document.createElement("span");
  listTelIconContainer.setAttribute("id", "iconTelContainer");

  listTelIconSpanContainer.append(listTelIconContainer)

  let mobileErrorText = document.createElement("p");
  mobileErrorText.setAttribute("id", "mobileErrorText");
  mobileErrorText.classList.add("error-color");
  mobileErrorText.classList.add("d-none");

  listDivInputGroupContainer.append(listDivInputGroupPrependContainer);
  listDivInputGroupContainer.append(listDivSelectInputContainer);
  listDivInputGroupContainer.append(listTelIconSpanContainer);


  listDivSelectContainer.append(listDivInputGroupContainer);
  listDivSelectContainer.append(mobileErrorText);
  let listDivSelectSpanContainer = document.createElement("span");
  listDivSelectSpanContainer.classList.add("delete-icon");


  let listDivImageContainer = document.createElement("img");
  if (value.rowCount >= value.surveyRecipientDetails.length) {
    listDivImageContainer.classList.add("d-none");
  }
  listDivImageContainer.setAttribute("src", deleteIcon);
  listDivImageContainer.addEventListener("click", function () {
    deleteSelectedEmailMobileRow(key, value.rowCount);
  });
  listDivSelectSpanContainer.append(listDivImageContainer);
  listDivSelectContainer.append(listDivSelectSpanContainer)
  listDivContainer.append(listDivSelectContainer);

  return listDivContainer;
}

function loadm360SurveyDetails(data, lookupData, dialCodeInfo, isSaveDraft) {

  let surveyContainer = document.createDocumentFragment();
  let surveyDivContainer = document.createElement("div");
  surveyDivContainer.classList.add("row");
  $.each(data, function (key, value) {
    let surveyTypeContainer = document.createElement("div");
    surveyTypeContainer.classList.add("col-12");
    surveyTypeContainer.classList.add("col-md-6");
    surveyTypeContainer.classList.add("mt-5");
    surveyTypeContainer.classList.add("mt-md-0");

    let surveyTypeTitle = document.createElement("h4");
    surveyTypeTitle.classList.add("card-title");
    surveyTypeTitle.classList.add("primary-color");
    surveyTypeTitle.innerHTML = value.type[lang].name;


    let listContainer = document.createElement("div");
    listContainer.classList.add("col-12");
    listContainer.classList.add("col-md-6");
    if (key != 0) {
      listContainer.classList.add("mt-5");
    }
    listContainer.classList.add("mt-md-0");
    listContainer.append(surveyTypeTitle);
    let listDivCardDSContainer = document.createElement("div");
    listDivCardDSContainer.classList.add("card");
    listDivCardDSContainer.classList.add("DS");
    let listDivCardBodyContainer = document.createElement("div");
    listDivCardBodyContainer.classList.add("card-body");
    let listDivTitleContainer = document.createElement("div");
    listDivTitleContainer.classList.add("row");
    listDivTitleContainer.classList.add("align-items-end");
    let listDivEmailContainer = document.createElement("div");
    listDivEmailContainer.classList.add("col-12");
    listDivEmailContainer.classList.add("col-md-12");
    listDivEmailContainer.classList.add("col-lg-6");

    let listDivEmailTitleContainer = document.createElement("h4");
    listDivEmailTitleContainer.classList.add("card-title");
    listDivEmailTitleContainer.classList.add("required");
    listDivEmailTitleContainer.classList.add("mb-0");
    listDivEmailTitleContainer.innerHTML = lookupData.email;
    listDivEmailContainer.append(listDivEmailTitleContainer);
    listDivTitleContainer.append(listDivEmailContainer);
    let listDivPhoneContainer = document.createElement("div");
    listDivPhoneContainer.classList.add("col-12");
    listDivPhoneContainer.classList.add("col-md-6");

    let listDivPhoneTitleContainer = document.createElement("h4");
    listDivPhoneTitleContainer.classList.add("card-title");
    listDivPhoneTitleContainer.classList.add("required");
    listDivPhoneTitleContainer.classList.add("mb-0");
    listDivPhoneTitleContainer.innerHTML = lookupData.mobileNo;
    listDivPhoneContainer.append(listDivPhoneTitleContainer);
    listDivTitleContainer.append(listDivPhoneContainer);
    listDivCardBodyContainer.append(listDivTitleContainer);
    let rowListDivContainer = document.createElement("div");
    rowListDivContainer.setAttribute("id", "rowListDiv" + key);

    let rowCount = value.rowCount;

    for (
      i = 0;
      i <
      (rowCount > value.surveyRecipientDetails.length
        ? rowCount
        : value.surveyRecipientDetails.length);
      i++
    ) {
      let editedInputValueList = !isEmptyList(value.surveyRecipientDetails)
        ? value.surveyRecipientDetails
        : "";
      let editedInputValue = !isEmptyObject(editedInputValueList[i])
        ? editedInputValueList[i]
        : "";
      rowListDivContainer.append(
        getEmailMobileSection(
          key + "-" + i,
          dialCodeInfo,
          value,
          isSaveDraft,
          editedInputValue
        )
      );
    }
    listDivCardBodyContainer.append(rowListDivContainer);
    let addItemContainer = document.createElement("div");
    addItemContainer.classList.add("row");
    addItemContainer.classList.add("pl-4");
    let addItemImageContainer = document.createElement("img");
    addItemImageContainer.setAttribute("src", addItemIcon);
    addItemImageContainer.classList.add("cursor");
    addItemContainer.addEventListener("click", function (event) {
      let rowListDiv = document.getElementById("rowListDiv" + key);
      let nextRowCount = Number(rowListDiv.lastChild.id.split("-")[1]) + 1;
      rowListDiv.appendChild(
        getEmailMobileSection(key + "-" + nextRowCount, dialCodeInfo, value, "")
      );
      $("#rowListDiv" + key + " img").removeClass("d-none");
    });
    let addItemSpanContainer = document.createElement("span");
    addItemSpanContainer.classList.add("icon");
    addItemSpanContainer.classList.add("pl-2");
    addItemSpanContainer.classList.add("add-item");
    addItemSpanContainer.classList.add("primary-color");
    addItemSpanContainer.classList.add("cursor");
    addItemSpanContainer.setAttribute("value", lookupData.addItem);
    addItemSpanContainer.innerHTML = lookupData.addItem;
    addItemContainer.append(addItemImageContainer);
    addItemContainer.append(addItemSpanContainer);
    listDivCardBodyContainer.append(addItemContainer);
    listDivCardDSContainer.append(listDivCardBodyContainer);

    listContainer.append(listDivCardDSContainer);
    document.getElementById("emailMobileContainer").appendChild(listContainer);
  });
  surveyContainer.append(surveyDivContainer);
  document
    .getElementById("surveyDetailsTitleDiv")
    .appendChild(surveyDivContainer);
  surveyRecipientDetails = Object.values(surveyRecipientObject);
  editedSurveyList = JSON.parse(JSON.stringify(surveyRecipientDetails));

}

function validateBAInputs(obj) {
  if (obj.classList.contains("dropzone")) {
    return onClickEventListener(obj, documentDetails);
  }
  return onClickEventListener(obj, questionAnsObj);
}

function validateM360Select(element, error) {
  let elementId = element.id;
  let isFieldValid = false;


  if (element.classList.contains("field-validate") && isRequiredFieldValidate) {
    if ($("#" + elementId + " option:selected").index() == 0) {
      isFieldValid = false;
      $(element).siblings()[0].classList.add("is-invalid");
      error.classList.remove("d-none");
    } else {
      isFieldValid = true;
      $(element).siblings()[0].classList.remove("is-invalid");
      error.classList.add("d-none");
    }
  } else {
    isFieldValid = true;
    $(element).siblings()[0].classList.remove("is-invalid");
    error.classList.add("d-none");
  }
  return isFieldValid;
}

function validateFileDropZone(element, error) {
  let isFieldValid = false;


  if (
    element.classList.contains("is-invalid") &&
    element.classList.contains("field-validate") &&
    isRequiredFieldValidate
  ) {

    element.setAttribute("style", "border:1px solid red");
    if (isEmpty(error.innerHTML)) {
      error.innerHTML = m360LookupData.fileUploadFieldRequiredMsg;
    }
    isFieldValid = false;
    error.classList.remove("d-none");
  } else {
    
    element.removeAttribute("style", "border:1px solid red");
    isFieldValid = true;
    error.classList.add("d-none");
  }
  return isFieldValid;
}

function validateM360TextArea(element, error) {
  let isFieldValid = false;
  let textValue = element.value.trim();
  if(!(document.getElementById("validationTextareaLabel"+element.id.replace("validationTextarea","")).classList.contains("required")) && isEmpty(element.value)){
    element.classList.remove("field-validate")
  }

  if (
    textValue.length == 0 &&
    element.classList.contains("field-validate") &&
    isRequiredFieldValidate 
  ) {
    isFieldValid = false;
    element.classList.add("is-invalid");
    element.classList.remove("is-valid");
    error.innerHTML = m360LookupData.justificationFieldRequiredMsg;
    error.classList.remove("d-none");
  } else if (textValue.length > validationInfo.justificationLength) {
    isFieldValid = false;
    element.classList.add("is-invalid");
    element.classList.remove("is-valid");
    error.innerHTML = m360LookupData.justficationFieldValidation;
    error.classList.remove("d-none");
  } else {
    isFieldValid = true;
    element.classList.remove("is-invalid");
    element.classList.remove("is-valid");
    if (textValue.length > 0) {
      element.classList.add("is-valid");
    }

    error.classList.add("d-none");
  }
  return isFieldValid;
}

function showOrHideTickMark(id){
  let isSectionValid=true;

  $.each(resultDataList,function (key,value) {
    
    if(value.sectionId==id){
      if(value.isRequired && isEmpty(value.answerId)){
       
        isSectionValid=false
        return;
      }
      else if(isEmpty(value.justification) && value.justificationIsRequired){
       
        isSectionValid=false
        return;
      }
      else if(value.documentUploadRequired ){
        let isFilesUploaded;
        
        if(!isEmptyList(documentDetails)){
        $.each(documentDetails,function (key1,value1) {
          if(value1.questionId == value.questionId){
            isFilesUploaded=true
            return;
          }
        })
       }
        if(!isFilesUploaded){
          
          isSectionValid=false
          return;
          }
      }
    }
  })
  if(isSectionValid){
    $('#tick'+id).removeClass('d-none')
  }else{
    $('#tick'+id).addClass('d-none')
  }

}

function onClickEventListener(element, questionAnsObj) {

  let inputType = element.tagName.toLowerCase();
  let elementId = element.id;
  if (inputType == "select") {
    let selectErrorElementId = $(element).siblings()[1].id;
    if (selectErrorElementId == "m360SelectErrorText") {
      errorElement = $(element).siblings()[1];
    }
    let isSelectFieldValid = validateM360Select(element, errorElement);
    isFormValid = isSelectFieldValid;
    if (isSelectFieldValid) {
      questionAnsObj["answerId"] = !isEmpty(
        element.options[element.selectedIndex].value
      )
        ? parseInt(element.options[element.selectedIndex].value)
        : null;
    } else {
      questionAnsObj["answerId"] = null;
    }
    let justificationField=document.getElementById('validationTextarea'+questionAnsObj.questionId)
    let justificationFieldLabel=document.getElementById('validationTextareaLabel'+questionAnsObj.questionId)
    let justificationError = document.getElementById("m360JustificationErrorText"+questionAnsObj.questionId)

    if(!isEmpty(justificationField) && questionAnsObj.justificationIsRequired && !isEmpty(questionAnsObj.questionId)){

       justificationField.classList.add('field-validate')
       justificationFieldLabel.classList.add('required')
       if(isRequiredFieldValidate && isEmpty(justificationField.value)){
         justificationField.classList.add("is-invalid")
         justificationError.innerHTML = m360LookupData.justificationFieldRequiredMsg
         justificationError.classList.remove("d-none")

       }

      
    }
    else if(!isEmpty(justificationField) && !isEmpty(questionAnsObj.questionId)){
        
        justificationFieldLabel.classList.remove('required')
        if(isEmpty(justificationField.value)){
          
          justificationField.classList.remove('field-validate')
          justificationField.classList.remove('is-invalid')
          justificationError.classList.add("d-none")
        }
        else{
          questionAnsObj.justificationIsRequired=true;
        }
    }

    if (isDataEdited(editedBAList, resultDataList)) {
      $("#saveAndCloseBtn").addClass("disabled");
    } else {
      $("#saveAndCloseBtn").removeClass("disabled");
    }
  } else if (inputType == "textarea") {
    errorElement = document.getElementById("m360JustificationErrorText"+elementId.replace("validationTextarea",""));
    element.setAttribute("data-gramm_editor", "false");
    let isTextAreaValid = validateM360TextArea(element, errorElement);
    isFormValid = isTextAreaValid;

    if (isTextAreaValid) {
      questionAnsObj["justification"] = !isEmpty(element.value.trim())
        ? element.value.trim()
        : null;
      questionAnsObj["justificationIsRequired"] = element.classList.contains('field-validate')
    } else {
      questionAnsObj["justification"] = null;
      questionAnsObj["justificationIsRequired"] = true;
    }

    if (isDataEdited(editedBAList, resultDataList)) {
      $("#saveAndCloseBtn").addClass("disabled");
    } else {
      $("#saveAndCloseBtn").removeClass("disabled");
    }
  } else if (inputType == "div") {
    if (element.classList.contains("dropzone")) {
      let fileInstrElementId = element.nextElementSibling.id;
      let fileErrorElementId = (element.nextElementSibling).nextElementSibling.id;
     
      if (fileErrorElementId == "m360FileErrorText") {
        errorElement = (element.nextElementSibling).nextElementSibling
      }
      let isDropZoneValid = validateFileDropZone(element, errorElement);
      isFormValid = isDropZoneValid;
    }
  }
    showOrHideTickMark(questionAnsObj.sectionId)
  
  return isFormValid;
}

function showTab(n) {
  var colwidth = $("#m360baNavBar li.col.nav-item").outerWidth();
  activeindex = n + 1;

  var x = document.getElementsByClassName("container1");
  if (!financialStatement) {
    x = document.getElementsByClassName("container1 show");
  }
  $(x[n]).css({
    display: "block",
  });

  if (window.matchMedia("(max-width: 767px)").matches) {
    let navItemElementList;
    if (x.length == 2) {
      navItemElementList = $("#m360baNavBar li.col.nav-item.no-fs");
    } else {
      navItemElementList = $("#m360baNavBar li.col.nav-item");
    }

    $(navItemElementList).each(function (key, value) {
      if (key == activeindex - 1) {

        value.classList.add("d-block");
        value.classList.remove("d-none");
      } else {

        value.classList.add("d-none");
        value.classList.remove("d-block");
      }

    });
  }


  var calculatedWidth = colwidth * activeindex - colwidth / 2;
  $("#m360baProgressLine").width(calculatedWidth);

  if (n == 0) {
    $("#prevBtn").css({
      display: "none",
    });
    $("#saveAndCloseBtn").css({
      display: "none",
    });
  } else {
    $("#prevBtn").css({
      display: "inline",
    });
    $("#saveAndCloseBtn").css({
      display: "inline",
    });
  }

  if (n == x.length - 1 || !financialStatement) {
    if(!financialStatement){
      document.getElementById("nextBtnLbl").innerHTML = m360LookupData.submit;
    }else{
      document.getElementById("nextBtnLbl").innerHTML = m360LookupData.confirmAndSubmit;
    }
    $("#saveAndCloseBtn").css({
      display: "none",
    });
  } else if (n == x.length - 2) {
    document.getElementById("nextBtnLbl").innerHTML = m360LookupData.next;
  } else {
    document.getElementById("nextBtnLbl").innerHTML = m360LookupData.next;
  }
}

function nextPrev(n, isNextBtnClicked) {
  errorCount = 0;
  isRequiredFieldValidate = true;

  if (currentTab == 0) {
    isRequiredFieldValidate = false;
  }
  var x = document.getElementsByClassName("container1");

  if (!financialStatement) {
    x = document.getElementsByClassName("container1 show");
  }
  
  // if the tab is business analysis questions
  if (currentTab == 1 && isNextBtnClicked && !isEmpty(financialStatement)) {
    isFormValid = true;


    $("#m360Tab2 .field-validate").each(function (key, value) {
      isFormValid = validateBAInputs(value);
    });

    $(".item").each(function (key1, value1) {
      value1.classList.remove("active");
      if (value1.children[2].classList.contains("collapse")) {
        value1.children[2].classList.remove("show");
      }
    });

    let isActiveAdded = false;
    $("#m360Tab2 .error-color").each(function (key, value) {
      let errorParent = value.closest(".item > div");
      let errSibling = errorParent.previousElementSibling;

      if (!value.classList.contains("d-none")) {
        errorClass = true;
      } else {
        errorClass = false;
      }

      if (errorClass) {
        if (!isEmpty(errSibling)) {

          $(".item").each(function (key1, value1) {
            if (value1.id == errSibling.parentNode.id ) {
              value1.classList.add("active");
              value1.children[2].classList.add("show");
              if(!isActiveAdded)
              {
                isActiveAdded = true;
                $("html,body").animate(
                {
                  scrollTop: $(value1).offset().top,
                },
                300
              );
            }

            }
          });
          errorCount++;
          return;
        }
      }
    });


    if (isFormValid && errorCount == 0) {
      if (!isEmptyList(fileUploadTempList)) {
        let accordianItems = $(
          "#accordion #" + fileUploadTempList[0].itemId
        )[0];
        accordianItems.classList.add("active");
        accordianItems.children[2].classList.add("show");
        $("html,body").animate(
          {
            scrollTop: $(accordianItems).offset().top,
          },
          300
        );
      } else {
        $(x[currentTab]).css({
          display: "none",
        });

        currentTab = currentTab + n;
        showTab(currentTab);
      }
    }
  } else if (
    currentTab == 0 &&
    isNextBtnClicked &&
    isEmpty(financialStatement)
  ) {
    let data = {
      certificateRequestDetails: {
        createdBy: userDetails.fullName, // sso user // string
        crNumber: corporateDetails.mci.crNumber,
        nationalId: userDetails.nationalId, //string
      },
      requestorDetails: {
        hasFinancialStatements: resSmeFormDetails.financialStatement,
        showAllTabsSMEForm:financialStatement,
        emailId: userDetails.mail, // sso user //string
      },
    };

    postSMEFormDetails(data, false);
  } else if (currentTab == 2 && isNextBtnClicked) {
    isAgreementChecked = false;
    for (var key in surveyRecipientObject) {
      let value = surveyRecipientObject[key];

      onChangeEventListener($("#" + key + " input[type=email]")[0], value, key);
      onChangeEventListener($("#" + key + " input[type=tel]")[0], value, key);
    }
    onAgreementCheckboxClicked(document.getElementById("agreementCheckBox"));
    isFormValid = true;
    $("#m360Tab3 .is-invalid").each(function (key, value) {
      isFormValid = false;
      return;
    });

    if (isFormValid ) {	
      document
          .getElementById("agreementCheckBox")
          .classList.remove("is-invalid");
      $(x[currentTab]).css({	
        display: "none",	
      });	
    currentTab = currentTab + n;	
    showTab(currentTab);	
    // business analysis details	
    let businessAnalysisDetailList = []	
    $.each(businessAnalysisDetails, function (key, value) {      	
      let arabic = {	
        "name":value["arabic"].name	
      }	
      let english = {	
        "name":value["english"].name	
      }	
      let questions = []	
      //result data - question & answers 	
      $.each(resultDataList, function (key1, value1) {	
         
      if(value.sectionId == value1.sectionId){	
        let arabic = {	
          "answer":"",	
          "question":"",	
        }	
        let english = { 	
          "answer":"",	
          "question":"",	
        }	
        
        $.each(value.questions,function(qKey,qValue){	
          if(qValue.questionId == value1.questionId){	
              arabic.question = qValue.arabic.question	
              english.question = qValue.english.question	
             $.each(qValue.answerNamesAndIds,function(aKey,aValue){	
               if(aValue.id == value1.answerId){	
                arabic.answer = aValue.arabic	
                english.answer = aValue.english	
                return ;	
               }	
             })	
             return ;	
          }	
        })	
        let documents = []	
        // document details	
        $.each(documentDetails, function (key2, value2) {	
     
          if(value1.questionId == value2.questionId){	
            let tempValue={...value2}
            delete tempValue.questionId	
            tempValue['folderName'] = folderName	
            documents.push(tempValue)	
          }   	
            
       
        })	
        questions[questions.length] = {	
          'arabic':arabic,	
          'english':english,	
          'documents':documents,	
          'justification':value1.justification	
        }	
        return	
        }	
      })	
      
      businessAnalysisDetailList[key] ={	
        'arabic':arabic,	
        'english':english,	
        'questions':questions	
      }	
      
    })		
  
    //survey details	
    let surveyDetailList = []	
    $.each(surveyDetails,function(skey,sValue){	
        
      let surveyRecipientDetailList =[]	
      $.each(surveyRecipientObject,function(skey1,sValue1){	
        if(sValue1.surveyTypeId == sValue.surveyTypeId){	
          let temp={	
            "code":sValue1.dialCode,	
            "email":sValue1.emailId,	
            "mobileNum":sValue1.phoneNumber	
          }	
          surveyRecipientDetailList.push(temp)	
        }	
      })	
      surveyDetailList[skey] = {	
        "type":sValue.type,	
        "value":surveyRecipientDetailList	
      }    	
    })	
    $("#reviewTab1").empty()
    $("#reviewTab2").empty()
    $("#reviewTab3").empty()	
    $("#reviewTab1Title").empty()
    $("#reviewTab2Title").empty()
    $("#reviewTab3Title").empty()	
    document.getElementById("reviewTab1Title").innerHTML =  m360LookupData.corporateDetails;
    document.getElementById("reviewTab3Title").innerHTML = m360LookupData.survey;
    document.getElementById("reviewTab2Title").innerHTML =  m360LookupData.businessAnalysisQuestions;
    loadCorporateDetails(corporateDetails,m360LookupData,"reviewTab1")
    loadBusinessAnalysisDetails(businessAnalysisDetailList,m360LookupData,"reviewTab2")
    loadSurveyDetails(surveyDetailList,m360LookupData,"reviewTab3")
  }	
  }else if(currentTab == 3 && isNextBtnClicked){
    surveyRecipientDetails = Object.values(surveyRecipientObject);
    // let addedDocumentNameList = [];
    // for (i = 0; i < documentDetails.length; i++) {
    //   addedDocumentNameList.push(documentDetails[i].frontEndName);
    // }
    for (var i = resultDataList.length; i--;) {
      delete resultDataList[i].justificationIsRequired
      delete resultDataList[i].documentUploadRequired
    }
    let data = {
      questionAnswerDetails: resultDataList,
      surveyRecipientDetails: surveyRecipientDetails,
      certificateRequestDetails: {
        createdBy: userDetails.fullName, // sso user //string
        crNumber: corporateDetails.mci.crNumber,
        nationalId: userDetails.nationalId,
        agreementId: agreementId,
        termsAndConditionsId:termsAndConditionsId,
      },
      requestorDetails: {
        hasFinancialStatements: resSmeFormDetails.financialStatement,
        showAllTabsSMEForm:financialStatement,
        emailId: userDetails.mail, // sso user //string
      },
      feFolderName: folderName,
      documentDetails: documentDetails,
      deleteFileList: deleteFileList,
      feTempFolderName: feTempFolderName,
      certificateScoreCardMappingDetails: certificateScoreCardMappingDetails,
    };
    postSMEFormDetails(data, false);
  } else {
    $(x[currentTab]).css({
      display: "none",
    });

    currentTab = currentTab + n;
    showTab(currentTab);
  }
}

function postSMEFormDetails(data, isDraft) {

  let url = SME_FORM_POST_URL;
  finalResponseData = JSON.stringify(data);
  if (isDraft) {
    url = SME_FORM_DRAFT_POST_URL;
  }
  $.ajax({
    beforeSend: function () {
      $("#loaderContainer").removeClass("d-none");
      $("#btnSection1").addClass("d-none");
      if (financialStatement) {
      document.getElementById("submissionTitle").innerHTML =m360LookupData.submission;
      }
    },
    type: "POST",
    url: url, //url
    data: JSON.stringify(data),
    success: function (data) {
      if (data.isReload) {
        window.location.reload()
      }
      else {
        var x = document.getElementsByClassName("container1");
        if (!financialStatement) {
          x = document.getElementsByClassName("container1 show");
        }
        if(currentTab!=3)
        {$(x[currentTab]).css({
          display: "none",
        });}

        if (isDraft && currentTab == 1) {
          currentTab = currentTab + 2;
          showTab(currentTab); // from ba form to submission
        } else if(currentTab!=3){
          currentTab = currentTab + 1;
          showTab(currentTab);
        }
        $('#submissionTabContainer').removeClass("d-none");
        $('#reviewTabContainer').addClass("d-none");

        $("#submissionDoneBtn").removeClass("d-none");
        $("#imgSubmission").removeClass("d-none");
        $("#errorImage").addClass("d-none");
        document.getElementById("thanksContent").innerHTML =
          data.messageInfo[lang].messageDescription;
        document.getElementById("submitContentTitle").innerHTML =
          data.messageInfo[lang].messageTitle;
        if (data.messageInfo["isError"] && financialStatement) {
          $("#imgSubmission").addClass("d-none");
          $("#errorImage").removeClass("d-none");
          $("#btnSection1").removeClass("d-none");
          $("#prevBtn").addClass("d-none");
          $("#submissionDoneBtn").addClass("d-none");
          $("#nextBtn").addClass("d-none");
          $("#saveAndCloseBtn").addClass("d-none");
          if (isDraft) {
            $("#retryBtnSubmit").addClass("d-none");
            $("#retryBtnDraft").removeClass("d-none");
            document.getElementById("retryBtnDraft").innerHTML =
              m360LookupData.pleasetryagain; //string
          } else {
            $("#retryBtnSubmit").removeClass("d-none");
            $("#retryBtnDraft").removeClass("d-none");
            document.getElementById("retryBtnDraft").innerHTML = m360LookupData.saveAndCloseButton; //string
            document.getElementById("retryBtnSubmit").innerHTML =
              m360LookupData.pleasetryagain; //string
          }
        }
      }

    },
    error: function (err) {
      var x = document.getElementsByClassName("container1");
      if (!financialStatement) {
        x = document.getElementsByClassName("container1 show");
      }
      if(currentTab!=3)
      {$(x[currentTab]).css({
        display: "none",
      });}
      if (isDraft && currentTab == 1) {
        currentTab = currentTab + 2;
        showTab(currentTab); // from ba form to submission
      } else if(currentTab!=3){
        currentTab = currentTab + 1;
        showTab(currentTab);
      }
      $('#submissionTabContainer').removeClass("d-none");
      $('#reviewTabContainer').addClass("d-none");
     
      $("#loaderContainer").addClass("d-none");
      $("#imgSubmission").addClass("d-none");
      $("#errorImage").removeClass("d-none");
      let errorData = COMMON_ERROR_MESSAGE;
      if (financialStatement) {
        $("#btnSection1").removeClass("d-none");
        $("#prevBtn").addClass("d-none");
        $("#submissionDoneBtn").addClass("d-none");
        $("#nextBtn").addClass("d-none");
        $("#saveAndCloseBtn").addClass("d-none");
        if (isDraft) {
          $("#retryBtnSubmit").addClass("d-none");
          $("#retryBtnDraft").removeClass("d-none");
          document.getElementById("retryBtnDraft").innerHTML =
            m360LookupData.pleasetryagain; //string
        } else {
          $("#retryBtnSubmit").removeClass("d-none");
          $("#retryBtnDraft").removeClass("d-none");
          document.getElementById("retryBtnDraft").innerHTML = m360LookupData.saveAndCloseButton; //string
          document.getElementById("retryBtnSubmit").innerHTML =
            m360LookupData.pleasetryagain; //string
        }
      } else {
        $("#submissionDoneBtn").removeClass("d-none");
      }
      document.getElementById("thanksContent").innerHTML =
        errorData.messageInfo[lang].messageDescription;
      document.getElementById("submitContentTitle").innerHTML =
        errorData.messageInfo[lang].messageTitle;
    },
    complete: function () {
      $("#loaderContainer").addClass("d-none");
    },
  });
}

function onSaveAndCloseButtonClicked() {
  errorCount = 0;
  surveyRecipientDetails = Object.values(surveyRecipientObject);
  isFormValid = true;
  isRequiredFieldValidate = false;

  $("#m360Tab2 .field-validate").each(function (key, value) {
    isFormValid = validateBAInputs(value);
  });

  $(".item").each(function (key1, value1) {
    value1.classList.remove("active");
    if (value1.children[2].classList.contains("collapse")) {
      value1.children[2].classList.remove("show");
    }
  });

  let isActiveAdded = false;
  $("#m360Tab2 .error-color").each(function (key, value) {
    let errorParent = value.closest(".item > div");
    let errSibling = errorParent.previousElementSibling;

    if (!value.classList.contains("d-none")) {
      errorClass = true;
    } else {
      errorClass = false;
    }

    if (errorClass) {
      if (!isEmpty(errSibling)) {
        $(".item").each(function (key1, value1) {
          if (value1.id == errSibling.parentNode.id ) {
            value1.classList.add("active");
            value1.children[2].classList.add("show");
            if(!isActiveAdded)
            {
              isActiveAdded = true;
            $("html,body").animate(
              {
                scrollTop: $(value1).offset().top,
              },
              300
            );
          }
          }
        });

        errorCount++;
        return;
      }
    }
  });
  for (var key in surveyRecipientObject) {
    let value = surveyRecipientObject[key];

    onChangeEventListener($("#" + key + " input[type=email]")[0], value, key);
    onChangeEventListener($("#" + key + " input[type=tel]")[0], value, key);
  }
  onAgreementCheckboxClicked(document.getElementById("agreementCheckBox"));

  $("#m360Tab3 .is-invalid").each(function (key, value) {

    isFormValid = false;
    return false;
  });
  if (isFormValid && errorCount == 0) {
    //removing the null data object from the list - non edited fields

    for (var i = resultDataList.length; i--;) {
      delete resultDataList[i].justificationIsRequired;
      delete resultDataList[i].documentUploadRequired;
      if (
        isEmpty(resultDataList[i].answerId) &&
        isEmpty(resultDataList[i].justification)
      ) {
        resultDataList.splice(i, 1);
      }
      
    }
    // let addedDocumentNameList = [];
    // for (i = 0; i < documentDetails.length; i++) {
    //   addedDocumentNameList.push(documentDetails[i].frontEndName);
    // }
    for (var i = surveyRecipientDetails.length; i--;) {
      if (
        isEmpty(surveyRecipientDetails[i].emailId) &&
        isEmpty(surveyRecipientDetails[i].phoneNumber)
      ) {
        surveyRecipientDetails.splice(i, 1);
      }
    }
    let data = {
      questionAnswerDetails: resultDataList,
      surveyRecipientDetails: surveyRecipientDetails,
      saveDraftMasterDetails: {
        crNumber: corporateDetails.mci.crNumber,
        nationalId: userDetails.nationalId,
      },
      feFolderName: folderName,
      documentDetails: documentDetails,
      deleteFileList: deleteFileList,
      feTempFolderName: feTempFolderName,
    };

    postSMEFormDetails(data, true);
  } else {
    if (currentTab == 1 && errorCount == 0) {
      var x = document.getElementsByClassName("container1");
      if (!financialStatement) {
        x = document.getElementsByClassName("container1 show");
      }
      $(x[currentTab]).css({
        display: "none",
      });
      currentTab = currentTab + 1
      showTab(currentTab)
    }
  }


}

function retryHandler(isDraft) {
  currentTab = currentTab - 1;
  postSMEFormDetails(JSON.parse(finalResponseData), isDraft);
}

function onAgreementCheckboxClicked(element) {
  if (element.checked) {
    isAgreementChecked = true;
    element.classList.remove("is-invalid");
  } else if (isRequiredFieldValidate) {
    isAgreementChecked = false;
    element.classList.add("is-invalid");
  } else {
    element.classList.remove("is-invalid");
  }
}
