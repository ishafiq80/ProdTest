
const CR_RECORD_REPORT_STATUS_WAITING = 528
const CR_REQUEST_REPORT_STATUS_GENERATED = 529
const REPORT_STATUS_N0_FS_WAITING = 534

let isDraftAvailable, crNoEvent, smeFormDetails,userDetails,footerDetails;
function createCRRecord(recordDetail,crLookUpData,profileDetails,footerData) {

    userDetails = profileDetails
    footerDetails = footerData;
    let crContainer = document.createDocumentFragment();

    let cardContainer = document.createElement("div");
    cardContainer.classList.add("col-12")
    cardContainer.classList.add("col-sm-6")
    cardContainer.classList.add("col-md-6")
    cardContainer.classList.add("col-lg-3")

    cardContainer.classList.add("row-padding-bottom")

    let cardContentContainer = document.createElement("div");
    cardContentContainer.classList.add("card")
    cardContentContainer.classList.add("DS")

    let cardBodyContainer = document.createElement("div");
    cardBodyContainer.classList.add("card-body");

    let crWithImg = document.createElement("div")
    crWithImg.classList.add("row")
    crWithImg.classList.add("align-items-center")


    let crDetailsImgDiv = document.createElement("div")
    crDetailsImgDiv.classList.add("d-flex")

    let companyImg = document.createElement("img")
    companyImg.src = companyImgSrc
    companyImg.classList.add("logo");
    companyImg.classList.add("company-logo")
    companyImg.classList.add("mb-3");
    companyImg.classList.add("text-center");

    let companyDetailsDiv = document.createElement("div");
    companyDetailsDiv.classList.add("company-detail")

    let companyName = document.createElement("h5");
    companyName.classList.add("mb-0")
    companyName.classList.add("company-name")
    companyName.innerHTML = !isEmpty(recordDetail.companyName)?recordDetail.companyName:"" //string

    let crNumberLbl = document.createElement("h5");
    crNumberLbl.classList.add("card-text")
    crNumberLbl.classList.add("mb-0")
    crNumberLbl.innerHTML = crLookUpData.crNum

    let crNumber = document.createElement("h5");
    // crNumber.classList.add("card-text")
    crNumber.classList.add("mb-0")
    crNumber.innerHTML = recordDetail.crNumber

    companyDetailsDiv.append(companyName)
    companyDetailsDiv.append(crNumberLbl)
    companyDetailsDiv.append(crNumber)

    crDetailsImgDiv.append(companyImg)
    crDetailsImgDiv.append(companyDetailsDiv)
    crWithImg.append(crDetailsImgDiv)

    let submittedDate = document.createElement("p")
    submittedDate.classList.add("black-color")
    submittedDate.classList.add("mt-4")
    var submissionDate = !isEmpty(recordDetail.lastSubmittedOn) ? getFormattedDate(recordDetail.lastSubmittedOn) : ""
    submittedDate.innerHTML = !isEmpty(recordDetail.lastSubmittedOn) ? (crLookUpData.lastSubmittedOn + " " + submissionDate) : ""


    let statusDiv = document.createElement("div")
    statusDiv.classList.add("d-flex");
    statusDiv.classList.add("justify-content-left");

    let stsIcon = document.createElement("img")
    stsIcon.classList.add("mr-1")
    stsIcon.classList.add("mt-1")

    let stsTextDiv = document.createElement("div")
    stsTextDiv.classList.add("comment-date")
    stsTextDiv.classList.add("mt-2")

    let stsText = document.createElement("span")
    stsText.classList.add("tick-text")

    stsText.innerHTML = recordDetail.statusInfo[lang]['lastRequestStatus']

    if (recordDetail.statusInfo.statusId == CR_RECORD_REPORT_STATUS_WAITING || recordDetail.statusInfo.statusId==REPORT_STATUS_N0_FS_WAITING) {
        stsIcon.src = iconCaution;
        stsText.setAttribute("style", "color:#FF8500")
    } else if (recordDetail.statusInfo.statusId == CR_REQUEST_REPORT_STATUS_GENERATED) {
        stsIcon.src = iconTick;
        stsText.setAttribute("style", "color:#5CB366")
    }else{
        stsIcon.src = iconTick;
    }

    stsTextDiv.append(stsText)

    statusDiv.append(stsIcon)
    statusDiv.append(stsTextDiv)

    let reportCount = document.createElement("a");
    reportCount.href = REPORT_URL + recordDetail.crNumber //url
    reportCount.classList.add("card-text")
    reportCount.classList.add("mt-2")
    reportCount.classList.add("mb-0")
    reportCount.classList.add("report-label")
    reportCount.innerHTML = crLookUpData.viewAllReports + " (" + recordDetail.noOfAssessment + ")" // string



    let applyBtn = document.createElement("button")
    applyBtn.classList.add("btn")
    applyBtn.classList.add("btn-sm")
    applyBtn.classList.add("btn-outline-primary")
    applyBtn.classList.add("DS")
    applyBtn.classList.add("hvr-top")
    applyBtn.classList.add("rounded-pill")
    applyBtn.classList.add("align-items-center")
    applyBtn.classList.add("apply-button")
    applyBtn.classList.add("mt-4")
    applyBtn.setAttribute("id", recordDetail.crNumber)
    applyBtn.addEventListener("click", function (event) {
        onApplyButtonClicked(event, recordDetail.isSaveDraft,crLookUpData,profileDetails,footerData)
    })

    if (!recordDetail.readyForSubmission) {
        applyBtn.classList.add("disabled")
    }


    let btnText = document.createElement("span")
    btnText.innerHTML = crLookUpData.applyForM360
    btnText.setAttribute("id", recordDetail.crNumber)

    applyBtn.append(btnText)

    cardBodyContainer.append(crWithImg)
    cardBodyContainer.append(submittedDate)
    cardBodyContainer.append(statusDiv)
    cardBodyContainer.append(reportCount)
    cardBodyContainer.append(applyBtn)

    if (!recordDetail.readyForSubmission) {
        let nextSubmissionInfo = document.createElement("p")
        nextSubmissionInfo.classList.add("submission-info")
        nextSubmissionInfo.innerHTML = crLookUpData.nextSubmission + " " + getFormattedDate(recordDetail.nextSubmissionDate)
        cardBodyContainer.append(nextSubmissionInfo)
    }

    cardContentContainer.append(cardBodyContainer)

    cardContainer.append(cardContentContainer)

    crContainer.append(cardContainer)

    document.getElementById("crListContainer").appendChild(crContainer)

}

function onModalContinueButtonClicked() {
    if (isDraftAvailable) {
        getSMEFormDetails(crNoEvent, isDraftAvailable,userDetails,footerDetails,false)
    } else {
        loadm360Form(financialStatement, smeFormDetails, isDraftAvailable,userDetails)
    }
    $("#popupContinueBtn").attr("data-dismiss", "modal");
}

function onModalNoBtnClicked(event) {
    
    if (isDraftAvailable && event.id == "noBtnLbl") {
        getSMEFormDetails(crNoEvent, false,userDetails,footerDetails,true) // false - not to load edited data
    }
    $("#noBtnLabel").attr("data-dismiss", "modal");

}

function getSMEFormDetails(event, isSaveDraft,profileDetails,footerData,isCreateFromStart) {
    let m360FormDetails;
    if (isEmpty(m360FormDetails)) {
        
        let id = event.target.id
        let supportTicketDetails={
                "supportTicketDetails":
                {
                    "requestorName": null,
                    "nationalId":null,
                    "crNumber":id,
                    "requestorEmailId": null,
                    "requestorMobNo": null,
                    "issue": null,
                    "assessmentNo": null,
                    "queries": null,
                    "supportPersonEmailId": null
                }
        }
        if(!isEmptyObject(profileDetails)){
            supportTicketDetails.supportTicketDetails.requestorName=profileDetails.fullName
            supportTicketDetails.supportTicketDetails.requestorEmailId=profileDetails.mail
            supportTicketDetails.supportTicketDetails.issue=footerData.lookupInfo[lang].issueInAssessment
            supportTicketDetails.supportTicketDetails.supportPersonEmailId=footerData.formInfo.emailId
            supportTicketDetails.supportTicketDetails.nationalId=profileDetails.nationalId
        }

        $.ajax({
            beforeSend: function () {
                $("#loaderContainer").removeClass("d-none");
                $("#responseContainer").addClass('d-none');
            },
            type: 'POST',
            url: SME_FORM_GET_URL, //url
            data: JSON.stringify({ crNumber: id,isSaveDraft:isSaveDraft,isCreateFromStart:isCreateFromStart,supportTicketDetails:JSON.stringify(supportTicketDetails),lang:lang=='arabic'?'ar':'en'}),
            success: function (data) {
                if(data.isReload){
                    // window.location=LANDING_URL
                    window.location.reload()
                }
                else if (data.hasOwnProperty("messageInfo")) {
                    $("#loaderContainer").addClass("d-none");
                    $("#crRecordsContainer").addClass("d-none");
                    createServiceResponseCard(data)
                    $("#crRecordsSection").addClass('d-none')
                    $("#responseContainer").removeClass('d-none')
                    
                }
                else if(data.hasOwnProperty("isB2BFailed")){
                    let msgInfo={
                        messageInfo: {
                            english: {
                              messageTitle: "Service unavailable!",
                              messageDescription:headerLookUpDetails.errorMessageForB2BP1+'<a id="b2bContactLink" >'+headerLookUpDetails.errorMessageForB2BP2+'</a>'+"."+'<p>'+headerLookUpDetails.errorMessageForB2BP3+'<a id=b2bEmailLink>'+footerData.formInfo.emailId+'</a>'+'</p>',
                              btnText:"Return to home"
                            },
                            arabic: {
                              messageTitle: "الخدمة غير متوفرة!‎",
                              messageDescription:headerLookUpDetails.errorMessageForB2BP1+" "+'<a id="b2bContactLink" >'+" "+headerLookUpDetails.errorMessageForB2BP2+'</a>'+"."+'<p class="b2bEmailPTag">'+headerLookUpDetails.errorMessageForB2BP3+" "+'<a id=b2bEmailLink>'+footerData.formInfo.emailId+'</a>'+" "+'</p>',
                              btnText:"العودة إلى الصفحة الرئيسية"
                            }
                    }
                    }
                    $("#loaderContainer").addClass("d-none");
                    $("#crRecordsContainer").addClass("d-none");
                    createServiceResponseCard(msgInfo)
                    $('#b2bContactLink').attr('href',CONTACT_URL);
                    document.getElementById("b2bEmailLink").href = "mailto:" + footerData.formInfo.emailId
                    $("#crRecordsSection").addClass('d-none')
                    $("#responseContainer").removeClass('d-none')
                }
                else {
                    $("#crRecordsSection").removeClass('d-none')
                    $("#responseContainer").addClass('d-none')
                    $("#crRecordsContainer").removeClass("d-none");
                    $("#m360Tab1Content").empty()
                    $("#accordion").empty()
                    $("#emailMobileContainer").empty()
                    $("#surveyDetailsTitleDiv").empty()
                    m360FormDetails = JSON.parse(JSON.stringify(data))
                    smeFormDetails = m360FormDetails
                    
                    // financialStatement = isEmpty(m360FormDetails.smeFormDetails.formInfo.financialStatement) ? false : true
                    financialStatement = m360FormDetails.smeFormDetails.formInfo.showAllTabsSMEForm

                    if (isEmpty(financialStatement)) {
                        $("#loaderContainer").addClass("d-none");
                        $("#crRecordsSection").removeClass("d-none");
                        m360LookupData = m360FormDetails.smeFormDetails.lookupInfo[lang]
                        document.getElementById("popupContinueBtn").innerHTML = m360LookupData.continue
                        document.getElementById("noBtnLbl").innerHTML = m360LookupData.noCancel
                        document.getElementById("noCancelSection").classList.add("d-none")
                        document.getElementById("popupContinueBtn").classList.remove("mt-2")
                        document.getElementById("continueSection").classList.remove("col-8")
                        document.getElementById("noFinancialStatementTxt").innerHTML = m360LookupData.sorrynoFinancialStmt

                        document.getElementById("subText").innerHTML = m360LookupData.continueToApply

                        let element = event.target
                        element.setAttribute("data-toggle", "modal")
                        element.setAttribute("data-target", "#modal")

                        $("#modal").modal("show")

                    }


                    else {
                        $("#crRecordsSection").addClass("d-none");
                        loadm360Form(financialStatement, m360FormDetails, isSaveDraft,userDetails)
                    }
                }

            },
            error: function (error) {
                $("#crRecordsContainer").addClass("d-none");
                createServiceResponseCard(error)
                $("#crRecordsSection").addClass('d-none')
                $("#responseContainer").removeClass('d-none')
            },
            complete: function () {
                $("#loaderContainer").addClass("d-none");

            }


        });
    }

}

function onApplyButtonClicked(event, isSaveDraft,crLookUpData,profileDetails,footerData) {

    currentTab = 0
    errorCount = 0
    isFormValid = true
    isErrorExist = false
    crNoEvent = event
    isDraftAvailable = isSaveDraft
    let element = event.target
    element.removeAttribute("data-toggle", "modal")
    element.removeAttribute("data-target", "#modal")

    if (isSaveDraft) { // if draft exists - show popover
        document.getElementById("popupContinueBtn").innerHTML = crLookUpData.continue //string
        document.getElementById("noBtnLbl").innerHTML = crLookUpData.createFromStart //string
        document.getElementById("noCancelSection").classList.remove("d-none")
        document.getElementById("continueSection").classList.add("col-8")
        document.getElementById("popupContinueBtn").classList.add("mt-2")
        document.getElementById("cancelBtnLbl").innerHTML = crLookUpData.cancel //string
        document.getElementById("noFinancialStatementTxt").innerHTML = crLookUpData.draftAvailable //string

        document.getElementById("subText").innerHTML = crLookUpData.continueWithDraft //string
        element.setAttribute("data-toggle", "modal")
        element.setAttribute("data-target", "#modal")
        $("#modal").modal("show")

    } else { // if no draft - load the sme 
        getSMEFormDetails(event, isSaveDraft,profileDetails,footerData,false) //isSaveDraft
    }

}