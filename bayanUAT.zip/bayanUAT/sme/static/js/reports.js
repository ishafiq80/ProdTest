let initialFilterObj = {
  year: null,
  quarter: null,
  assessmentDate: null,
  searchText: null,
  sortField: "requestNo",
  sortDir: "asc",
  sortType: null
}

const REPORT_STATUS_WAITING = 528
const REPORT_STATUS_GENERATED = 529
const REPORT_STATUS_N0_FS_WAITING = 534

let startPageNumber = 1

let filteredObject = JSON.parse(JSON.stringify(initialFilterObj))

function clearFilter(newReportList) {

  // clear the select option
  $("#reportsContainer select").each(function (key, value) {
    $(this).prop('selectedIndex', 0)
    $("#" + value.id).val(null).trigger('change');

  })

  // clear the input
  document.getElementById("reportSearch").value = ""
  $('.date-picker').val("").datepicker("update");

  // reload the list
  $("#reportTable tbody tr").remove();
  $("#paginationDiv a").remove();

  filteredObject = JSON.parse(JSON.stringify(initialFilterObj))
  startPageNumber = 1
  $('#pageNumberDiv').remove();
  getPaginatedList(newReportList)
  sortTable(1, 'number', 'requestNo')

}

function onChangeListener(event) {

  let elementId = event.target.id;
  let element = event.target;
  switch (elementId) {
    case "yearSelect":
      filteredObject["year"] = element.value;
      break;
    case "quarterSelect":
      filteredObject["quarter"] = element.value;
      break;
    case "datePicker":
      filteredObject["assessmentDate"] = event.format();
      break;
    default:
      break;
  }
  $("#reportTable tbody tr").remove();
  loadFilteredReportDetails(filteredObject);
}

function converDateForSortFormat(dateStr) {
  var p = dateStr.split("/");
  return +(p[2] + p[1] + p[0]);
}

function loadFilterField(filterFieldLookup) {

  $.each(filterFieldLookup.quarterList, function (key, value) {
    var option = document.createElement("option");
    option.innerHTML = value;
    document.getElementById("quarterSelect").append(option)

  })
  $('#quarterSelect').select2({
    minimumResultsForSearch: -1,
    dropdownParent: $('#quarterSelectDiv'),
    dropdownPosition: 'below'
  });
  $.each(filterFieldLookup.yearList, function (key, value) {
    var option = document.createElement("option");
    option.innerHTML = value;
    document.getElementById("yearSelect").append(option)

  })
  $('#yearSelect').select2({
    minimumResultsForSearch: -1,
    dropdownParent: $('#yearSelectDiv'),
    dropdownPosition: 'below'
  });
}

function getLowerCaseStr(text) {
  return !isEmpty(text) ? text.toString().toLowerCase() : ""
}

function loadFilteredReportDetails(filteredObject) {
  let reportList = reportDetails.reportsDetails.formInfo;


  let filteredList = [],
    isNotToAdd = false;
  $.each(reportList, function (key, value) {
    isNotToAdd = false;

    concatText = getLowerCaseStr(getFormattedDate(value.assessmentDate)) +
      getLowerCaseStr(value.certificateNo) +
      getLowerCaseStr(value.crNumber) +
      getLowerCaseStr(value.quarter) +
      getLowerCaseStr(value.requestNo) +
      getLowerCaseStr(value.year)



    if (!isEmpty(filteredObject.year) && value["year"] != filteredObject.year) {
      isNotToAdd = true;
    }
    if (
      !isEmpty(filteredObject.assessmentDate) &&
      getFormattedDate(value["assessmentDate"]) != filteredObject.assessmentDate
    ) {
      isNotToAdd = true;
    }

    if (
      !isEmpty(filteredObject.quarter) &&
      value["quarter"] != filteredObject.quarter
    ) {
      isNotToAdd = true;
    }
    if (
      !isEmpty(filteredObject.searchText) &&
      !concatText.includes(filteredObject.searchText.toLowerCase().trim())
    ) {
      isNotToAdd = true;
    }

    if (!isNotToAdd) {
      filteredList.push(value);
    }
  });
  if (isEmptyList(filteredList) && !isNotToAdd) {
    filteredList = reportList
  }
  if (!isEmpty(filteredObject.sortField)) {
    switch (filteredObject.sortType) {
      case 'text':
        filteredList.sort(function (a, b) {
          a[filteredObject.sortField] = a[filteredObject.sortField] == null ? "" : a[filteredObject.sortField];
          b[filteredObject.sortField] = b[filteredObject.sortField] == null ? "" : b[filteredObject.sortField];
          let valueA = a[filteredObject.sortField].toLowerCase(), valueB = b[filteredObject.sortField].toLowerCase()
          if (filteredObject.sortDir == 'dsc')
            valueA = b[filteredObject.sortField].toLowerCase(), valueB = a[filteredObject.sortField].toLowerCase()
          if (valueA < valueB) //sort string ascending
            return -1
          if (valueA > valueB)
            return 1
          return 0 //default return value (no sorting)
        })
        break
      case 'date':
        filteredList.sort(function (a, b) {
          let dateA = new Date(a[filteredObject.sortField]), dateB = new Date(b[filteredObject.sortField])
          if (filteredObject.sortDir == 'asc')
            return dateA - dateB //sort by date ascending
          if (filteredObject.sortDir == 'dsc')
            return dateB - dateA //sort by date descending
        })
        break
      case 'number':
        filteredList.sort(function (a, b) {
          // asc
          if (filteredObject.sortDir == 'asc')
            return parseFloat(a[filteredObject.sortField]) - parseFloat(b[filteredObject.sortField]);
          // des
          if (filteredObject.sortDir == 'dsc')
            return parseFloat(b[filteredObject.sortField]) - parseFloat(a[filteredObject.sortField]);
        });
        break
      default:
        break

    }

  }
  if (!isEmptyList(filteredList) || isNotToAdd) {
    startPageNumber = 1
    $('#pageNumberDiv').remove();
    $("#paginationDiv a").remove();
    getPaginatedList(filteredList);
  }
}

function getPaginatedList(reportList) {
  if (reportList.length > pageSize) {
    var totalPaginate = Math.ceil(reportList.length / pageSize);

    var paginationDoubleLeftArrow = document.createElement('a');
    paginationDoubleLeftArrow.setAttribute('id', 'leftDoubleArrow');
    paginationDoubleLeftArrow.classList.add('pagination-anchor')
    paginationDoubleLeftArrow.innerHTML = '&laquo';
    if (!(reportList.length <= pageNumberSetLimit * pageSize)) {
      if (lang == "arabic") {
        document.getElementById("paginationDiv").prepend(paginationDoubleLeftArrow)
      } else {
        document.getElementById("paginationDiv").append(paginationDoubleLeftArrow)
      }
    }

    var paginationLeftArrow = document.createElement('a');
    paginationLeftArrow.setAttribute('id', 'leftArrow');
    paginationLeftArrow.classList.add('pagination-anchor')
    paginationLeftArrow.innerHTML = '&lsaquo;';
    if (!(reportList.length <= pageNumberSetLimit * pageSize)) {
      if (lang == "arabic") {
        document.getElementById("paginationDiv").prepend(paginationLeftArrow)
      } else {
        document.getElementById("paginationDiv").append(paginationLeftArrow)
      }
    }
    var paginationLeftDot = document.createElement('a');
    paginationLeftDot.setAttribute('id', 'leftDot');
    paginationLeftDot.setAttribute('style', 'color: black !important;');
    paginationLeftDot.classList.add('pagination-anchor');
    paginationLeftDot.classList.add('disabled');
    paginationLeftDot.innerHTML = '..'
    if (lang == "arabic") {
      document.getElementById("paginationDiv").prepend(paginationLeftDot)
    } else {
      document.getElementById("paginationDiv").append(paginationLeftDot)
    }

    var pageNumberDiv = document.createElement('span');
    pageNumberDiv.setAttribute('id', 'pageNumberDiv');
    if (lang == "arabic") {
      document.getElementById("paginationDiv").prepend(pageNumberDiv)
    } else {
      document.getElementById("paginationDiv").append(pageNumberDiv)
    }
    createPageNumberSet(startPageNumber, totalPaginate, reportList)


    var paginationRightArrow = document.createElement('a');
    paginationRightArrow.setAttribute('id', 'rightArrow');
    paginationRightArrow.classList.add('pagination-anchor')
    paginationRightArrow.innerHTML = '&rsaquo;';
    paginationRightArrow.setAttribute('value', '&rsaquo;');
    if (!(reportList.length <= pageNumberSetLimit * pageSize)) {
      if (lang == "arabic") {
        document.getElementById("paginationDiv").prepend(paginationRightArrow)
      } else {
        document.getElementById("paginationDiv").append(paginationRightArrow)
      }
    }

    var paginationDoubleRightArrow = document.createElement('a');
    paginationDoubleRightArrow.setAttribute('id', 'rightDoubleArrow');
    paginationDoubleRightArrow.classList.add('pagination-anchor')
    paginationDoubleRightArrow.innerHTML = '&raquo';
    if (!(reportList.length <= pageNumberSetLimit * pageSize)) {
      if (lang == "arabic") {
        document.getElementById("paginationDiv").prepend(paginationDoubleRightArrow)
      } else {
        document.getElementById("paginationDiv").append(paginationDoubleRightArrow)
      }
    }
    $("#rightArrow").click(function (event) {
      startPageNumber++;
      if (startPageNumber <= totalPaginate) {
        $('#pageNumberDiv a').remove();
        $("#reportTable tbody tr").remove();
        $("#leftArrow").removeClass('disabled');
        $("#leftDoubleArrow").removeClass('disabled');
        $("#leftDot").show()
        let startPage = (startPageNumber)
        createPageNumberSet(startPage, totalPaginate, reportList)
        loadReportTableDetails(reportList.slice((startPage * pageSize) - pageSize, (startPage * pageSize)));
      }
    });
    $("#leftArrow").click(function (event) {

      if (startPageNumber > 1) {
        startPageNumber--;
      }
      $('#pageNumberDiv a').remove();
      $("#reportTable tbody tr").remove();

      $("#rightArrow").removeClass('disabled');
      $("#rightDoubleArrow").removeClass('disabled');
      $("#rightDot").show()
      let startPage = startPageNumber
      createPageNumberSet(startPage, totalPaginate, reportList)
      loadReportTableDetails(reportList.slice((startPage * pageSize) - pageSize, (startPage * pageSize)));
    });
    $("#rightDoubleArrow").click(function (event) {

      $('#pageNumberDiv a').remove();
      $("#reportTable tbody tr").remove();
      $("#leftArrow").removeClass('disabled');
      $("#leftDoubleArrow").removeClass('disabled');
      $("#leftDot").show()
      startPageNumber = totalPaginate - pageNumberSetLimit + 1
      let startPage = totalPaginate - pageNumberSetLimit + 1
      createPageNumberSet(startPage, totalPaginate, reportList)
      loadReportTableDetails(reportList.slice((startPage * pageSize) - pageSize, startPage * pageSize));

    });
    $("#leftDoubleArrow").click(function (event) {

      $('#pageNumberDiv a').remove();
      $("#reportTable tbody tr").remove();
      $("#rightArrow").removeClass('disabled');
      $("#rightDoubleArrow").removeClass('disabled');
      $("#rightDot").show()
      startPageNumber = 1
      createPageNumberSet(startPageNumber, totalPaginate, reportList)
      loadReportTableDetails(reportList.slice(0, 10));

    });

  }
  loadReportTableDetails(reportList.slice(0, 10));
}

function createPageNumberSet(startPage, totalPaginate, reportList) {
  let tempI = startPage;
  for (var i = startPage; (i < (startPage + pageNumberSetLimit)) && (i <= (totalPaginate)); i++) {
    var anchor = document.createElement("a");
    anchor.classList.add("pagination-anchor");
    anchor.innerHTML = i;
    if (i == startPage) {
      anchor.classList.add("active");
    }
    if (i == 1) {
      $("#leftArrow").addClass('disabled')
      $("#leftDoubleArrow").addClass('disabled')
      $("#leftDot").hide()
    }
    if (i == totalPaginate) {
      $("#rightArrow").addClass('disabled')
      $("#rightDoubleArrow").addClass('disabled')
      $("#rightDot").hide()
    }
    if (lang == "arabic") {
      document.getElementById("pageNumberDiv").prepend(anchor);
    } else {
      document.getElementById("pageNumberDiv").append(anchor);
    }
    tempI = i

  }
  var paginationRightDot = document.createElement('a');
  paginationRightDot.setAttribute('id', 'rightDot');
  paginationRightDot.setAttribute('style', 'color: black !important;');
  paginationRightDot.classList.add('pagination-anchor');
  paginationRightDot.classList.add('disabled');
  paginationRightDot.innerHTML = '..'


  if (lang == "arabic") {
    document.getElementById("pageNumberDiv").prepend(paginationRightDot)
  } else {
    document.getElementById("pageNumberDiv").append(paginationRightDot)
  }
  if (tempI == totalPaginate) {
    $("#rightDot").hide()
  }

  var totalCountDiv = document.createElement("a");
  totalCountDiv.classList.add("pagination-anchor");
  totalCountDiv.classList.add("disabled");

  let spanText = document.createElement("span")
  spanText.classList.add("page-span-number")
  spanText.innerHTML = totalPaginate

  let numberSpanText = document.createElement("span")
  numberSpanText.classList.add("page-span-number")
  numberSpanText.innerHTML = reportLookUpData.of; //string

  if (lang == "arabic") {
    totalCountDiv.append(numberSpanText)
    totalCountDiv.append(spanText)
    document.getElementById("pageNumberDiv").prepend(totalCountDiv);
  } else {
    totalCountDiv.append(numberSpanText)
    totalCountDiv.append(spanText)
    document.getElementById("pageNumberDiv").append(totalCountDiv);
  }
  $("#pageNumberDiv a").click(function (event) {
    if (!$(this).hasClass("active")) {
      if ($(this).text() == totalPaginate) {
        $("#paginationDiv a").removeClass("active");
        $(this).addClass("active");
        end = pageSize * $(this).text();
        startPageNumber = startPage - 1;
        $("#reportTable tbody tr").remove();
        loadReportTableDetails(reportList.slice(end - pageSize, end));
      }
      else if ((startPageNumber < totalPaginate)) {
        startPageNumber++;
        $('#pageNumberDiv a').remove();
        $("#reportTable tbody tr").remove();
        $("#leftArrow").removeClass('disabled');
        $("#leftDoubleArrow").removeClass('disabled');
        $("#leftDot").show()
        let startPage = (startPageNumber)
        createPageNumberSet(startPage, totalPaginate, reportList)
        loadReportTableDetails(reportList.slice((startPage * pageSize) - pageSize, (startPage * pageSize)));
      }
    }
    // if (!$(this).hasClass("disabled")) {
    //   $("#paginationDiv a").removeClass("active");
    //   $(this).addClass("active");
    //   end = pageSize * $(this).text();
    //   startPageNumber = $(this).text();
    //   $("#reportTable tbody tr").remove();
    //   loadReportTableDetails(reportList.slice(end - pageSize, end));
    // }
  });
}

function searchTable() {
  filteredObject.searchText = document.getElementById("reportSearch").value;
  $("#reportTable tbody tr").remove();
  loadFilteredReportDetails(filteredObject);
}

function loadReportTableDetails(reportList) {
  var tbodyContainer = document.createDocumentFragment();
  var rowContainer;

  if ((!isEmptyList(reportList))) {
    document.getElementById("noRecordsContent").classList.add("d-none")

    $.each(reportList, function (key, value) {
      rowContainer = document.createElement("tr");
      rowContainer.setAttribute("id", value.requestNo)

      if (!value.isOldSystemDetails) {
        rowContainer.addEventListener("click", function (event) {
          window.open(REPORT_DASHBOARD_URL + value.requestNo, "_blank"); //url

        });
      } else {
        rowContainer.setAttribute(
          "style",
          "background:#F0F1F2;pointer-events:none"
        );
      }
      var requestColumn = document.createElement("td");
      var reqId = value.requestNo
      if (value.isOldSystemDetails) {
        reqId = reqId + " **";
      }
      requestColumn.innerHTML = reqId;



      var crColumn = document.createElement("td");
      crColumn.innerHTML = value.crNumber;


      var certificateColumn = document.createElement("td");
      certificateColumn.innerHTML = value.certificateNo;


      var yearColumn = document.createElement("td");
      yearColumn.innerHTML = value.year;


      var quarterColumn = document.createElement("td");
      quarterColumn.innerHTML = value.quarter;

      var assessmentColumn = document.createElement("td");
      var formattedDate = !isEmpty(value.assessmentDate) ? getFormattedDate(value.assessmentDate) : "";
      assessmentColumn.innerHTML = formattedDate;
      assessmentColumn.setAttribute(
        "date-to-Sort",
        converDateForSortFormat(formattedDate)
      );

      let btnArLink = document.createElement("button")
      let arLink = null;
      let enLink = null;
      if (!isEmpty(value.pdfReportIdAr)) {
        arLink = { 'docId': value.pdfReportIdAr, 'docName': value.pdfReportNameAr, "docExtension": 'pdf' }
      }

      let pdfLink = document.createElement("td");

      let docDiv = document.createElement("div")
      docDiv.classList.add("d-flex")


      btnArLink.setAttribute("id", "btnAr" + value.requestNo)
      btnArLink.setAttribute("style", "white-space:nowrap")


      btnArLink.classList.add("btn")
      btnArLink.classList.add("btn-sm")
      btnArLink.classList.add("DS")
      btnArLink.classList.add("hvr-top")
      btnArLink.classList.add("btn-outline-primary")
      btnArLink.classList.add("rounded-pill")
      btnArLink.classList.add("btn-color")
      btnArLink.classList.add("mr-2")
      btnArLink.classList.add("btn-outline-primary")
      btnArLink.classList.add("download-icon-table")

      let imgSpanAr = document.createElement("span")
      imgSpanAr.setAttribute("style", "pointer-events:none")


      imgSpanAr.classList.add("d-flex")
      imgSpanAr.classList.add("align-items-center")

      let iconSpanAr = document.createElement("span")
      iconSpanAr.setAttribute("id", "span" + "btnAr" + value.requestNo)

      let iconImgAr = document.createElement("img");
      iconImgAr.setAttribute("id", "img" + "btnAr" + value.requestNo)
      iconImgAr.setAttribute("style", "height:15px")
      iconImgAr.src = fileImgSrc

      iconSpanAr.append(iconImgAr)

      imgSpanAr.append(iconSpanAr)

      let imgSpanArTxt = document.createElement("span")
      imgSpanArTxt.classList.add("pl-2")
      imgSpanArTxt.innerHTML = reportLookUpData.arabic  //string

      imgSpanAr.append(imgSpanArTxt)

      btnArLink.append(imgSpanAr)


      btnArLink.addEventListener("click", function (event) {
        event.stopPropagation()
        downloadFile(arLink, "btnAr" + value.requestNo)
      })

      if (!isEmpty(arLink)) {
        docDiv.append(btnArLink)
      }

      let btnEnLink = document.createElement("button")


      if (!isEmpty(value.pdfReportIdEng)) {
        enLink = { 'docId': value.pdfReportIdEng, 'docName': value.pdfReportNameEng, "docExtension": 'pdf' }
      }


      btnEnLink.setAttribute("id", "btnEn" + value.requestNo)
      btnEnLink.setAttribute("style", "white-space:nowrap")

      btnEnLink.classList.add("btn")
      btnEnLink.classList.add("btn-sm")
      btnEnLink.classList.add("DS")
      btnEnLink.classList.add("hvr-top")
      btnEnLink.classList.add("btn-outline-primary")
      btnEnLink.classList.add("rounded-pill")
      btnEnLink.classList.add("btn-color")
      btnEnLink.classList.add("btn-outline-primary")
      btnEnLink.classList.add("download-icon-table")

      let imgSpanEn = document.createElement("span")
      imgSpanEn.setAttribute("style", "pointer-events:none")

      imgSpanEn.setAttribute("id", "btnEn" + value.requestNo)
      imgSpanEn.classList.add("d-flex")
      imgSpanEn.classList.add("align-items-center")


      let iconSpanEn = document.createElement("span")
      iconSpanEn.setAttribute("id", "span" + "btnEn" + value.requestNo)

      let iconImgEn = document.createElement("img");
      iconImgEn.setAttribute("style", "height:15px")
      iconImgEn.setAttribute("id", "img" + "btnEn" + value.requestNo)
      iconImgEn.src = fileImgSrc
      iconSpanEn.append(iconImgEn)
      imgSpanEn.append(iconSpanEn)

      let imgSpanEnTxt = document.createElement("span")
      imgSpanEnTxt.classList.add("pl-2")
      imgSpanEnTxt.innerHTML = reportLookUpData.english //string

      imgSpanEn.append(imgSpanEnTxt)

      btnEnLink.append(imgSpanEn)

      btnEnLink.addEventListener("click", function (event) {
        event.stopPropagation()
        downloadFile(enLink, "btnEn" + value.requestNo)
      })


      if (!isEmpty(enLink)) {
        docDiv.append(btnEnLink)
      }

      let statusDiv = document.createElement("div")
      statusDiv.classList.add("d-flex");
      statusDiv.classList.add("justify-content-left");

      let stsIcon = document.createElement("img")
      stsIcon.classList.add("mr-1")
      stsIcon.classList.add("mt-1")

      let stsTextDiv = document.createElement("div")
      stsTextDiv.classList.add("comment-date")
      stsTextDiv.classList.add("mt-2")

      let stsText = document.createElement("span")
      stsText.classList.add("tick-text")

      stsText.innerHTML = value.statusInfo[lang]['lastRequestStatus']

      if (value.statusInfo.statusId == REPORT_STATUS_WAITING || value.statusInfo.statusId == REPORT_STATUS_N0_FS_WAITING) {
        stsIcon.src = iconCaution;
        stsText.setAttribute("style", "color:#FF8500")
      } else if (value.statusInfo.statusId == REPORT_STATUS_GENERATED) {
        stsIcon.src = iconTick;
        stsText.setAttribute("style", "color:#5CB366")
      } else {
        stsIcon.src = iconTick;
      }

      stsTextDiv.append(stsText)

      statusDiv.append(stsIcon)
      statusDiv.append(stsTextDiv)

      let dateTxt = document.createElement("h6")
      dateTxt.classList.add("date-txt");
      dateTxt.classList.add("mt-1")
      let dateTxtValue = ""
      if (!isEmpty(value.surveyExpiryDate)) {
        dateTxtValue = reportLookUpData.reportGenerationWithFS + "(" + value.surveyExpiryDate + ")"
      } else {
        dateTxtValue = reportLookUpData.reportGenerationNoFS
      }
      dateTxt.innerHTML = dateTxtValue

      if (!value.isOldSystemDetails && (isEmpty(enLink) && isEmpty(arLink))) {
        pdfLink.append(statusDiv)
        pdfLink.append(dateTxt)
      } else {
        pdfLink.append(docDiv)
      }

      rowContainer.append(requestColumn);
      rowContainer.append(crColumn);
      rowContainer.append(certificateColumn);
      rowContainer.append(yearColumn);
      rowContainer.append(quarterColumn);
      rowContainer.append(assessmentColumn);

      rowContainer.append(pdfLink);

      tbodyContainer.append(rowContainer);
    });
  }
  else {
    document.getElementById("noRecordsContent").classList.remove("d-none")
  }

  document.getElementById("bodyContent").appendChild(tbodyContainer);
}

function sortTable(n, type, value, event) {
  if (!isEmpty(document.getElementById('sortImg')))
    document.getElementById('sortImg').remove()
  filteredObject.sortType = type
  if (filteredObject.sortField == value && filteredObject.sortDir == 'asc') {
    let downArrowContainer = document.createElement('img')
    downArrowContainer.setAttribute('src', downArrowImg)
    downArrowContainer.classList.add("sort-img")
    downArrowContainer.setAttribute('id', "sortImg")

    document.getElementById('th' + n).appendChild(downArrowContainer)

    filteredObject.sortDir = 'dsc';
  } else {

    let upArrowContainer = document.createElement('img')
    upArrowContainer.setAttribute('src', upArrowImg)
    upArrowContainer.classList.add("sort-img")
    upArrowContainer.setAttribute('id', "sortImg")
    document.getElementById('th' + n).appendChild(upArrowContainer)

    filteredObject.sortField = value;
    filteredObject.sortDir = 'asc';
  }
  $("#reportTable tbody tr").remove();
  loadFilteredReportDetails(filteredObject);

}