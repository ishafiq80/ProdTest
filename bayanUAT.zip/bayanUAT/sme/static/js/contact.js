let isContactFormValid

let resultContactData = {

    "requestorName": null,
    "requestorEmailId": null,
    "requestorMobNo": null,
    "issue": null,
    "assessmentNo": null,
    "queries": null,
    "supportPersonEmailId": null

}


const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]{2,63}\.)+[a-zA-Z]{2,}))$/;
const PHONE_REGEX_WITH_COUNTRY_CODE = /^\+[0-9-]{1,4}\s?[0-9-+()]*$/

function applyInValidInput(element){
    document.getElementById(element.id+'IconSpan').classList.add('is-invalid-span')
    document.getElementById(element.id+'Icon').classList.add('icon-invalid')
    document.getElementById(element.id+'IconSpan').classList.remove('is-valid-span')
    document.getElementById(element.id+'Icon').classList.remove('icon-done')
   
}
function applyValidInput(element){
    document.getElementById(element.id+'IconSpan').classList.remove('is-invalid-span')
    document.getElementById(element.id+'Icon').classList.remove('icon-invalid')
    document.getElementById(element.id+'IconSpan').classList.add('is-valid-span')
    document.getElementById(element.id+'Icon').classList.add('icon-done')
                
}

function validateSupportInput(element, error) {

    let isFieldValid = false;
    let value = element.value.trim();

    if (element.tagName.toLowerCase() == "input") {
        if (element.type == "text") {
            if (value.length == 0) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)

                error.innerHTML = lookupDetails.nameRequiredValidation //string
                error.classList.remove('d-none')
            } else if (value.length > validations.nameLength) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.nameLengthValidation //string
                error.classList.remove('d-none')
            } else {
                isFieldValid = true
                element.classList.remove("is-invalid")
                element.classList.add("is-valid")
                applyValidInput(element)
                error.classList.add('d-none')
            }
        }
        else if (element.type == "number") {
            if (value.length == 0) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.assessmentNumberValidation //string
                error.classList.remove('d-none')
            }
            else {
                isFieldValid = true
                element.classList.remove("is-invalid")
                element.classList.add("is-valid")
                applyValidInput(element)
                error.classList.add('d-none')
            }
        }
        else if (element.type == "email") {
            if (value.length == 0) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.emailIdRequiredValidation //string
                error.classList.remove('d-none')
            }
            else if (!EMAIL_REGEX.test(value)) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.emailIdValidation //string
                error.classList.remove('d-none')
            }
            else {
                isFieldValid = true
                element.classList.remove("is-invalid")
                element.classList.add("is-valid")
                applyValidInput(element)
                error.classList.add('d-none')
            }
        } else if (element.type == "tel") {
            if (value.length == 0) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.mobileNumberRequiredValidation //string
                error.classList.remove('d-none')
            }else if(value.substring(0,4)=='+966' && (value.substring(4).length!=9 || value.substring(4)[0]!='5') ){
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.mobileNumberValidation //string
                error.classList.remove('d-none')
            }
            else if (!(value.length >= 8 && value.length <= 21)) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.mobileNumberValidation //string
                error.classList.remove('d-none')
            }
            else if (!PHONE_REGEX_WITH_COUNTRY_CODE.test(value)) {
                isFieldValid = false
                element.classList.add("is-invalid")
                element.classList.remove("is-valid")
                applyInValidInput(element)
                error.innerHTML = lookupDetails.mobileNumberValidation //string
                error.classList.remove('d-none')
            }
            else {
                isFieldValid = true
                element.classList.remove("is-invalid")
                element.classList.add("is-valid")
                error.classList.add('d-none')
                applyValidInput(element)
            }

        }
    } else if (element.tagName.toLowerCase() == "textarea") {
        if (value.length == 0) {
            isFieldValid = false
            element.classList.add("is-invalid")
            element.classList.remove("is-valid")
            error.innerHTML = lookupDetails.queriesRequiredValidation //string
            error.classList.remove('d-none')
        } else if (value.length > validations.queriesLength) {
            isFieldValid = false
            element.classList.add("is-invalid")
            element.classList.remove("is-valid")
            error.innerHTML = lookupDetails.queriesLengthValidation //string
            error.classList.remove('d-none')
        } else {
            isFieldValid = true
            element.classList.remove("is-invalid")
            element.classList.add("is-valid")
            error.classList.add('d-none')
        }
    }
    return isFieldValid
}

function onContactInputChangeListener(event) {
    let element
    if (!isEmpty(event.target)) {
        element = event.target
    } else {
        element = event
    }

    let inputType = element.tagName.toLowerCase()

    if (inputType == "input") {
        let errorElement = document.getElementById(element.id+"ErrorText");
        if (element.type == "text") {
            if (!isEmpty(errorElement)) {
                let isInputValid = validateSupportInput(element, errorElement)
                isContactFormValid = isInputValid
            }

            if (isContactFormValid) {
                resultContactData[element.id] = element.value
            }
        }
        if (element.type == "number") {
            if (!isEmpty(errorElement)) {
                let isInputValid = validateSupportInput(element, errorElement)
                isContactFormValid = isInputValid
            }

            if (isContactFormValid) {
                resultContactData[element.id] = element.value
            }
        }
        if (element.type == "tel") {
            if (!isEmpty(errorElement)) {
                let isInputValid = validateSupportInput(element, errorElement)
                isContactFormValid = isInputValid
            }

            if (isContactFormValid) {
                resultContactData[element.id] = element.value
            }

        }
        if (element.type == "email") {
            if (!isEmpty(errorElement)) {
                let isInputValid = validateSupportInput(element, errorElement)
                isContactFormValid = isInputValid
            }

            if (isContactFormValid) {
                resultContactData[element.id] = element.value
            }

        }
    }

    else if (inputType == "select") {
        if (element.id == "issue") {
            errorElement = document.getElementById("subjectErrorText")

            let isInputValid = validateIssueSelect(element, errorElement)
            isContactFormValid = isInputValid

            if (isContactFormValid) {
                resultContactData[element.id] = element.options[element.selectedIndex].text
            }

        }
    }

    else if (inputType == "textarea") {

        let errorElement = document.getElementById("queryErrorText")

        if (!isEmpty(errorElement)) {
            let isInputValid = validateSupportInput(element, errorElement)
            isContactFormValid = isInputValid
        }

        if (isContactFormValid) {
            resultContactData[element.id] = element.value
        }

    }

    return isContactFormValid
}

function validateIssueSelect(element, errorElement) {

    let isFieldValid
    if (!isEmpty(element.value) && element.selectedIndex != 0) {

        document.getElementById("assessmentNumberDiv").classList.remove("d-none")
        document.getElementById("assessmentNo").classList.add("field-validate")
        errorElement.classList.add("d-none")
        $(element).siblings()[0].classList.remove("is-invalid")
        resultContactData[element.id] = element.innerHTML
        isFieldValid = true

    } else if (element.selectedIndex != 0) {

        document.getElementById("assessmentNumberDiv").classList.add("d-none")
        document.getElementById("assessmentNo").classList.remove("field-validate")
        document.getElementById("assessmentNo").classList.remove("is-invalid")
        document.getElementById("assessmentNoErrorText").classList.add("d-none")
        errorElement.classList.add("d-none")
        $(element).siblings()[0].classList.remove("is-invalid")
        if (!isEmpty(element.options[element.selectedIndex])) {
            resultContactData[element.id] = element.options[element.selectedIndex].text
        }
        isFieldValid = true

    } else {

        document.getElementById("assessmentNumberDiv").classList.add("d-none")
        document.getElementById("assessmentNo").classList.remove("field-validate")
        document.getElementById("assessmentNo").classList.remove("is-invalid")
        document.getElementById("assessmentNoErrorText").classList.add("d-none")
        errorElement.classList.remove("d-none")
        $(element).siblings()[0].classList.add("is-invalid")
        errorElement.innerHTML = lookupDetails.selectOption
        isFieldValid = false
    }


    return isFieldValid

}

function validateContactForm(value) {
    return onContactInputChangeListener(value)
}

function resetContactForm() {
    document.getElementById("requestorName").value = userDetails.fullName //user name //string
    document.getElementById("requestorMobNo").value = userDetails.mobile // user mobile number //string
    document.getElementById("requestorEmailId").value = userDetails.mail //string
    document.getElementById("queries").value = ""
    document.getElementById("assessmentNo").value = ""
    document.getElementById("issue").selectedIndex = "0";
    $("#issue").trigger("change")
    document.getElementById("issue").nextElementSibling.classList.remove("is-invalid")

    document.getElementById("requestorName").classList.remove("is-valid")
    document.getElementById("requestorName").classList.remove("is-invalid")
    document.getElementById("requestorMobNo").classList.remove("is-valid")
    document.getElementById("requestorMobNo").classList.remove("is-invalid")
    document.getElementById("requestorEmailId").classList.remove("is-valid")
    document.getElementById("requestorEmailId").classList.remove("is-invalid")
    document.getElementById("queries").classList.remove("is-invalid")
    document.getElementById("queries").classList.remove("is-valid")
    document.getElementById("assessmentNo").classList.remove("is-invalid")
    document.getElementById("assessmentNo").classList.remove("is-valid")


 
    $("#issue").siblings()[1].classList.add("d-none")
  
}


function postContactData() {

    isContactFormValid = false

    $("#contactContainer .field-validate").each(function (key, value) {
        isContactFormValid = validateContactForm(value)

    })

    $('#contactContainer .is-invalid').each(function (key, value) {
        isContactFormValid = false
        return
    })

    if (isContactFormValid) {
        resultContactData['supportPersonEmailId'] = contactDetails.emailId
        let resultData = { "supportTicketDetails": resultContactData }

        
        $.ajax({
            beforeSend: function () {
                $("#loaderContainer").removeClass("d-none");
            },
            type: 'POST',
            url: CONTACT_POST_URL,
            data: JSON.stringify(resultData),
            success: function (data) {
                if (data.status_code == 200) {
                    $("#statusAlert").addClass("alert-success")
                    $("#statusAlert").removeClass("alert-danger")
                    $("#statusAlert").removeClass("d-none")

                } else {

                    if(data.isReload){
                        // window.location=LANDING_URL
                        window.location.reload()
                    }
                    else
                    {
                    $("#statusAlert").addClass("alert-danger")
                    $("#statusAlert").removeClass("alert-success")
                    $("#statusAlert").removeClass("d-none")
                    }
                }
                document.getElementById("stsMsg").innerHTML = data.messageInfo[lang].messageTitle + " " + data.messageInfo[lang].messageDescription
                resetContactForm()


            },
            error: function (data) {

                createServiceResponseCard(data)

                $("#contactContainer").addClass('d-none')
                $("#responseContainer").removeClass('d-none')
            },
            complete: function () {
                $("#loaderContainer").addClass("d-none");
      

            }
        })

    }

}