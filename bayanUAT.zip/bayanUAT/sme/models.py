from django.db import models
from django.contrib.auth.models import AbstractUser

class SessionDetails(AbstractUser):
    
    access_token = models.CharField(max_length=60,unique=True, db_index=True, primary_key=True)
    expires_in=models.CharField(max_length=30)
    session_id=models.TextField(blank=True,null=True)
    is_loggedout = models.BooleanField(default=False) 
    login_time=models.DateTimeField(blank=True,null=True)
    logout_time=models.DateTimeField(blank=True,null=True)
    expire_time=models.DateTimeField(blank=True,null=True)
    action_by=models.CharField(max_length=10,blank=True,null=True)
    user_agent=models.TextField(blank=True,null=True)
    uid=models.CharField(max_length=30)

class UserDetails(models.Model):

    national_id=models.CharField(max_length=30)
    user_picture = models.TextField(blank=True,null=True)
    mail=models.CharField(max_length=30,blank=True,null=True)
    mobile_number=models.CharField(max_length=20,blank=True,null=True)
    cr_list=models.TextField(blank=True,null=True)
    uid=models.CharField(max_length=30, db_index=True, primary_key=True)
    uuid=models.TextField()
    name=models.CharField(max_length=30,blank=True,null=True)
    full_name=models.CharField(max_length=30,blank=True,null=True)
    gender=models.CharField(max_length=10,blank=True,null=True)
    temp_email=models.CharField(max_length=100,blank=True,null=True)
    verified_email=models.CharField(max_length=100,blank=True,null=True)
    verified_mobile=models.CharField(max_length=20,blank=True,null=True)
    langcode=models.CharField(max_length=10,blank=True,null=True)
    default_langcode=models.CharField(max_length=10,blank=True,null=True)
    preferred_langcode=models.CharField(max_length=10,blank=True,null=True)
    preferred_admin_langcode=models.CharField(max_length=10,blank=True,null=True)
    about=models.TextField(blank=True,null=True)
    birthdate=models.CharField(max_length=20,blank=True,null=True)
    timezone=models.CharField(max_length=20,blank=True,null=True)
    facebook_url=models.TextField(blank=True,null=True)
    twitter_url=models.TextField(blank=True,null=True)
    linkedin_url=models.TextField(blank=True,null=True)
    status=models.CharField(max_length=5,blank=True,null=True)
    # created=models.CharField(max_length=20,blank=True,null=True)
    # changed=models.CharField(max_length=20,blank=True,null=True)

    def __str__(self):
        return self.uid

class SmeCommonLookup(models.Model):

    lookup_details=models.TextField()
    footer_details=models.TextField()
    key_value=models.CharField(max_length=30, db_index=True, primary_key=True)
    
    def __str__(self):
        return self.key_value

class CRDetails(models.Model):

    cr_number=models.TextField()
    cr_company_name=models.CharField(max_length=200,blank=True,null=True)
    user_key=models.ForeignKey(UserDetails, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.cr_number



