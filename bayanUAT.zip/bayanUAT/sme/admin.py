from django.contrib import admin
from sme.models import SessionDetails,UserDetails,SmeCommonLookup,CRDetails
# Register your models here.

admin.site.register(SessionDetails)
admin.site.register(UserDetails)
admin.site.register(SmeCommonLookup)
admin.site.register(CRDetails)

from django.contrib.sessions.models import Session
admin.site.register(Session)