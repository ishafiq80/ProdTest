from functools import partial
from random import randint
from django.http.response import JsonResponse
from datetime import datetime
from django.utils import timezone
import asyncio,requests,json
from sme.constants import CORPORATE_DETAILS_URL,MESSAGE_INFO,ACTION_BY_STATUS
from sme.models import SessionDetails,UserDetails,CRDetails
from bayan.constants import B2B_USERNAME,B2B_PASSWORD

def getConcatString(key,subKey,val): 
    if key in val:
        if isinstance(val[key], list):
            return ','.join(v[subKey] for v in val[key])
        else:
            return val[key][subKey]
    else:
        return ''

async def getResponseList(crNumber,lang):
    xml="<soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope' xmlns:v1='V1'> <soap:Header xmlns:wsa='http://www.w3.org/2005/08/addressing'> <wsa:Action>V1/Reports/BuyReportByCRNumber</wsa:Action> </soap:Header> <soap:Body> <v1:BuyReportByCRNumber> <v1:request> <v1:Culture>"+str(lang)+"</v1:Culture> <v1:Consent>true</v1:Consent> <v1:ProductID>RPT_HQR_PAY_FIN_B2C</v1:ProductID> <v1:ReasonCode>RCER</v1:ReasonCode> <!--Optional:--> <v1:CustomerReference/> <v1:Format>XML</v1:Format> <v1:CRNumber>"+str(crNumber)+"</v1:CRNumber> </v1:request> <v1:Username>"+str(B2B_USERNAME)+"</v1:Username> <v1:Password>"+str(B2B_PASSWORD)+"</v1:Password> </v1:BuyReportByCRNumber> </soap:Body> </soap:Envelope>"
    fsxml="<soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope' xmlns:v1='V1'><soap:Header xmlns:wsa='http://www.w3.org/2005/08/addressing'><wsa:Action>V1/Reports/SearchByCRNumber</wsa:Action></soap:Header><soap:Body> <v1:SearchByCRNumber> <v1:request> <v1:Culture>"+str(lang)+"</v1:Culture> <v1:Format>XML</v1:Format>  <v1:CRNumber>"+str(crNumber)+"</v1:CRNumber> </v1:request> <v1:Username>"+str(B2B_USERNAME)+"</v1:Username> <v1:Password>"+str(B2B_PASSWORD)+"</v1:Password> </v1:SearchByCRNumber> </soap:Body> </soap:Envelope>"
    loop = asyncio.get_event_loop()
    reportResponse = loop.run_in_executor(None,partial(requests.post,verify=False,timeout=120,headers={'Content-Type': 'application/soap+xml'},data=xml), CORPORATE_DETAILS_URL)
    financialStatementResponse = loop.run_in_executor(None,partial(requests.post,verify=False,timeout=120,headers={'Content-Type': 'application/soap+xml'},data=fsxml), CORPORATE_DETAILS_URL)
    responseList=[]
    responseList.append(await reportResponse)
    responseList.append(await financialStatementResponse)
    return responseList

def getRandomNumber(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

def getTabTemplate(tabname):
    if tabname=="dashboard": 
        return 'sme/dashboard.html'; 
    elif tabname=="crRecords": 
        return 'sme/crRecords.html'; 
    elif tabname=="reports": 
        return 'sme/reports.html'; 
    elif tabname=="contact": 
        return 'sme/contact.html'; 
    elif tabname == "reportDashboard":
        return 'sme/reportDetail.html'
    else: 
        return 'sme/dashboard.html'; 

def editedResponse(response):
    if 'statusCode' in response:
        del response['statusCode']
    if 'description' in response:
        del response['description']
    return response  

def createUserProfile(accessTokenResponse,profileResponse):
    user=SessionDetails.objects.create(
        username=accessTokenResponse['access_token'],
        access_token=accessTokenResponse['access_token'],
        expires_in=accessTokenResponse['expires_in'],
        login_time=datetime.now(),
        uid=profileResponse['uid']
        )
    return user

def createUserDetails(profileResponse,crListResponse):
    crList=''
    if isinstance(crListResponse, list):
        crList=[None] * len(crListResponse)
        for i,crObj in enumerate(crListResponse):
            crList[i]=json.dumps(crObj['number'])

    user=UserDetails.objects.create(
        national_id=profileResponse['national_id'],
        uid=str(profileResponse['uid']),
        mobile_number=profileResponse['mobile_number'],
        mail=profileResponse['mail'],
        user_picture=profileResponse['user_picture'],
        cr_list=','.join(crList),
        full_name=profileResponse['full_name'],
        name=profileResponse['name'],
        gender=profileResponse['gender'],
        temp_email=profileResponse['temp_email'],
        verified_email=profileResponse['verified_email'],
        verified_mobile=profileResponse['verified_mobile'],
        langcode=profileResponse['langcode'],
        default_langcode=profileResponse['default_langcode'],
        preferred_langcode=profileResponse['preferred_langcode'],
        preferred_admin_langcode=profileResponse['preferred_admin_langcode'],
        about=profileResponse['about'],
        birthdate=profileResponse['birthdate'],
        facebook_url=profileResponse['facebook_url'],
        twitter_url=profileResponse['twitter_url'],
        linkedin_url=profileResponse['linkedin_url'],
        timezone=profileResponse['timezone'],
        status=profileResponse['status'],
        # created=profileResponse['created'],
        # changed=profileResponse['changed']
        )
    if isinstance(crListResponse, list):
        for i,crObj in enumerate(crListResponse):
            CRDetails.objects.create(
                cr_company_name=crObj['name'],
                cr_number=crObj['number'],
                user_key=user
            )
    
def getUserDataObj():
    SessionDetails.objects.filter(expire_time__lt=datetime.now()).update(action_by=ACTION_BY_STATUS['sys'])
    userDetailsTableList = UserDetails.objects.all()
    userDetailsList=[]
    for user in userDetailsTableList:
        userDetailsObj=[{}]
        userDetailsObj[0]['nationalId']=user.national_id
        userDetailsObj[0]['uid']=user.uid
        userDetailsObj[0]['name']=user.name
        userDetailsObj[0]['full_name']=user.full_name
        userDetailsObj[0]['gender']=user.gender
        userDetailsObj[0]['mail']=user.mail
        userDetailsObj[0]['tempEmail']=user.temp_email
        userDetailsObj[0]['verifiedEmail']=user.verified_email
        userDetailsObj[0]['mobileNumber']=user.mobile_number
        userDetailsObj[0]['verifiedMobile']=user.verified_mobile
        userDetailsObj[0]['langCode']=user.langcode
        userDetailsObj[0]['defaultLangCode']=user.default_langcode
        userDetailsObj[0]['preferredLangCode']=user.preferred_langcode
        userDetailsObj[0]['preferredAdminLangCode']=user.preferred_admin_langcode
        userDetailsObj[0]['about']=user.about
        userDetailsObj[0]['birthdate']=user.birthdate
        userDetailsObj[0]['facebookURL']=user.facebook_url
        userDetailsObj[0]['linkedinURL']=user.linkedin_url
        userDetailsObj[0]['twitterURL']=user.twitter_url
        userDetailsObj[0]['userPicture']=user.user_picture
        userDetailsObj[0]['timezone']=user.timezone
        userDetailsObj[0]['status']=user.status
        sessionTableList=SessionDetails.objects.filter(uid=user.uid)
        sessionList=[]
        for session in sessionTableList:
            sessionObj=[{}]
            sessionObj[0]['accessCode']=session.access_token
            sessionObj[0]['sessionId']=session.session_id
            sessionObj[0]['defaultSessionDuration']=session.expires_in
            sessionObj[0]['loggedInTime']=session.login_time
            sessionObj[0]['loggedOutTime']=session.logout_time
            sessionObj[0]['expiredTime']=session.expire_time
            sessionObj[0]['actionedBy']=session.action_by
            sessionObj[0]['userAgent']=session.user_agent
            sessionList.extend(sessionObj)
        userDetailsObj[0]['sessionDetails']=sessionList
        userDetailsList.extend(userDetailsObj)
    return userDetailsList

def getProfileDetails(userDetails):
    data={}
    data['userProfile']=userDetails.user_picture
    data['nationalId']=userDetails.national_id
    data['fullName']=userDetails.full_name
    data['mobile']=userDetails.mobile_number
    data['mail']=userDetails.mail
    data['total_commercial_records']=len(userDetails.cr_list.split(',')) if userDetails.cr_list else ''
    return data