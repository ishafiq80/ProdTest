from django.shortcuts import render,redirect
from django.views.decorators.http import require_GET,require_POST
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse,HttpResponse
from bayan.constants import LANDING_URL,CLIENT_ID,CLIENT_SECRET,AUTHORISATION_KEY,REDIRECT_URL,SSO_TOKEN_URL,SSO_PROFILE_URL,SSO_CR_LIST_URL,KEY_MISMATCH_STRING
from sme.constants import MESSAGE_INFO,ACTION_BY_STATUS
from .api_data import getDataForDashboard,getFooterDetails
from sme.utils import getTabTemplate,createUserProfile,createUserDetails,getUserDataObj
import json,requests
from datetime import datetime, timedelta

from sme.models import SessionDetails,UserDetails,SmeCommonLookup
from django.contrib.auth import authenticate, login,logout

@require_GET
def index(request):
    template = 'sme/dashboard.html'
    if request.user.is_authenticated:
        requestFrom = request.GET.get('requestFrom')
        params=request.GET.get('params')
        if requestFrom == 'reportDashboard':
            return JsonResponse(getDataForDashboard(requestFrom,params,request),safe=False)
        return render(request, template, getDataForDashboard('dashboard','',request))
    else:
        authorisationCode=request.GET.get('code')
        if authorisationCode:
                data={
                    "client_id":CLIENT_ID,
                    "client_secret":CLIENT_SECRET,
                    "redirect_uri":REDIRECT_URL,
                    "code":authorisationCode,
                    "grant_type":"authorization_code"
                }
                accessTokenResponse=requests.post(SSO_TOKEN_URL,data=data)
                if accessTokenResponse.ok:
                    accessTokenResponse=accessTokenResponse.json()
                    if accessTokenResponse['access_token']:
                        headers={"Content-Type":"application/json",'Authorization':'Bearer {}'.format(accessTokenResponse['access_token'])}
                        profileResponse=requests.get(SSO_PROFILE_URL,headers=headers)
                        profileResponse=profileResponse.json()
                        crListResponse=requests.get(SSO_CR_LIST_URL,headers=headers)
                        crListResponse=crListResponse.json()
                        user=createUserProfile(accessTokenResponse,profileResponse)
                        login(request, user,backend='django.contrib.auth.backends.ModelBackend')
                        try:
                            UserDetails.objects.get(uid=str(profileResponse['uid'])).delete()
                            createUserDetails(profileResponse,crListResponse)
                        except UserDetails.DoesNotExist:
                            createUserDetails(profileResponse,crListResponse)
                        user=SessionDetails.objects.get(access_token=request.user)
                        user.session_id=request.session.session_key
                        user.user_agent=request.headers['User-Agent']
                        user.expire_time= datetime.now() + timedelta(seconds=accessTokenResponse['expires_in'])
                        user.save()
                        request.session.set_expiry(accessTokenResponse['expires_in'])
                        return render(request, template, getDataForDashboard('dashboard','',request))
                else:
                    template='sme/landingPage.html'
                    return render(request, template, getFooterDetails())
                    # return redirect(LANDING_URL)
        else:
            template='sme/landingPage.html'
            return render(request, template, getFooterDetails())
            # return redirect(LANDING_URL)
            
def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

@require_GET
def renderTab(request,tabName,crNum):
    tabname=tabName
    params=crNum
    if not crNum:
        params=request.GET.get('params')
    if tabName=='cr-records':
        tabname='crRecords'
    if request.user.is_authenticated:
        return render(request, getTabTemplate(tabname), getDataForDashboard(tabname,params,request))
    else:
        template='sme/landingPage.html'
        return render(request, template, getFooterDetails())
        # return redirect(LANDING_URL)

            
@csrf_exempt
@require_POST
def logoutUser(request):
    if request.user.is_authenticated:
        SmeCommonLookup.objects.get(key_value=request.user).delete()
        user=SessionDetails.objects.get(access_token=request.user)
        user.logout_time=datetime.now()
        user.action_by=ACTION_BY_STATUS['user']
        user.is_loggedout=True
        user.save()
        logout(request)
    return HttpResponse("Logged out!!!")


@require_GET
def sendUserDetails(request):
    if request.GET.get('key')==AUTHORISATION_KEY:
        return JsonResponse(getUserDataObj(),safe=False)
    else:
        return HttpResponse(KEY_MISMATCH_STRING,status=401)