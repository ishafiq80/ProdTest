from bayan.constants import BASE_URL

MESSAGE_INFO = {
    "messageInfo":{
            "english": {
                "messageTitle": "Service unavailable!",
                "messageDescription": "Sorry, we'are unable to reach the server right now. Please try again later.",
                "btnText":"Return to home"
            },
            "arabic": {
                "messageTitle": "الخدمة غير متوفرة!‎",
                "messageDescription": "عذرًا ، لم نتمكن من الوصول إلى الخادم في الوقت الحالي. الرجاء معاودة المحاولة في وقت لاحق.",
                "btnText":"العودة إلى الصفحة الرئيسية"
            }
        }
}

SURVEY_GET=BASE_URL+'surveyquestions'

SURVEY_POST=BASE_URL+'post-survey-response'