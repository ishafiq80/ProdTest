def editedResponse(response):
    if 'statusCode' in response:
        del response['statusCode']
    if 'description' in response:
        del response['description']
    return response   