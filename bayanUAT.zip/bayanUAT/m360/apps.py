from django.apps import AppConfig


class M360Config(AppConfig):
    name = 'm360'
