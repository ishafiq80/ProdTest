from django.shortcuts import render
from django.views.decorators.http import require_GET
import json
from .api_data import getFormSchema

@require_GET
def surveyDetails(request, hash):
    template = 'm360/index.html'
    return render(request, template, {'response_data': json.dumps(getFormSchema(hash))})