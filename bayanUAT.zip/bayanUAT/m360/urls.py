from django.urls import path
from .api_data import postFormSchema
from . import views

urlpatterns = [
    path('postSurveyDetails/', postFormSchema, name='postSurveyDetails'),
    path('<hash>/', views.surveyDetails, name='index'),
    path('', views.surveyDetails,{'hash':''})
]
