from django.urls import path
from . import views 

urlpatterns = [
    path('renderChart/', views.renderChart, name='renderChart'),
    path('renderPdf/', views.renderPdf, name='renderPdf')
]